# 47 Recorder

Gravador de tela open source para Android, escrito do zero (Kotlin).

## Recursos (v1.5)
- Tema **vermelho + preto**
- Gravação de tela H.264 (até 1080p, 30/60 fps)
- **Áudio interno** do aparelho (AudioPlaybackCapture, Android 10+)
- Microfone opcional, mixado com o áudio interno
- Botão flutuante arrastável — menu com textos legíveis
- **Arraste o círculo até o X** para parar e fechar o app
- Controles na notificação (Parar / Print) — aparece no painel
- Replay instantâneo, face cam, marca d'água, modo limpo
- Placeholders: **47 Voice Rec Mode** e **47 Art Mode**

## Limitações
- Alguns apps bloqueiam a captura de áudio (ex.: apps de streaming com DRM, chamadas).
- Se o áudio interno falhar, grava só o vídeo.
- Formatos extras (qualquer codec) e “47 Art Mode” completo ainda não implementados.

## Gerar o APK
**GitHub Actions:** suba o projeto, abra a aba Actions e baixe o artefato `47recorder-apk`.
**Android Studio:** Build > Build APK(s).

## Próximos passos
47 Voice Rec Mode, 47 Art Mode (canvas de desenho), contagem regressiva, mais formatos de saída, personalização total de cores/layout.
