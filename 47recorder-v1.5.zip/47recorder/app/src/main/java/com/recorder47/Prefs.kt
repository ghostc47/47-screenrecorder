package com.recorder47

import android.content.Context
import android.graphics.Color
import androidx.core.graphics.ColorUtils

object Prefs {
    val DEFAULT_COLOR = 0xFFE53935.toInt()
    const val DEFAULT_SIZE = 64      // dp
    const val DEFAULT_OPACITY = 85   // %

    private fun sp(c: Context) = c.getSharedPreferences("prefs47", Context.MODE_PRIVATE)

    // Botão flutuante
    fun size(c: Context) = sp(c).getInt("size", DEFAULT_SIZE)
    fun opacity(c: Context) = sp(c).getInt("opacity", DEFAULT_OPACITY)
    fun color(c: Context) = sp(c).getInt("color", DEFAULT_COLOR)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()
    fun setOpacity(c: Context, v: Int) = sp(c).edit().putInt("opacity", v).apply()
    fun setColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()
    fun resetCircle(c: Context) {
        sp(c).edit().remove("size").remove("opacity").remove("color").apply()
    }

    // Vídeo
    fun resolution(c: Context) = sp(c).getInt("res", 720)
    fun bitrate(c: Context) = sp(c).getInt("bitrate", 5)
    fun fps(c: Context) = sp(c).getInt("fps", 30)
    fun setResolution(c: Context, v: Int) = sp(c).edit().putInt("res", v).apply()
    fun setBitrate(c: Context, v: Int) = sp(c).edit().putInt("bitrate", v).apply()
    fun setFps(c: Context, v: Int) = sp(c).edit().putInt("fps", v).apply()

    // Opções gerais
    fun mic(c: Context) = sp(c).getBoolean("mic", false)
    fun internal(c: Context) = sp(c).getBoolean("internal", true)
    fun clean(c: Context) = sp(c).getBoolean("clean", false)
    fun facecam(c: Context) = sp(c).getBoolean("facecam", false)
    fun setMic(c: Context, v: Boolean) = sp(c).edit().putBoolean("mic", v).apply()
    fun setInternal(c: Context, v: Boolean) = sp(c).edit().putBoolean("internal", v).apply()
    fun setClean(c: Context, v: Boolean) = sp(c).edit().putBoolean("clean", v).apply()
    fun setFacecam(c: Context, v: Boolean) = sp(c).edit().putBoolean("facecam", v).apply()

    // Marca d'água
    fun watermark(c: Context) = sp(c).getBoolean("wm", false)
    fun wmText(c: Context) = sp(c).getString("wmText", "47 Recorder") ?: "47 Recorder"
    fun wmPos(c: Context) = sp(c).getInt("wmPos", 3)   // 0 TE, 1 TD, 2 BE, 3 BD
    fun setWatermark(c: Context, v: Boolean) = sp(c).edit().putBoolean("wm", v).apply()
    fun setWmText(c: Context, v: String) = sp(c).edit().putString("wmText", v).apply()
    fun setWmPos(c: Context, v: Int) = sp(c).edit().putInt("wmPos", v).apply()

    // Replay instantâneo
    fun replaySec(c: Context) = sp(c).getInt("replaySec", 30)
    fun setReplaySec(c: Context, v: Int) = sp(c).edit().putInt("replaySec", v).apply()

    /** Preto ou branco, conforme o que fica legível sobre a cor. */
    fun contrast(color: Int): Int =
        if (ColorUtils.calculateLuminance(color) > 0.6) Color.BLACK else Color.WHITE
}
