package com.recorder47

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Camada transparente onde o dedo desenha traços. */
class DrawView(ctx: Context) : View(ctx) {
    private class Stroke(val path: Path, val paint: Paint)

    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private var lastX = 0f
    private var lastY = 0f
    var color: Int = Color.RED
    var widthPx: Float = 12f

    private fun newPaint(): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        p.strokeWidth = widthPx
        return p
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val path = Path()
                path.moveTo(e.x, e.y)
                path.lineTo(e.x + 0.1f, e.y)
                cur = Stroke(path, newPaint())
                lastX = e.x
                lastY = e.y
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val s = cur
                if (s != null) {
                    s.path.quadTo(lastX, lastY, (e.x + lastX) / 2f, (e.y + lastY) / 2f)
                    lastX = e.x
                    lastY = e.y
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val s = cur
                if (s != null) {
                    strokes.add(s)
                    cur = null
                }
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        for (s in strokes) canvas.drawPath(s.path, s.paint)
        val c = cur
        if (c != null) canvas.drawPath(c.path, c.paint)
    }

    fun undo() {
        if (strokes.isNotEmpty()) {
            strokes.removeAt(strokes.size - 1)
            invalidate()
        }
    }

    fun clear() {
        strokes.clear()
        cur = null
        invalidate()
    }
}

class DrawService : Service() {

    companion object {
        const val ACTION_TOGGLE = "com.recorder47.DRAW_TOGGLE"
        const val ACTION_CLOSE = "com.recorder47.DRAW_CLOSE"
        @Volatile var running = false
        private const val CHANNEL_ID = "rec47"
        private const val NOTIF_ID = 49
    }

    private var drawView: DrawView? = null
    private var barView: View? = null
    private var drawing = true

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val action = intent?.action
        if (action == ACTION_CLOSE) {
            closeAll()
        } else if (action == ACTION_TOGGLE) {
            if (running) closeAll() else openOverlay()
        } else if (!running) {
            openOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação", NotificationManager.IMPORTANCE_LOW)
        )
        val close = PendingIntent.getService(
            this, 9,
            Intent(this, DrawService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("47 Recorder")
            .setContentText("Desenhando na tela")
            .setOngoing(true)
            .addAction(0, "Fechar", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Ative a sobreposição de tela para desenhar", Toast.LENGTH_LONG).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dv = DrawView(this)

        val palette = intArrayOf(
            0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFFFDD835.toInt(), 0xFF43A047.toInt(),
            0xFF1E88E5.toInt(), 0xFFEC407A.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt()
        )
        val sizes = intArrayOf(4, 8, 14, 24)
        var ci = 0
        var si = 1
        dv.color = palette[ci]
        dv.widthPx = dp(sizes[si]).toFloat()

        val drawParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(6), dp(4), dp(6), dp(4))
        val barBg = GradientDrawable()
        barBg.cornerRadius = dp(28).toFloat()
        barBg.setColor(0xF2141414.toInt())
        bar.background = barBg

        fun tool(label: String): TextView {
            val t = TextView(this)
            t.text = label
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.setTextColor(Color.WHITE)
            bar.addView(t, LinearLayout.LayoutParams(dp(44), dp(44)))
            return t
        }

        val grip = tool("⠿")
        val modeBtn = tool("✏️")
        val colorBtn = tool("●")
        val sizeBtn = tool("◉")
        val undoBtn = tool("↩")
        val clearBtn = tool("🗑")
        val closeBtn = tool("✕")

        colorBtn.setTextColor(palette[ci])
        colorBtn.setOnClickListener {
            ci = (ci + 1) % palette.size
            dv.color = palette[ci]
            colorBtn.setTextColor(palette[ci])
        }
        sizeBtn.textSize = 12f + si * 4f
        sizeBtn.setOnClickListener {
            si = (si + 1) % sizes.size
            dv.widthPx = dp(sizes[si]).toFloat()
            sizeBtn.textSize = 12f + si * 4f
        }
        undoBtn.setOnClickListener { dv.undo() }
        clearBtn.setOnClickListener { dv.clear() }
        closeBtn.setOnClickListener { closeAll() }
        modeBtn.setOnClickListener {
            drawing = !drawing
            val notTouchable = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            drawParams.flags = if (drawing) {
                drawParams.flags and notTouchable.inv()
            } else {
                drawParams.flags or notTouchable
            }
            try { wm.updateViewLayout(dv, drawParams) } catch (_: Exception) { }
            modeBtn.text = if (drawing) "✏️" else "✋"
        }

        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        barParams.gravity = Gravity.TOP or Gravity.START
        barParams.x = dp(8)
        barParams.y = dp(140)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = barParams.x
                    startY = barParams.y
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    barParams.x = startX + (e.rawX - touchX).toInt()
                    barParams.y = startY + (e.rawY - touchY).toInt()
                    try { wm.updateViewLayout(bar, barParams) } catch (_: Exception) { }
                }
            }
            true
        }

        wm.addView(dv, drawParams)
        wm.addView(bar, barParams)
        drawView = dv
        barView = bar
        running = true
    }

    private fun removeViews() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val a = drawView
        if (a != null) { try { wm.removeView(a) } catch (_: Exception) { } }
        val b = barView
        if (b != null) { try { wm.removeView(b) } catch (_: Exception) { } }
        drawView = null
        barView = null
    }

    private fun closeAll() {
        removeViews()
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        removeViews()
        running = false
        super.onDestroy()
    }
}
