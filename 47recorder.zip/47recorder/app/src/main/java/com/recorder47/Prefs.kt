package com.recorder47

import android.content.Context
import android.graphics.Color
import androidx.core.graphics.ColorUtils

object Prefs {
    val DEFAULT_COLOR = 0xFFE53935.toInt()
    const val DEFAULT_SIZE = 64      // dp
    const val DEFAULT_OPACITY = 85   // %

    private fun sp(c: Context) = c.getSharedPreferences("prefs47", Context.MODE_PRIVATE)

    // Botão 47 (círculo flutuante)
    fun size(c: Context) = sp(c).getInt("size", DEFAULT_SIZE)
    fun opacity(c: Context) = sp(c).getInt("opacity", DEFAULT_OPACITY)
    fun color(c: Context) = sp(c).getInt("color", DEFAULT_COLOR)
    fun orbText(c: Context) = sp(c).getString("orbText", "47") ?: "47"
    fun orbShape(c: Context) = sp(c).getInt("orbShape", 0)          // 0 círculo, 1 quadrado arredondado
    fun menuBg(c: Context) = sp(c).getInt("menuBg", 0xF2141414.toInt())
    fun showShot(c: Context) = sp(c).getBoolean("showShot", true)
    fun showDraw(c: Context) = sp(c).getBoolean("showDraw", true)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()
    fun setOpacity(c: Context, v: Int) = sp(c).edit().putInt("opacity", v).apply()
    fun setColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()
    fun setOrbText(c: Context, v: String) = sp(c).edit().putString("orbText", v).apply()
    fun setOrbShape(c: Context, v: Int) = sp(c).edit().putInt("orbShape", v).apply()
    fun setMenuBg(c: Context, v: Int) = sp(c).edit().putInt("menuBg", v).apply()
    fun setShowShot(c: Context, v: Boolean) = sp(c).edit().putBoolean("showShot", v).apply()
    fun setShowDraw(c: Context, v: Boolean) = sp(c).edit().putBoolean("showDraw", v).apply()
    fun resetOrb(c: Context) {
        sp(c).edit().remove("size").remove("opacity").remove("color").remove("orbText")
            .remove("orbShape").remove("menuBg").remove("showShot").remove("showDraw").apply()
    }

    // Vídeo
    fun resolution(c: Context) = sp(c).getInt("res", 720)
    fun bitrate(c: Context) = sp(c).getInt("bitrate", 5)
    fun fps(c: Context) = sp(c).getInt("fps", 30)
    fun setResolution(c: Context, v: Int) = sp(c).edit().putInt("res", v).apply()
    fun setBitrate(c: Context, v: Int) = sp(c).edit().putInt("bitrate", v).apply()
    fun setFps(c: Context, v: Int) = sp(c).edit().putInt("fps", v).apply()

    // Opções gerais
    fun mic(c: Context) = sp(c).getBoolean("mic", false)
    fun internal(c: Context) = sp(c).getBoolean("internal", true)
    fun clean(c: Context) = sp(c).getBoolean("clean", false)
    fun facecam(c: Context) = sp(c).getBoolean("facecam", false)
    fun setMic(c: Context, v: Boolean) = sp(c).edit().putBoolean("mic", v).apply()
    fun setInternal(c: Context, v: Boolean) = sp(c).edit().putBoolean("internal", v).apply()
    fun setClean(c: Context, v: Boolean) = sp(c).edit().putBoolean("clean", v).apply()
    fun setFacecam(c: Context, v: Boolean) = sp(c).edit().putBoolean("facecam", v).apply()

    // Assinatura (marca d'água)
    fun watermark(c: Context) = sp(c).getBoolean("wm", false)
    fun wmText(c: Context) = sp(c).getString("wmText", "47 Recorder") ?: "47 Recorder"
    fun wmPos(c: Context) = sp(c).getInt("wmPos", 3)
    fun setWatermark(c: Context, v: Boolean) = sp(c).edit().putBoolean("wm", v).apply()
    fun setWmText(c: Context, v: String) = sp(c).edit().putString("wmText", v).apply()
    fun setWmPos(c: Context, v: Int) = sp(c).edit().putInt("wmPos", v).apply()

    // Voltar no tempo (replay)
    fun replaySec(c: Context) = sp(c).getInt("replaySec", 30)
    fun setReplaySec(c: Context, v: Int) = sp(c).edit().putInt("replaySec", v).apply()

    // 47 Voice Rec Mode
    fun voiceFmt(c: Context) = sp(c).getInt("voiceFmt", 0)          // 0 M4A, 1 OGG, 2 3GP, 3 WAV
    fun voiceKbps(c: Context) = sp(c).getInt("voiceKbps", 128)
    fun setVoiceFmt(c: Context, v: Int) = sp(c).edit().putInt("voiceFmt", v).apply()
    fun setVoiceKbps(c: Context, v: Int) = sp(c).edit().putInt("voiceKbps", v).apply()

    // Estabilidade
    fun startOnBoot(c: Context) = sp(c).getBoolean("boot", false)
    fun setStartOnBoot(c: Context, v: Boolean) = sp(c).edit().putBoolean("boot", v).apply()

    // Aparência do app
    fun uiAccent(c: Context) = sp(c).getInt("uiAccent", 0xFFE53935.toInt())
    fun uiBg(c: Context) = sp(c).getInt("uiBg", 0xFF0E0E0E.toInt())
    fun uiRadius(c: Context) = sp(c).getInt("uiRadius", 16)
    fun uiScale(c: Context) = sp(c).getInt("uiScale", 1)            // 0 pequeno, 1 normal, 2 grande
    fun setUiAccent(c: Context, v: Int) = sp(c).edit().putInt("uiAccent", v).apply()
    fun setUiBg(c: Context, v: Int) = sp(c).edit().putInt("uiBg", v).apply()
    fun setUiRadius(c: Context, v: Int) = sp(c).edit().putInt("uiRadius", v).apply()
    fun setUiScale(c: Context, v: Int) = sp(c).edit().putInt("uiScale", v).apply()
    fun resetUi(c: Context) {
        sp(c).edit().remove("uiAccent").remove("uiBg").remove("uiRadius").remove("uiScale").apply()
    }

    // 47 Art Mode: cores recentes (lista separada por vírgula)
    fun artRecent(c: Context): String = sp(c).getString("artRecent", "") ?: ""
    fun setArtRecent(c: Context, v: String) = sp(c).edit().putString("artRecent", v).apply()

    /** Preto ou branco, conforme o que fica legível sobre a cor. */
    fun contrast(color: Int): Int =
        if (ColorUtils.calculateLuminance(color) > 0.6) Color.BLACK else Color.WHITE
}
