package com.recorder47

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View

/** Roda de cores: anel para o matiz e quadrado para saturação e brilho. */
class ColorWheelView(ctx: Context) : View(ctx) {

    var onColor: ((Int) -> Unit)? = null

    private var hue = 0f
    private var sat = 1f
    private var value = 1f
    private var cx = 0f
    private var cy = 0f
    private var outerR = 0f
    private var innerR = 0f
    private var ringW = 0f
    private var half = 0f
    private var drag = 0   // 0 nenhum, 1 anel, 2 quadrado

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sqPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setColor(c: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hue = hsv[0]
        sat = hsv[1]
        value = hsv[2]
        rebuildSquare()
        invalidate()
    }

    fun getColor(): Int = Color.HSVToColor(floatArrayOf(hue, sat, value))

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        cy = h / 2f
        outerR = minOf(w, h) / 2f - 8f
        ringW = outerR * 0.22f
        innerR = outerR - ringW
        half = innerR * 0.68f
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = ringW
        ringPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            ),
            null
        )
        rebuildSquare()
    }

    private fun rebuildSquare() {
        if (half <= 0f) return
        val pure = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        val l = cx - half
        val t = cy - half
        val r = cx + half
        val b = cy + half
        val satShader = LinearGradient(l, t, r, t, 0xFFFFFFFF.toInt(), pure, Shader.TileMode.CLAMP)
        val valShader = LinearGradient(l, t, l, b, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP)
        sqPaint.shader = ComposeShader(valShader, satShader, PorterDuff.Mode.MULTIPLY)
    }

    override fun onDraw(canvas: Canvas) {
        if (half <= 0f) return
        canvas.drawCircle(cx, cy, outerR - ringW / 2f, ringPaint)
        canvas.drawRect(cx - half, cy - half, cx + half, cy + half, sqPaint)

        // marcador do matiz
        val a = Math.toRadians(hue.toDouble())
        val rr = innerR + ringW / 2f
        val hx = cx + (Math.cos(a) * rr).toFloat()
        val hy = cy + (Math.sin(a) * rr).toFloat()
        markPaint.style = Paint.Style.STROKE
        markPaint.strokeWidth = 5f
        markPaint.color = 0xFF000000.toInt()
        canvas.drawCircle(hx, hy, ringW * 0.42f, markPaint)
        markPaint.strokeWidth = 2.5f
        markPaint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(hx, hy, ringW * 0.42f, markPaint)

        // marcador de saturação/brilho
        val sx = cx - half + sat * 2f * half
        val sy = cy - half + (1f - value) * 2f * half
        markPaint.strokeWidth = 5f
        markPaint.color = 0xFF000000.toInt()
        canvas.drawCircle(sx, sy, 14f, markPaint)
        markPaint.strokeWidth = 2.5f
        markPaint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(sx, sy, 14f, markPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dx = x - cx
                val dy = y - cy
                val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                drag = if (dist >= innerR - 4f && dist <= outerR + 12f) {
                    1
                } else if (Math.abs(dx) <= half + 14f && Math.abs(dy) <= half + 14f) {
                    2
                } else {
                    0
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                applyTouch(x, y)
            }
            MotionEvent.ACTION_MOVE -> applyTouch(x, y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = 0
        }
        return true
    }

    private fun applyTouch(x: Float, y: Float) {
        if (drag == 1) {
            var deg = Math.toDegrees(Math.atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()
            if (deg < 0f) deg += 360f
            hue = if (deg >= 360f) 359.9f else deg
            rebuildSquare()
        } else if (drag == 2) {
            sat = ((x - (cx - half)) / (2f * half)).coerceIn(0f, 1f)
            value = (1f - (y - (cy - half)) / (2f * half)).coerceIn(0f, 1f)
        } else {
            return
        }
        invalidate()
        onColor?.invoke(getColor())
    }
}
