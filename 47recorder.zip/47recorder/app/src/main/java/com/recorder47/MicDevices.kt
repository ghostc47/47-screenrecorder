package com.recorder47

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord

/**
 * Lista e aplica o microfone de entrada preferido (celular, fone, Bluetooth, USB…).
 */
object MicDevices {

    data class Entry(val id: Int, val type: Int, val label: String)

    fun listInputs(ctx: Context): List<Entry> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val out = ArrayList<Entry>()
        try {
            val devices = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            for (d in devices) {
                if (!d.isSource) continue
                // Ignora fontes que não são microfone de usuário
                if (d.type == AudioDeviceInfo.TYPE_TELEPHONY) continue
                val label = labelFor(d)
                out.add(Entry(d.id, d.type, label))
            }
        } catch (_: Exception) { }
        // Ordena: embutido, fone, BT, USB, resto
        return out.sortedWith(compareBy({ typeRank(it.type) }, { it.label }))
    }

    fun labelFor(d: AudioDeviceInfo): String {
        val base = typeName(d.type)
        val prod = try {
            d.productName?.toString()?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
        return if (prod.isNotEmpty() && !prod.equals(base, ignoreCase = true)) {
            "$base · $prod"
        } else {
            base
        }
    }

    fun typeName(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Microfone do celular"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Fone com fio (microfone)"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Fone com fio"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (fone/headset)"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE (headset)"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "Fone USB"
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> "Acessório USB"
        AudioDeviceInfo.TYPE_HDMI -> "HDMI"
        AudioDeviceInfo.TYPE_REMOTE_SUBMIX -> "Submix do sistema"
        else -> "Microfone ($type)"
    }

    private fun typeRank(type: Int): Int = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> 0
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 1
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY -> 2
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> 3
        else -> 9
    }

    /** Nome curto da preferência salva (para a linha de ajustes). */
    fun preferredLabel(ctx: Context): String {
        val id = Prefs.micDeviceId(ctx)
        if (id < 0) return "Automático"
        val type = Prefs.micDeviceType(ctx)
        for (e in listInputs(ctx)) {
            if (e.id == id) return e.label
        }
        // Dispositivo desconectado: mostra pelo tipo
        if (type != 0) return typeName(type) + " (ausente)"
        return "Automático"
    }

    /**
     * Aplica o dispositivo preferido no AudioRecord.
     * @return true se conseguiu fixar um dispositivo (ou se está em automático).
     */
    fun applyPreferred(ctx: Context, record: AudioRecord): Boolean {
        val wantId = Prefs.micDeviceId(ctx)
        val wantType = Prefs.micDeviceType(ctx)
        if (wantId < 0 && wantType == 0) return true // automático

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            val devices = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            var match: AudioDeviceInfo? = null
            // 1) id exato
            if (wantId >= 0) {
                match = devices.firstOrNull { it.isSource && it.id == wantId }
            }
            // 2) mesmo tipo (fone reconectou com outro id)
            if (match == null && wantType != 0) {
                match = devices.firstOrNull { it.isSource && it.type == wantType }
            }
            if (match != null) {
                return record.setPreferredDevice(match)
            }
        } catch (_: Exception) { }
        return false
    }
}
