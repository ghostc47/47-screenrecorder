package com.recorder47

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Projetos do 47 Art Mode ficam em filesDir/art/<id>/ (uma imagem PNG por camada + meta.json). */
object ArtStore {

    class Info(
        val id: String, val name: String, val updated: Long,
        val w: Int, val h: Int, val layers: Int, val thumb: File
    )

    class Loaded(
        val w: Int, val h: Int, val bg: Int, val cur: Int,
        val layers: ArrayList<ArtCanvas.Layer>
    )

    private val exec: ExecutorService = Executors.newSingleThreadExecutor()

    private val defaultPalette = listOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFE53935.toInt(), 0xFFFB8C00.toInt(),
        0xFFFDD835.toInt(), 0xFF43A047.toInt(), 0xFF00ACC1.toInt(), 0xFF1E88E5.toInt(),
        0xFF8E24AA.toInt(), 0xFFEC407A.toInt(), 0xFF795548.toInt(), 0xFF9E9E9E.toInt()
    )

    fun root(ctx: Context): File {
        val d = File(ctx.filesDir, "art")
        d.mkdirs()
        return d
    }

    fun projDir(ctx: Context, id: String): File {
        val d = File(root(ctx), id)
        d.mkdirs()
        return d
    }

    fun newId(): String = "p" + System.currentTimeMillis()

    fun list(ctx: Context): List<Info> {
        val out = ArrayList<Info>()
        val dirs = root(ctx).listFiles() ?: return out
        for (d in dirs) {
            if (!d.isDirectory) continue
            val mf = File(d, "meta.json")
            if (!mf.exists()) continue
            try {
                val o = JSONObject(mf.readText())
                out.add(
                    Info(
                        d.name, o.optString("name", "Desenho"), o.optLong("updated", 0L),
                        o.optInt("w", 0), o.optInt("h", 0),
                        o.getJSONArray("layers").length(), File(d, "thumb.jpg")
                    )
                )
            } catch (_: Exception) { }
        }
        out.sortByDescending { it.updated }
        return out
    }

    fun rename(ctx: Context, id: String, name: String) {
        try {
            val mf = File(File(root(ctx), id), "meta.json")
            if (!mf.exists()) return
            val o = JSONObject(mf.readText())
            o.put("name", name)
            mf.writeText(o.toString())
        } catch (_: Exception) { }
    }

    /** Copia um desenho (sem os quadros do timelapse). Devolve o id da cópia. */
    fun duplicate(ctx: Context, id: String): String? {
        return try {
            val src = File(root(ctx), id)
            if (!src.isDirectory) return null
            val nid = newId()
            val dst = File(root(ctx), nid)
            dst.mkdirs()
            for (f in src.listFiles() ?: emptyArray()) {
                if (f.isFile) f.copyTo(File(dst, f.name), overwrite = true)
            }
            val mf = File(dst, "meta.json")
            if (mf.exists()) {
                val o = JSONObject(mf.readText())
                o.put("name", "Cópia de " + o.optString("name", "Desenho"))
                o.put("updated", System.currentTimeMillis())
                mf.writeText(o.toString())
            }
            nid
        } catch (_: Exception) { null }
    }

    fun delete(ctx: Context, id: String) {
        val d = File(root(ctx), id)
        d.deleteRecursively()
    }

    /** Grava em segundo plano. As camadas já chegam copiadas, então o desenho pode continuar. */
    fun save(
        ctx: Context, id: String, w: Int, h: Int, bg: Int, cur: Int,
        layers: List<ArtCanvas.SaveLayer>, thumb: Bitmap?
    ) {
        exec.execute {
            try {
                val dir = projDir(ctx, id)
                val keep = HashSet<String>()
                val arr = JSONArray()
                for (l in layers) {
                    val fn = "layer_${l.uid}.png"
                    keep.add(fn)
                    val bc = l.bmpCopy
                    if (bc != null) {
                        FileOutputStream(File(dir, fn)).use { bc.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        bc.recycle()
                    }
                    val o = JSONObject()
                    o.put("uid", l.uid)
                    o.put("name", l.name)
                    o.put("vis", l.visible)
                    o.put("op", l.opacity)
                    o.put("bl", l.blend)
                    o.put("al", l.alphaLock)
                    o.put("clip", l.clipping)
                    o.put("lk", l.locked)
                    arr.put(o)
                }
                val files = dir.listFiles()
                if (files != null) {
                    for (f in files) {
                        if (f.name.startsWith("layer_") && !keep.contains(f.name)) f.delete()
                    }
                }
                if (thumb != null) {
                    FileOutputStream(File(dir, "thumb.jpg")).use { thumb.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                    thumb.recycle()
                }
                val mf = File(dir, "meta.json")
                var name = ""
                if (mf.exists()) {
                    try { name = JSONObject(mf.readText()).optString("name", "") } catch (_: Exception) { }
                }
                if (name.isEmpty()) {
                    name = "Desenho " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
                }
                val meta = JSONObject()
                meta.put("w", w)
                meta.put("h", h)
                meta.put("bg", bg)
                meta.put("cur", cur)
                meta.put("name", name)
                meta.put("updated", System.currentTimeMillis())
                meta.put("layers", arr)
                mf.writeText(meta.toString())
            } catch (_: Exception) { }
        }
    }

    fun load(ctx: Context, id: String): Loaded? {
        try {
            val dir = File(root(ctx), id)
            val mf = File(dir, "meta.json")
            if (!mf.exists()) return null
            val meta = JSONObject(mf.readText())
            val w = meta.getInt("w")
            val h = meta.getInt("h")
            val bg = meta.optInt("bg", 0xFFFFFFFF.toInt())
            val cur = meta.optInt("cur", 0)
            val arr = meta.getJSONArray("layers")
            val list = ArrayList<ArtCanvas.Layer>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val uid = o.getInt("uid")
                val f = File(dir, "layer_$uid.png")
                var decoded: Bitmap? = null
                if (f.exists()) {
                    val opt = BitmapFactory.Options()
                    opt.inMutable = true
                    opt.inPreferredConfig = Bitmap.Config.ARGB_8888
                    decoded = BitmapFactory.decodeFile(f.path, opt)
                }
                val b: Bitmap = if (decoded != null && decoded.width == w && decoded.height == h) {
                    decoded
                } else {
                    Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                }
                val l = ArtCanvas.Layer(b, o.optBoolean("vis", true), o.optString("name", "Camada"), uid)
                l.opacity = o.optInt("op", 255)
                l.blend = o.optInt("bl", 0)
                l.alphaLock = o.optBoolean("al", false)
                l.clipping = o.optBoolean("clip", false)
                l.locked = o.optBoolean("lk", false)
                l.dirty = false
                list.add(l)
            }
            if (list.isEmpty()) return null
            return Loaded(w, h, bg, cur.coerceIn(0, list.size - 1), list)
        } catch (e: Exception) {
            return null
        }
    }

    // ------------------------------------------------------------- paleta
    fun palette(ctx: Context): List<Int> {
        val s = ctx.getSharedPreferences("art47", Context.MODE_PRIVATE).getString("palette", "") ?: ""
        if (s.isEmpty()) return defaultPalette
        val out = ArrayList<Int>()
        for (part in s.split(",")) {
            val v = part.toIntOrNull()
            if (v != null) out.add(v)
        }
        return if (out.isEmpty()) defaultPalette else out
    }

    fun addPalette(ctx: Context, color: Int) {
        val cur = ArrayList<Int>(palette(ctx))
        cur.remove(color)
        cur.add(0, color)
        while (cur.size > 24) cur.removeAt(cur.size - 1)
        ctx.getSharedPreferences("art47", Context.MODE_PRIVATE)
            .edit().putString("palette", cur.joinToString(",")).apply()
    }
}
