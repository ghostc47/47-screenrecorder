package com.recorder47

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Cores do estúdio do 47 Art Mode. */
object AU {
    val bg = 0xFF0E0E12.toInt()
    val glass = 0xEB17171D.toInt()
    val glassLine = 0x2EFFFFFF
    val sheet = 0xFF18181E.toInt()
    val surface = 0xFF23232B.toInt()
    val surface2 = 0xFF2D2D37.toInt()
    val text = 0xFFF4F4F7.toInt()
    val sub = 0xFF9A9AA8.toInt()
    val accent: Int get() = Ui.accent
    fun accentSoft(): Int = (Ui.accent and 0x00FFFFFF) or 0x2E000000
}

/** Ferramentas visuais: tamanhos, fundos arredondados, ícones vetoriais. */
class Kit(val ctx: Context) {
    private val d = ctx.resources.displayMetrics.density

    fun dp(v: Int) = (v * d).toInt()
    fun dpf(v: Float) = v * d

    fun round(color: Int, rDp: Int, line: Int = 0, lineDp: Float = 0f): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dpf(rDp.toFloat())
        g.setColor(color)
        if (line != 0) g.setStroke(maxOf(1, (lineDp * d).toInt()), line)
        return g
    }

    fun glass(rDp: Int = 26): GradientDrawable = round(AU.glass, rDp, AU.glassLine, 1f)

    fun oval(color: Int, line: Int = 0, lineDp: Float = 0f): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        if (line != 0) g.setStroke(maxOf(1, (lineDp * d).toInt()), line)
        return g
    }

    fun iconRes(name: String): Int = ctx.resources.getIdentifier("ic_a_$name", "drawable", ctx.packageName)

    fun icon(name: String, tint: Int = AU.text): ImageView {
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        val id = iconRes(name)
        if (id != 0) iv.setImageResource(id)
        iv.imageTintList = ColorStateList.valueOf(tint)
        return iv
    }

    fun drawable(name: String, tint: Int = Color.WHITE): Drawable? {
        val id = iconRes(name)
        if (id == 0) return null
        val dr = ctx.getDrawable(id)?.mutate() ?: return null
        dr.setTint(tint)
        return dr
    }

    fun text(t: String, sp: Float, color: Int = AU.text, bold: Boolean = false): TextView {
        val tv = TextView(ctx)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    /** Clique com animação de toque. */
    fun press(v: View, action: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener {
            v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(50).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                action()
            }.start()
        }
    }

    fun clipRound(v: View, rDp: Int) {
        val r = dpf(rDp.toFloat())
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    /** Fundo xadrez (indica transparência). */
    fun checker(): Drawable {
        val s = 8
        val bmp = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.color = 0xFFC9C9D1.toInt()
        c.drawRect(0f, 0f, s * 2f, s * 2f, p)
        p.color = 0xFFE6E6EB.toInt()
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        val bd = BitmapDrawable(ctx.resources, bmp)
        bd.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        return bd
    }

    fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    /** Botão com ícone e texto. */
    fun button(label: String, iconName: String?, primary: Boolean, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(dp(16), dp(13), dp(16), dp(13))
        row.background = if (primary)
            Ui.gradientButton(Ui.lighten(Ui.accent, 0.12f), Ui.darken(Ui.accent, 0.12f), dpf(22f))
        else round(AU.surface2, 22)
        if (iconName != null) {
            row.addView(icon(iconName, AU.text), LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) })
        }
        row.addView(text(label, 14f, AU.text, true))
        press(row, onClick)
        return row
    }

    /** Chips lado a lado (um selecionado). */
    fun segmented(labels: List<String>, selected: Int, sp: Float = 12f, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.background = round(AU.surface, 16)
        row.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (i in labels.indices) {
            val on = i == selected
            val t = text(labels[i], sp, if (on) Color.WHITE else AU.sub, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setPadding(dp(2), dp(9), dp(2), dp(9))
            t.background = if (on) round(Ui.accent, 12) else null
            t.setOnClickListener { onSelect(i) }
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }
}

/** Slider próprio: vertical (nas bordas da tela) ou horizontal (nos painéis). */
class ArtSlider(ctx: Context, private val vertical: Boolean, private val side: Int = 0) : View(ctx) {

    var min = 0
    var max = 100
    var value = 0
        set(v) {
            field = v.coerceIn(min, max)
            invalidate()
        }
    var onChange: ((Int) -> Unit)? = null
    var onFinish: (() -> Unit)? = null
    var fmt: (Int) -> String = { it.toString() }
    var icon: Drawable? = null

    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pill = RectF()
    private val tmp = RectF()
    private val clip = Path()
    private var dragging = false

    init {
        textPaint.color = Color.WHITE
        textPaint.textSize = 13f * d
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textAlign = Paint.Align.CENTER
    }

    private fun frac(): Float = if (max > min) (value - min).toFloat() / (max - min) else 0f

    override fun onDraw(c: Canvas) {
        if (vertical) drawVertical(c) else drawHorizontal(c)
    }

    private fun layoutPill() {
        val pw = 40f * d
        val l = if (side == 0) 0f else width - pw
        pill.set(l, 0f, l + pw, height.toFloat())
    }

    private fun drawVertical(c: Canvas) {
        layoutPill()
        val r = pill.width() / 2f
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = AU.glass
        c.drawRoundRect(pill, r, r, paint)

        val f = frac()
        val top = pill.bottom - pill.height() * f
        clip.reset()
        clip.addRoundRect(pill, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        paint.shader = LinearGradient(
            0f, pill.top, 0f, pill.bottom,
            Ui.lighten(Ui.accent, 0.12f), Ui.darken(Ui.accent, 0.12f), Shader.TileMode.CLAMP
        )
        c.drawRect(pill.left, top, pill.right, pill.bottom, paint)
        paint.shader = null
        c.restore()

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f * d
        paint.color = AU.glassLine
        c.drawRoundRect(pill, r, r, paint)

        // marcador
        val cy = top.coerceIn(pill.top + 8f * d, pill.bottom - 8f * d)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * d
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.WHITE
        c.drawLine(pill.centerX() - 8f * d, cy, pill.centerX() + 8f * d, cy, paint)

        icon?.let {
            val s = (18f * d).toInt()
            val cx = pill.centerX().toInt()
            val iy = (pill.bottom - 22f * d).toInt()
            it.setBounds(cx - s / 2, iy - s / 2, cx + s / 2, iy + s / 2)
            it.draw(c)
        }

        if (dragging) {
            val label = fmt(value)
            val tw = textPaint.measureText(label)
            val bw = tw + 22f * d
            val bh = 32f * d
            val by = cy.coerceIn(bh / 2f, height - bh / 2f)
            if (side == 0) tmp.set(pill.right + 10f * d, by - bh / 2f, pill.right + 10f * d + bw, by + bh / 2f)
            else tmp.set(pill.left - 10f * d - bw, by - bh / 2f, pill.left - 10f * d, by + bh / 2f)
            paint.style = Paint.Style.FILL
            paint.color = 0xF0000000.toInt()
            c.drawRoundRect(tmp, bh / 2f, bh / 2f, paint)
            c.drawText(label, tmp.centerX(), tmp.centerY() + 4.5f * d, textPaint)
        }
    }

    private fun drawHorizontal(c: Canvas) {
        val pad = 12f * d
        val cy = height / 2f
        val th = 6f * d
        tmp.set(pad, cy - th / 2f, width - pad, cy + th / 2f)
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = 0x33FFFFFF
        c.drawRoundRect(tmp, th / 2f, th / 2f, paint)

        val x = pad + (width - 2 * pad) * frac()
        tmp.set(pad, cy - th / 2f, x, cy + th / 2f)
        paint.color = Ui.accent
        c.drawRoundRect(tmp, th / 2f, th / 2f, paint)

        paint.color = Color.WHITE
        c.drawCircle(x, cy, 10f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * d
        paint.color = Ui.accent
        c.drawCircle(x, cy, 8.5f * d, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (vertical) {
                    layoutPill()
                    val slop = 8f * d
                    if (e.x < pill.left - slop || e.x > pill.right + slop) return false
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                update(e)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) update(e)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    invalidate()
                    onFinish?.invoke()
                }
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun update(e: MotionEvent) {
        val f: Float = if (vertical) {
            val pad = 8f * d
            1f - (e.y - pad) / (height - 2f * pad)
        } else {
            val pad = 12f * d
            (e.x - pad) / (width - 2f * pad)
        }
        val nv = min + Math.round(f.coerceIn(0f, 1f) * (max - min))
        if (nv != value) {
            value = nv
            onChange?.invoke(nv)
        } else {
            invalidate()
        }
    }
}

/** Pré-visualização do traço do pincel (tamanho, opacidade, dureza e cor). */
class BrushPreview(ctx: Context) : View(ctx) {
    var color = Color.BLACK
    var size = 12f
    var opacity = 255
    var hardness = 70

    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val clip = Path()
    private val rect = RectF()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 18f * d
        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFEDEDF1.toInt()
        c.drawRect(0f, 0f, w / 2f, h, paint)
        paint.color = 0xFF1D1D23.toInt()
        c.drawRect(w / 2f, 0f, w, h, paint)

        path.reset()
        val pad = 28f * d
        val amp = h * 0.2f
        path.moveTo(pad, h / 2f)
        val steps = 48
        for (i in 1..steps) {
            val t = i / steps.toFloat()
            val x = pad + (w - 2 * pad) * t
            val y = h / 2f + Math.sin(t * Math.PI * 2.0).toFloat() * amp
            path.lineTo(x, y)
        }
        val sw = 2f * d + (size.coerceIn(1f, 200f) / 200f) * 30f * d
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = color or 0xFF000000.toInt()
        paint.alpha = opacity.coerceIn(1, 255)
        val soft = (100 - hardness.coerceIn(0, 100)) / 100f
        paint.maskFilter = if (soft > 0.05f) BlurMaskFilter(soft * sw * 0.5f + 0.5f, BlurMaskFilter.Blur.NORMAL) else null
        c.drawPath(path, paint)
        paint.maskFilter = null
        c.restore()
    }
}

/** ScrollView que não passa de uma altura máxima. */
private class CappedScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Painel que sobe da parte de baixo da tela. */
class ArtSheet(act: Activity, private val kit: Kit, title: String?) {
    private val dialog = Dialog(act)
    val pinned = LinearLayout(act)
    val body = LinearLayout(act)
    val footer = LinearLayout(act)
    var onDismiss: (() -> Unit)? = null
    private val panel = LinearLayout(act)
    private var closing = false

    val isShowing: Boolean get() = dialog.isShowing

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val dm = act.resources.displayMetrics
        val maxW = minOf(dm.widthPixels, kit.dp(560))
        val landscape = dm.widthPixels > dm.heightPixels
        val maxH = (dm.heightPixels * (if (landscape) 0.92f else 0.84f)).toInt()

        val scrim = FrameLayout(act)
        scrim.setOnClickListener { dismiss(true) }

        val r = kit.dpf(26f)
        val bg = GradientDrawable()
        bg.setColor(AU.sheet)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(kit.dp(1), AU.glassLine)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = bg
        panel.isClickable = true
        panel.setPadding(kit.dp(16), kit.dp(8), kit.dp(16), kit.dp(14))
        panel.elevation = kit.dpf(16f)

        val handle = View(act)
        handle.background = kit.round(0x44FFFFFF, 3)
        panel.addView(handle, LinearLayout.LayoutParams(kit.dp(40), kit.dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = kit.dp(8)
        })

        if (title != null) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(kit.text(title, 18f, AU.text, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val close = FrameLayout(act)
            close.background = kit.oval(AU.surface)
            close.addView(kit.icon("close", AU.sub), FrameLayout.LayoutParams(kit.dp(16), kit.dp(16), Gravity.CENTER))
            close.setOnClickListener { dismiss(true) }
            row.addView(close, LinearLayout.LayoutParams(kit.dp(32), kit.dp(32)))
            panel.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = kit.dp(10)
            })
        }

        pinned.orientation = LinearLayout.VERTICAL
        panel.addView(pinned, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        body.orientation = LinearLayout.VERTICAL
        val sv = CappedScroll(act, maxH - kit.dp(190))
        sv.isVerticalScrollBarEnabled = false
        sv.addView(body, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        panel.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        footer.orientation = LinearLayout.VERTICAL
        footer.setPadding(0, kit.dp(10), 0, 0)
        panel.addView(footer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        scrim.addView(panel, FrameLayout.LayoutParams(maxW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        dialog.setContentView(scrim)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.setDimAmount(0.55f)
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            w.navigationBarColor = AU.sheet
        }
        dialog.setOnDismissListener { onDismiss?.invoke() }
    }

    fun show() {
        panel.visibility = View.INVISIBLE
        dialog.show()
        panel.post {
            panel.translationY = panel.height.toFloat()
            panel.visibility = View.VISIBLE
            panel.animate().translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    fun dismiss(animated: Boolean = true) {
        if (closing || !dialog.isShowing) return
        if (!animated) {
            closing = true
            try { dialog.dismiss() } catch (_: Exception) { }
            return
        }
        closing = true
        panel.animate().translationY(panel.height.toFloat()).setDuration(170).withEndAction {
            try { dialog.dismiss() } catch (_: Exception) { }
        }.start()
    }
}

/** Favoritos de pincel e cores recentes (guardados no aparelho). */
object ArtPrefs {
    class Preset(
        val tool: Int, val size: Int, val opacity: Int, val hardness: Int,
        val flow: Int, val spacing: Int, val stab: Int
    )

    private fun sp(c: Context) = c.getSharedPreferences("art_ui", Context.MODE_PRIVATE)

    fun recents(c: Context): List<Int> {
        val s = sp(c).getString("recent", "") ?: ""
        val out = ArrayList<Int>()
        for (p in s.split(",")) {
            val v = p.toLongOrNull() ?: continue
            out.add(v.toInt())
        }
        return out
    }

    fun pushRecent(c: Context, color: Int) {
        val opaque = color or 0xFF000000.toInt()
        val l = ArrayList(recents(c))
        l.remove(opaque)
        l.add(0, opaque)
        while (l.size > 14) l.removeAt(l.size - 1)
        sp(c).edit().putString("recent", l.joinToString(",") { (it.toLong() and 0xFFFFFFFFL).toString() }).apply()
    }

    fun presets(c: Context): List<Preset> {
        val s = sp(c).getString("presets", "") ?: ""
        val out = ArrayList<Preset>()
        for (item in s.split(";")) {
            val a = item.split("|")
            if (a.size < 7) continue
            try {
                out.add(Preset(a[0].toInt(), a[1].toInt(), a[2].toInt(), a[3].toInt(), a[4].toInt(), a[5].toInt(), a[6].toInt()))
            } catch (_: Exception) { }
        }
        return out
    }

    private fun savePresets(c: Context, l: List<Preset>) {
        sp(c).edit().putString("presets", l.joinToString(";") {
            "${it.tool}|${it.size}|${it.opacity}|${it.hardness}|${it.flow}|${it.spacing}|${it.stab}"
        }).apply()
    }

    fun addPreset(c: Context, p: Preset) {
        val l = ArrayList(presets(c))
        l.add(0, p)
        while (l.size > 10) l.removeAt(l.size - 1)
        savePresets(c, l)
    }

    fun removePreset(c: Context, index: Int) {
        val l = ArrayList(presets(c))
        if (index in l.indices) {
            l.removeAt(index)
            savePresets(c, l)
        }
    }
}
