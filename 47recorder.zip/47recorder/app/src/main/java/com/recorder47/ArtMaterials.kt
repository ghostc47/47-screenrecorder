package com.recorder47

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Biblioteca de materiais/texturas estilo Ibis Paint.
 * - Embutidos: gerados proceduralmente
 * - Do usuário: PNG em filesDir/art_materials/
 */
object ArtMaterials {

    data class Mat(
        val id: String,
        val name: String,
        val builtin: Boolean,
        /** Gera ou carrega o bitmap em tons de cinza/alpha (branco = tinta). */
        val loader: (Context, Int) -> Bitmap
    )

    private const val SIZE = 128

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "art_materials")
        d.mkdirs()
        return d
    }

    /** Lista completa: embutidos + importados. */
    fun all(ctx: Context): List<Mat> {
        val out = ArrayList(builtins)
        val files = dir(ctx).listFiles() ?: return out
        for (f in files) {
            if (!f.isFile) continue
            if (!f.name.endsWith(".png", true) && !f.name.endsWith(".jpg", true)) continue
            val id = f.nameWithoutExtension
            val name = id.replace('_', ' ')
            out.add(
                Mat(id, name, false) { _, size ->
                    decodeScaled(f, size) ?: solid(size, Color.WHITE)
                }
            )
        }
        return out
    }

    fun find(ctx: Context, id: String): Mat? = all(ctx).firstOrNull { it.id == id }

    fun load(ctx: Context, id: String, size: Int = SIZE): Bitmap {
        val m = find(ctx, id) ?: return solid(size, Color.WHITE)
        return try {
            m.loader(ctx, size.coerceIn(32, 512))
        } catch (_: Exception) {
            solid(size, Color.WHITE)
        }
    }

    /** Importa bitmap como material. Devolve o id. */
    fun importBitmap(ctx: Context, src: Bitmap, name: String? = null): String {
        val id = "u_" + UUID.randomUUID().toString().take(8)
        val label = (name ?: "Material").trim().ifEmpty { "Material" }
        val file = File(dir(ctx), "$id.png")
        // Miniatura quadrada max 256
        val side = minOf(256, maxOf(src.width, src.height))
        val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val scale = side.toFloat() / maxOf(src.width, src.height)
        val dw = src.width * scale
        val dh = src.height * scale
        c.drawColor(Color.TRANSPARENT)
        c.drawBitmap(
            src,
            android.graphics.Rect(0, 0, src.width, src.height),
            android.graphics.RectF((side - dw) / 2f, (side - dh) / 2f, (side + dw) / 2f, (side + dh) / 2f),
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        )
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        // Guarda nome amigável
        File(dir(ctx), "$id.name").writeText(label)
        if (bmp !== src) bmp.recycle()
        return id
    }

    fun delete(ctx: Context, id: String) {
        if (id.startsWith("b_")) return // embutido
        File(dir(ctx), "$id.png").delete()
        File(dir(ctx), "$id.jpg").delete()
        File(dir(ctx), "$id.name").delete()
    }

    fun displayName(ctx: Context, id: String): String {
        val nf = File(dir(ctx), "$id.name")
        if (nf.exists()) return nf.readText().trim().ifEmpty { id }
        return find(ctx, id)?.name ?: id
    }

    // ------------------------------------------------------------------ embutidos
    val builtins: List<Mat> = listOf(
        Mat("b_noise", "Ruído", true) { _, s -> genNoise(s) },
        Mat("b_paper", "Papel", true) { _, s -> genPaper(s) },
        Mat("b_canvas", "Tela", true) { _, s -> genCanvas(s) },
        Mat("b_dots", "Pontos", true) { _, s -> genDots(s) },
        Mat("b_hatch", "Hachura", true) { _, s -> genHatch(s) },
        Mat("b_cross", "Cruzado", true) { _, s -> genCross(s) },
        Mat("b_cloud", "Nuvem", true) { _, s -> genCloud(s) },
        Mat("b_brick", "Tijolo", true) { _, s -> genBrick(s) },
        Mat("b_wood", "Madeira", true) { _, s -> genWood(s) },
        Mat("b_fabric", "Tecido", true) { _, s -> genFabric(s) },
        Mat("b_halftone", "Meio-tom", true) { _, s -> genHalftone(s) },
        Mat("b_grid", "Grade", true) { _, s -> genGrid(s) },
        Mat("b_stars", "Estrelas", true) { _, s -> genStars(s) },
        Mat("b_grunge", "Grunge", true) { _, s -> genGrunge(s) },
        Mat("b_ripple", "Ondas", true) { _, s -> genRipple(s) },
        Mat("b_sparkle", "Brilho", true) { _, s -> genSparkle(s) },
    )

    // --------------------------------------------------------------- geradores
    private fun solid(s: Int, color: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        Canvas(b).drawColor(color)
        return b
    }

    private fun decodeScaled(f: File, size: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (maxSide / sample > size * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = BitmapFactory.decodeFile(f.absolutePath, opts) ?: return null
        if (raw.width == size && raw.height == size) return raw
        val out = Bitmap.createScaledBitmap(raw, size, size, true)
        if (out !== raw) raw.recycle()
        return out
    }

    private fun genNoise(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val rnd = Random(42)
        val px = IntArray(s * s)
        for (i in px.indices) {
            val v = rnd.nextInt(256)
            px[i] = Color.argb(255, v, v, v)
        }
        b.setPixels(px, 0, s, 0, 0, s, s)
        return b
    }

    private fun genPaper(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val rnd = Random(7)
        val px = IntArray(s * s)
        for (i in px.indices) {
            val v = 200 + rnd.nextInt(40)
            px[i] = Color.argb(255, v, v, v - 5)
        }
        // fibras
        for (k in 0 until s * 3) {
            val x = rnd.nextInt(s)
            val y = rnd.nextInt(s)
            val len = 2 + rnd.nextInt(6)
            for (t in 0 until len) {
                val i = ((y * s + (x + t) % s))
                val v = 160 + rnd.nextInt(30)
                px[i] = Color.argb(255, v, v, v)
            }
        }
        b.setPixels(px, 0, s, 0, 0, s, s)
        return b
    }

    private fun genCanvas(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(210, 200, 180))
        val p = Paint()
        p.strokeWidth = 1f
        for (i in 0 until s step 4) {
            p.color = Color.argb(40, 80, 60, 40)
            c.drawLine(i.toFloat(), 0f, i.toFloat(), s.toFloat(), p)
            c.drawLine(0f, i.toFloat(), s.toFloat(), i.toFloat(), p)
            p.color = Color.argb(25, 255, 255, 255)
            c.drawLine((i + 2).toFloat(), 0f, (i + 2).toFloat(), s.toFloat(), p)
        }
        return b
    }

    private fun genDots(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val step = s / 8f
        var y = step / 2
        while (y < s) {
            var x = step / 2
            while (x < s) {
                c.drawCircle(x, y, step * 0.28f, p)
                x += step
            }
            y += step
        }
        return b
    }

    private fun genHatch(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.strokeWidth = 2f
        for (i in -s until s * 2 step 8) {
            c.drawLine(i.toFloat(), 0f, (i + s).toFloat(), s.toFloat(), p)
        }
        return b
    }

    private fun genCross(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.strokeWidth = 1.5f
        for (i in -s until s * 2 step 10) {
            c.drawLine(i.toFloat(), 0f, (i + s).toFloat(), s.toFloat(), p)
            c.drawLine(i.toFloat(), s.toFloat(), (i + s).toFloat(), 0f, p)
        }
        return b
    }

    private fun genCloud(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val rnd = Random(99)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 18) {
            val cx = rnd.nextFloat() * s
            val cy = rnd.nextFloat() * s
            val r = s * (0.12f + rnd.nextFloat() * 0.25f)
            p.shader = RadialGradient(
                cx, cy, r,
                intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0.2f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, r, p)
        }
        p.shader = null
        return b
    }

    private fun genBrick(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(160, 80, 60))
        val p = Paint()
        p.color = Color.rgb(90, 40, 30)
        p.strokeWidth = 2f
        val bh = s / 6f
        val bw = s / 3f
        var row = 0
        var y = 0f
        while (y < s) {
            val off = if (row % 2 == 0) 0f else bw / 2f
            var x = -bw + off
            while (x < s + bw) {
                c.drawRect(x, y, x + bw - 2f, y + bh - 2f, Paint().apply {
                    color = Color.rgb(170 + (row * 7) % 30, 90, 70)
                    style = Paint.Style.FILL
                })
                x += bw
            }
            y += bh
            row++
        }
        return b
    }

    private fun genWood(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val px = IntArray(s * s)
        val rnd = Random(3)
        for (y in 0 until s) {
            for (x in 0 until s) {
                val wave = sin((x + y * 0.15) * 0.15 + sin(y * 0.08) * 3).toFloat()
                val v = (140 + wave * 40 + rnd.nextInt(15)).toInt().coerceIn(60, 220)
                px[y * s + x] = Color.rgb(v, (v * 0.7).toInt(), (v * 0.4).toInt())
            }
        }
        b.setPixels(px, 0, s, 0, 0, s, s)
        return b
    }

    private fun genFabric(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(180, 180, 200))
        val p = Paint()
        p.strokeWidth = 1f
        for (i in 0 until s step 3) {
            p.color = Color.argb(50, 255, 255, 255)
            c.drawLine(i.toFloat(), 0f, i.toFloat(), s.toFloat(), p)
            p.color = Color.argb(40, 0, 0, 0)
            c.drawLine(0f, i.toFloat(), s.toFloat(), i.toFloat(), p)
        }
        return b
    }

    private fun genHalftone(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val step = s / 12f
        var y = step / 2
        var row = 0
        while (y < s) {
            var x = step / 2
            while (x < s) {
                val dist = sqrt(((x - s / 2f) * (x - s / 2f) + (y - s / 2f) * (y - s / 2f)).toDouble()).toFloat()
                val r = step * 0.15f + step * 0.35f * (1f - (dist / (s * 0.7f)).coerceIn(0f, 1f))
                c.drawCircle(x, y, r, p)
                x += step
            }
            y += step
            row++
        }
        return b
    }

    private fun genGrid(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint()
        p.color = Color.WHITE
        p.strokeWidth = 1.5f
        val step = s / 8f
        var i = 0f
        while (i <= s) {
            c.drawLine(i, 0f, i, s.toFloat(), p)
            c.drawLine(0f, i, s.toFloat(), i, p)
            i += step
        }
        return b
    }

    private fun genStars(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val rnd = Random(11)
        for (k in 0 until 12) {
            val cx = rnd.nextFloat() * s
            val cy = rnd.nextFloat() * s
            val r = 4f + rnd.nextFloat() * 10f
            val path = Path()
            for (i in 0 until 10) {
                val ang = Math.PI / 5 * i - Math.PI / 2
                val rad = if (i % 2 == 0) r else r * 0.4f
                val x = cx + (cos(ang) * rad).toFloat()
                val y = cy + (sin(ang) * rad).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            c.drawPath(path, p)
        }
        return b
    }

    private fun genGrunge(s: Int): Bitmap {
        val b = genNoise(s)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rnd = Random(21)
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_OUT)
        for (i in 0 until 30) {
            p.alpha = 100 + rnd.nextInt(120)
            c.drawCircle(rnd.nextFloat() * s, rnd.nextFloat() * s, 4f + rnd.nextFloat() * 20f, p)
        }
        p.xfermode = null
        return b
    }

    private fun genRipple(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val px = IntArray(s * s)
        val cx = s / 2f
        val cy = s / 2f
        for (y in 0 until s) {
            for (x in 0 until s) {
                val d = sqrt(((x - cx) * (x - cx) + (y - cy) * (y - cy)).toDouble()).toFloat()
                val v = ((sin(d * 0.35) * 0.5 + 0.5) * 255).toInt().coerceIn(0, 255)
                px[y * s + x] = Color.argb(255, v, v, v)
            }
        }
        b.setPixels(px, 0, s, 0, 0, s, s)
        return b
    }

    private fun genSparkle(s: Int): Bitmap {
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.TRANSPARENT)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rnd = Random(5)
        for (i in 0 until 40) {
            val x = rnd.nextFloat() * s
            val y = rnd.nextFloat() * s
            val r = 1f + rnd.nextFloat() * 3f
            p.shader = RadialGradient(
                x, y, r * 3f,
                intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF),
                null,
                Shader.TileMode.CLAMP
            )
            c.drawCircle(x, y, r * 3f, p)
        }
        p.shader = null
        return b
    }
}
