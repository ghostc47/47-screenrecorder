package com.recorder47

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Player/visualizador do próprio app: vídeo, áudio de voz e imagens.
 * Controles com gestos: toque duplo ±10 s, velocidade, repetir, girar, anterior/próximo.
 */
class PlayerActivity : ComponentActivity() {

    companion object {
        /** kind: 0 vídeo, 1 imagem, 2 áudio. */
        fun open(ctx: Context, uris: List<Uri>, names: List<String>, kind: Int, index: Int) {
            val i = Intent(ctx, PlayerActivity::class.java)
            i.putStringArrayListExtra("uris", ArrayList(uris.map { it.toString() }))
            i.putStringArrayListExtra("names", ArrayList(names))
            i.putExtra("kind", kind)
            i.putExtra("index", index)
            if (ctx !is android.app.Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val white = 0xFFFFFFFF.toInt()

    private var uris = mutableListOf<Uri>()
    private var names = mutableListOf<String>()
    private var kind = 0
    private var index = 0

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var controls: FrameLayout
    private lateinit var title: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var btnPlay: TextView
    private lateinit var btnPrev: TextView
    private lateinit var btnNext: TextView
    private lateinit var btnSpeed: TextView
    private lateinit var btnLoop: TextView
    private lateinit var flashView: TextView
    private lateinit var mediaBar: View

    private var video: VideoView? = null
    private var image: ImageView? = null
    private var mp: MediaPlayer? = null
    private var speed = 1f
    private var loop = false
    private var controlsOn = true
    private var dragging = false
    private var imgScale = 1f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ ciclo de vida
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        uris = (intent.getStringArrayListExtra("uris") ?: arrayListOf()).map { Uri.parse(it) }.toMutableList()
        names = (intent.getStringArrayListExtra("names") ?: arrayListOf()).toMutableList()
        kind = intent.getIntExtra("kind", 0)
        index = intent.getIntExtra("index", 0).coerceIn(0, maxOf(0, uris.size - 1))
        if (uris.isEmpty()) { finish(); return }
        while (names.size < uris.size) names.add("Arquivo")

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        controls = buildControls()
        root.addView(controls, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        flashView = TextView(this).apply {
            textSize = 20f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = Ui.pillDrawable(0xAA000000.toInt(), dp(24).toFloat())
            visibility = View.GONE
        }
        root.addView(flashView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)
        setupGestures()
        load(index)
        scheduleHide()
    }

    override fun onPause() {
        super.onPause()
        try { video?.pause() } catch (_: Exception) { }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { video?.stopPlayback() } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    // ------------------------------------------------------------------- UI
    private fun txtBtn(text: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun buildControls(): FrameLayout {
        val c = FrameLayout(this)

        // barra superior
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(30), dp(6), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xCC000000.toInt(), 0x00000000)
            )
        }
        top.addView(txtBtn("←", 24f) { finish() })
        title = TextView(this).apply {
            textSize = 15f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(txtBtn("⋮", 24f) { showMenu() })
        c.addView(top, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // barra inferior
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(20), dp(14), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(0xCC000000.toInt(), 0x00000000)
            )
        }

        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tCur = TextView(this).apply { textSize = 12f; setTextColor(white); text = "0:00" }
        tTot = TextView(this).apply { textSize = 12f; setTextColor(white); text = "0:00" }
        seek = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) tCur.text = fmt(p)
                }
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    video?.seekTo(s.progress)
                    dragging = false
                    scheduleHide()
                }
            })
        }
        seekRow.addView(tCur)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { leftMargin = dp(6); rightMargin = dp(6) })
        seekRow.addView(tTot)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        btnPrev = txtBtn("⏮") { if (index > 0) load(index - 1) }
        val back10 = txtBtn("⏪") { seekBy(-10_000) }
        btnPlay = txtBtn("⏸", 30f) { togglePlay() }
        val fwd10 = txtBtn("⏩") { seekBy(10_000) }
        btnNext = txtBtn("⏭") { if (index < uris.size - 1) load(index + 1) }
        btnRow.addView(btnPrev); btnRow.addView(back10); btnRow.addView(btnPlay)
        btnRow.addView(fwd10); btnRow.addView(btnNext)

        val optRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        btnSpeed = txtBtn("1x", 14f) { cycleSpeed() }.apply {
            background = Ui.pillDrawable(0x33FFFFFF, dp(18).toFloat())
        }
        btnLoop = txtBtn("🔁 Repetir", 14f) { toggleLoop() }.apply {
            background = Ui.pillDrawable(0x33FFFFFF, dp(18).toFloat())
        }
        val rot = txtBtn("🔄 Girar", 14f) { rotate() }.apply {
            background = Ui.pillDrawable(0x33FFFFFF, dp(18).toFloat())
        }
        val gap = { LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { leftMargin = dp(6); rightMargin = dp(6) } }
        optRow.addView(btnSpeed, gap()); optRow.addView(btnLoop, gap()); optRow.addView(rot, gap())

        mediaBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(seekRow)
            addView(optRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        }
        bottom.addView(mediaBar)
        bottom.addView(btnRow)
        c.addView(bottom, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        return c
    }

    private fun setupGestures() {
        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val img = image ?: return false
                imgScale = (imgScale * d.scaleFactor).coerceIn(1f, 6f)
                img.scaleX = imgScale; img.scaleY = imgScale
                if (imgScale == 1f) { img.translationX = 0f; img.translationY = 0f }
                return true
            }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleControls(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val img = image
                if (img != null) {
                    imgScale = if (imgScale > 1f) 1f else 2.5f
                    img.animate().scaleX(imgScale).scaleY(imgScale).translationX(0f).translationY(0f)
                        .setDuration(150).start()
                } else if (video != null) {
                    if (e.x < root.width / 2f) seekBy(-10_000) else seekBy(10_000)
                }
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val img = image ?: return false
                if (imgScale > 1f && !scaler.isInProgress) {
                    img.translationX -= dx
                    img.translationY -= dy
                    return true
                }
                return false
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || imgScale > 1f) return false
                val dx = e2.x - e1.x
                if (kotlin.math.abs(dx) > dp(120) && kotlin.math.abs(vx) > 800 && kotlin.math.abs(dx) > kotlin.math.abs(e2.y - e1.y)) {
                    if (dx < 0 && index < uris.size - 1) load(index + 1)
                    else if (dx > 0 && index > 0) load(index - 1)
                    return true
                }
                return false
            }
        })
        root.setOnTouchListener { _, e ->
            scaler.onTouchEvent(e)
            gd.onTouchEvent(e)
            true
        }
    }

    // ------------------------------------------------------------- carregar
    private fun load(i: Int) {
        index = i
        main.removeCallbacks(ticker)
        try { video?.stopPlayback() } catch (_: Exception) { }
        video = null; image = null; mp = null
        imgScale = 1f
        stage.removeAllViews()
        title.text = names[i]
        btnPrev.alpha = if (i > 0) 1f else 0.3f
        btnNext.alpha = if (i < uris.size - 1) 1f else 0.3f

        if (kind == 1) {
            mediaBar.visibility = View.GONE
            btnPlay.visibility = View.GONE
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            stage.addView(iv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            image = iv
            Thread {
                val bmp = decodeImage(uris[i])
                runOnUiThread {
                    if (bmp != null && image === iv) iv.setImageBitmap(bmp)
                    else if (bmp == null) Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_SHORT).show()
                }
            }.start()
            return
        }

        mediaBar.visibility = View.VISIBLE
        btnPlay.visibility = View.VISIBLE
        if (kind == 2) {
            val art = TextView(this).apply {
                text = "🎵"
                textSize = 96f
                gravity = Gravity.CENTER
                setTextColor(Ui.accent)
            }
            stage.addView(art, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val v = VideoView(this)
        stage.addView(v, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        video = v
        v.setOnPreparedListener { p ->
            mp = p
            p.isLooping = loop
            seek.max = maxOf(1, p.duration)
            tTot.text = fmt(p.duration)
            if (speed != 1f) applySpeed()
            v.start()
            btnPlay.text = "⏸"
            main.removeCallbacks(ticker)
            main.post(ticker)
            scheduleHide()
        }
        v.setOnCompletionListener {
            if (!loop) {
                btnPlay.text = "▶"
                showControls(true)
                if (index < uris.size - 1) {
                    flash("Próximo ⏭")
                    main.postDelayed({ if (video === v) load(index + 1) }, 700)
                }
            }
        }
        v.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Não foi possível reproduzir este arquivo", Toast.LENGTH_SHORT).show()
            true
        }
        v.setVideoURI(uris[i])
    }

    private fun decodeImage(uri: Uri): Bitmap? = try {
        val maxSide = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) * 2
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > maxSide || o.outHeight / sample > maxSide) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (_: Exception) { null }

    // ------------------------------------------------------------ reprodução
    private val ticker = object : Runnable {
        override fun run() {
            val v = video
            if (v != null) {
                try {
                    if (!dragging) {
                        val pos = v.currentPosition
                        seek.progress = pos
                        tCur.text = fmt(pos)
                    }
                    btnPlay.text = if (v.isPlaying) "⏸" else "▶"
                } catch (_: Exception) { }
                main.postDelayed(this, 250)
            }
        }
    }

    private fun togglePlay() {
        val v = video ?: return
        if (v.isPlaying) v.pause() else v.start()
        btnPlay.text = if (v.isPlaying) "⏸" else "▶"
    }

    private fun seekBy(ms: Int) {
        val v = video ?: return
        val dur = maxOf(1, v.duration)
        v.seekTo((v.currentPosition + ms).coerceIn(0, dur))
        flash(if (ms > 0) "+${ms / 1000}s ⏩" else "⏪ ${ms / 1000}s")
    }

    private fun cycleSpeed() {
        val list = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val i = list.indexOfFirst { it == speed }
        speed = list[(i + 1) % list.size]
        btnSpeed.text = (if (speed == speed.toInt().toFloat()) "${speed.toInt()}" else "$speed") + "x"
        applySpeed()
        flash(btnSpeed.text.toString())
    }

    private fun applySpeed() {
        val p = mp ?: return
        try {
            val wasPlaying = video?.isPlaying == true
            p.playbackParams = p.playbackParams.setSpeed(speed)
            if (!wasPlaying) p.pause()
        } catch (_: Exception) { }
    }

    private fun toggleLoop() {
        loop = !loop
        mp?.isLooping = loop
        btnLoop.background = Ui.pillDrawable(if (loop) Ui.accent else 0x33FFFFFF, dp(18).toFloat())
        flash(if (loop) "Repetir: ligado" else "Repetir: desligado")
    }

    private fun rotate() {
        requestedOrientation =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
    }

    // -------------------------------------------------------------- controles
    private fun toggleControls() = showControls(!controlsOn)

    private fun showControls(on: Boolean) {
        controlsOn = on
        controls.animate().alpha(if (on) 1f else 0f).setDuration(160).withEndAction {
            controls.visibility = if (on) View.VISIBLE else View.INVISIBLE
        }.start()
        if (on) controls.visibility = View.VISIBLE
        val ic = WindowInsetsControllerCompat(window, window.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) ic.show(WindowInsetsCompat.Type.systemBars()) else ic.hide(WindowInsetsCompat.Type.systemBars())
        if (on) scheduleHide()
    }

    private val hideRunnable = Runnable {
        val playing = try { video?.isPlaying == true } catch (_: Exception) { false }
        if (controlsOn && (playing || kind == 1) && !dragging) showControls(false)
    }

    private fun scheduleHide() {
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, 3500)
    }

    private val flashHide = Runnable { flashView.visibility = View.GONE }

    private fun flash(text: String) {
        flashView.text = text
        flashView.visibility = View.VISIBLE
        main.removeCallbacks(flashHide)
        main.postDelayed(flashHide, 700)
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        val h = s / 3600
        return if (h > 0) String.format("%d:%02d:%02d", h, (s % 3600) / 60, s % 60)
        else String.format("%d:%02d", s / 60, s % 60)
    }

    // ------------------------------------------------------------------ menu
    private fun showMenu() {
        val items = arrayOf("Compartilhar", "Detalhes", "Abrir em outro app", "Excluir")
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> share()
                    1 -> showDetails()
                    2 -> openExternal()
                    3 -> confirmDelete()
                }
            }.show()
    }

    private fun mimeOf(uri: Uri) = contentResolver.getType(uri) ?: when (kind) {
        0 -> "video/*"; 1 -> "image/*"; else -> "audio/*"
    }

    private fun share() {
        val uri = uris[index]
        val send = Intent(Intent.ACTION_SEND)
        send.type = mimeOf(uri)
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Compartilhar"))
    }

    private fun openExternal() {
        val uri = uris[index]
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeOf(uri))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "Nenhum app encontrado para abrir", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Excluir?")
            .setMessage(names[index])
            .setPositiveButton("Excluir") { _, _ ->
                try {
                    contentResolver.delete(uris[index], null, null)
                } catch (_: Exception) {
                    Toast.makeText(this, "Não foi possível excluir", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                uris.removeAt(index)
                names.removeAt(index)
                if (uris.isEmpty()) {
                    finish()
                } else {
                    load(minOf(index, uris.size - 1))
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showDetails() {
        val uri = uris[index]
        val sb = StringBuilder()
        try {
            contentResolver.query(
                uri,
                arrayOf(
                    MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH
                ), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    sb.append("Nome: ").append(c.getString(0)).append('\n')
                    sb.append(String.format("Tamanho: %.2f MB\n", c.getLong(1) / 1048576.0))
                    sb.append("Data: ").append(
                        android.text.format.DateFormat.format("dd/MM/yyyy HH:mm", c.getLong(2) * 1000)
                    ).append('\n')
                    sb.append("Pasta: ").append(c.getString(3) ?: "").append('\n')
                }
            }
        } catch (_: Exception) { }
        try {
            if (kind == 1) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                sb.append("Resolução: ${o.outWidth}×${o.outHeight}\n")
            } else {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                fun k(key: Int) = r.extractMetadata(key)
                val w = k(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val h = k(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                if (w != null && h != null) sb.append("Resolução: ${w}×${h}\n")
                k(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let {
                    sb.append("Duração: ").append(fmt(it.toInt())).append('\n')
                }
                k(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()?.let {
                    sb.append(String.format("Taxa de bits: %.1f Mbps\n", it / 1_000_000.0))
                }
                k(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.let { sb.append("Quadros/s: $it\n") }
                k(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)?.let { sb.append("Formato: $it\n") }
                r.release()
            }
        } catch (_: Exception) { }
        AlertDialog.Builder(this)
            .setTitle("Detalhes")
            .setMessage(sb.toString().trim().ifEmpty { "Sem informações" })
            .setPositiveButton("OK", null)
            .show()
    }
}
