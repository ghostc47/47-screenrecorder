package com.recorder47

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.app.NotificationCompat

/** Depois que o celular liga: avisa com uma notificação e tenta abrir o app para ligar o círculo flutuante. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != "android.intent.action.QUICKBOOT_POWERON") return
        if (!Prefs.startOnBoot(context)) return

        val launch = Intent(context, MainActivity::class.java)
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        launch.putExtra("auto", "circle")

        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("boot47", "Início automático", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val pi = PendingIntent.getActivity(
                context, 77, launch,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(context, "boot47")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("47 Recorder")
                .setContentText("Toque para abrir o círculo flutuante")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(78, n)
        } catch (_: Exception) { }

        // Quem tem a permissão de sobreposição pode abrir telas em segundo plano
        if (Settings.canDrawOverlays(context)) {
            try {
                context.startActivity(launch)
            } catch (_: Exception) { }
        }
    }
}
