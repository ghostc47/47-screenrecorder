package com.recorder47

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class WaveView(ctx: Context) : View(ctx) {
    private val values = FloatArray(64)
    private var idx = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var barColor: Int = Color.RED

    fun push(amp: Int) {
        val v = Math.sqrt((amp / 32767.0).coerceIn(0.0, 1.0)).toFloat()
        values[idx] = v
        idx = (idx + 1) % values.size
        invalidate()
    }

    fun clear() {
        for (i in values.indices) values[i] = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = w / n
        paint.color = barColor
        paint.strokeWidth = bw * 0.55f
        paint.strokeCap = Paint.Cap.ROUND
        for (i in 0 until n) {
            val v = values[(idx + i) % n]
            val bh = maxOf(h * 0.04f, v * h * 0.9f)
            val x = i * bw + bw / 2f
            canvas.drawLine(x, h / 2f - bh / 2f, x, h / 2f + bh / 2f, paint)
        }
    }
}
