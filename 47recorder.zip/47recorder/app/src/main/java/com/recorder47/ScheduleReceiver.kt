package com.recorder47

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat

/** Gravação agendada: dispara no horário escolhido. */
class ScheduleReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Prefs.setSchedAt(context, 0L)

        // Círculo já aberto: a sessão já tem permissão de captura, então grava direto
        if (RecorderService.active) {
            try {
                context.startService(
                    Intent(context, RecorderService::class.java).setAction(RecorderService.ACTION_REC)
                )
                return
            } catch (_: Exception) { }
        }

        // O Android exige a confirmação do usuário para capturar a tela
        val launch = Intent(context, MainActivity::class.java)
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        launch.putExtra("auto", "sched")
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("sched47", "Gravação agendada", NotificationManager.IMPORTANCE_HIGH)
            )
            val pi = PendingIntent.getActivity(
                context, 79, launch,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(context, "sched47")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("47 Recorder · gravação agendada")
                .setContentText("Toque para iniciar a gravação")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .build()
            nm.notify(79, n)
        } catch (_: Exception) { }

        if (Settings.canDrawOverlays(context)) {
            try { context.startActivity(launch) } catch (_: Exception) { }
        }
    }

    companion object {
        private fun pi(ctx: Context) = PendingIntent.getBroadcast(
            ctx, 80, Intent(ctx, ScheduleReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun schedule(ctx: Context, at: Long) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            Prefs.setSchedAt(ctx, at)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx))
        }

        fun cancel(ctx: Context) {
            try { ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx)) } catch (_: Exception) { }
            Prefs.setSchedAt(ctx, 0L)
        }
    }
}
