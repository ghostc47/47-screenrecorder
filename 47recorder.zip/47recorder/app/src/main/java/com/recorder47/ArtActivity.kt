package com.recorder47

import android.app.AlertDialog
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

private const val A_MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val A_WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val A_WHITE = 0xFFFFFFFF.toInt()
private val A_GREY = 0xFFB5B5B5.toInt()

/**
 * 47 Art Mode: estúdio de desenho. A tela acompanha a rotação do aparelho (em pé ou deitado):
 * o layout muda e o desenho é reajustado sem perder nada.
 */
class ArtActivity : ComponentActivity() {

    private lateinit var art: ArtCanvas
    private lateinit var timelapse: Timelapse
    private lateinit var toolPanel: LinearLayout
    private lateinit var transformBar: LinearLayout
    private lateinit var selBar: HorizontalScrollView
    private lateinit var zoomLabel: TextView
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var guideBtn: TextView
    private lateinit var toolBtn: TextView
    private lateinit var colorDot: TextView
    private lateinit var layerBtn: TextView
    private lateinit var symBtn: TextView
    private var sliderPanel: LinearLayout? = null

    private var landscape = false
    private var projId = ""
    private val toolItems = ArrayList<LinearLayout>()
    private var layersDialog: AlertDialog? = null
    private val saveHandler = Handler(Looper.getMainLooper())
    private val autosave = Runnable { saveNow() }
    private var exporting = false

    private val toolIcons = arrayOf(
        "✏️", "🖋️", "🖌️", "💨", "🖍️", "🩹", "🪣", "💧", "📏", "▭", "⬭", "🔄", "✋",
        "🌫️", "🧱", "💦", "👆", "🌈", "🔤", "⬚", "➰", "🌫", "🪄", "🌀"
    )
    private val toolNames = arrayOf(
        "Lápis", "Caneta", "Pincel", "Aerógrafo", "Marcador", "Borracha", "Balde",
        "Conta-gotas", "Linha", "Retângulo", "Elipse", "Transformar", "Mão",
        "Spray", "Giz", "Aquarela", "Borrar", "Gradiente", "Texto", "Seleção", "Laço",
        "Desfoque", "Varinha", "Liquify"
    )
    private val symLabels = arrayOf("off", "↔", "↕", "✛")
    private val guideNames = arrayOf("desligada", "grade", "terços", "perspectiva", "isométrica")

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) importImage(uri)
        }

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (toolPanel.visibility == View.VISIBLE) {
                toolPanel.visibility = View.GONE
            } else if (art.transforming) {
                art.cancelTransform()
            } else if (art.hasSelection()) {
                art.clearSelection()
            } else {
                finishSaving()
            }
        }
    }

    // ------------------------------------------------------------ helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun roundBtn(symbol: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = symbol
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.setTextColor(A_WHITE)
        t.background = oval(0xAA000000.toInt())
        t.setOnClickListener { onClick() }
        return t
    }

    private fun cell(icon: String, caption: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = icon + "\n" + caption
        t.gravity = Gravity.CENTER
        t.textSize = if (landscape) 9.5f else 11f
        t.setTextColor(0xFFDDDDDD.toInt())
        t.setOnClickListener { onClick() }
        return t
    }

    private fun pillBtn(text: String, onClick: () -> Unit): TextView {
        val t = label(text, 13f, A_WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(10), dp(10), dp(10))
        t.background = round(0x33FFFFFF, 12)
        t.setOnClickListener { onClick() }
        return t
    }

    // ------------------------------------------------------------- ciclo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF121212.toInt()
        onBackPressedDispatcher.addCallback(this, backCb)
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        art = ArtCanvas(this)
        art.stabilizer = 2
        art.color = 0xFF000000.toInt()

        val pid = intent.getStringExtra("pid")
        var loaded = false
        if (pid != null) {
            projId = pid
            loaded = loadProject()
        }
        if (!loaded) {
            if (projId.isEmpty()) projId = ArtStore.newId()
            if (landscape) createDoc(1350, 1080, Color.WHITE) else createDoc(1080, 1350, Color.WHITE)
        }
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))

        buildUi()

        art.onPick = { c ->
            art.color = c
            refreshColor()
        }
        art.onHistoryChanged = { refreshHistory() }
        art.onTransformChanged = { refreshBars() }
        art.onSelectionChanged = { refreshBars() }
        art.onViewChanged = { refreshZoom() }
        art.onCommit = { onCommitted() }
        art.onTextRequest = { x, y -> showTextDialog(x, y) }
        refreshAll()
    }

    /** O aparelho girou (em pé <-> deitado): refaz o layout e reajusta o desenho. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        buildUi()
        refreshAll()
    }

    override fun onPause() {
        super.onPause()
        saveHandler.removeCallbacks(autosave)
        saveNow()
    }

    override fun onDestroy() {
        saveHandler.removeCallbacks(autosave)
        super.onDestroy()
    }

    private fun createDoc(w: Int, h: Int, bg: Int) {
        try {
            art.newDoc(w, h, bg)
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente. Usando uma tela menor.")
            art.newDoc(720, 900, bg)
        }
    }

    private fun loadProject(): Boolean {
        return try {
            val d = ArtStore.load(this, projId) ?: return false
            art.setDoc(d.w, d.h, d.bg, d.layers, d.cur)
            true
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    private fun onCommitted() {
        timelapse.capture(art)
        saveHandler.removeCallbacks(autosave)
        saveHandler.postDelayed(autosave, 4000)
        refreshLayers()
    }

    private fun saveNow() {
        if (!::art.isInitialized) return
        try {
            val snap = art.snapshot()
            val th = maxOf(1, (256f * art.docH / art.docW).toInt())
            val thumb = art.renderSmall(256, th)
            ArtStore.save(this, projId, art.docW, art.docH, art.bgColor, art.current, snap, thumb)
        } catch (e: OutOfMemoryError) {
            // sem memória para a cópia: tenta de novo na próxima alteração
        }
    }

    private fun finishSaving() {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        finish()
    }

    // ------------------------------------------------------------ interface
    private fun buildUi() {
        toolItems.clear()
        val oldParent = art.parent
        if (oldParent is ViewGroup) oldParent.removeView(art)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF1B1B1B.toInt())
        root.addView(art, FrameLayout.LayoutParams(A_MATCH, A_MATCH))
        root.addView(buildTop(), FrameLayout.LayoutParams(A_MATCH, A_WRAP, Gravity.TOP))

        transformBar = buildTransformBar()
        val tbp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        tbp.topMargin = dp(62)
        root.addView(transformBar, tbp)

        selBar = buildSelBar()
        val sbp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        sbp.topMargin = dp(62)
        sbp.leftMargin = dp(8)
        sbp.rightMargin = dp(8)
        root.addView(selBar, sbp)

        zoomLabel = label("100%", 11f, A_WHITE, true)
        zoomLabel.setPadding(dp(10), dp(4), dp(10), dp(4))
        zoomLabel.background = round(0x99000000.toInt(), 12)
        val zp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.START)
        zp.topMargin = dp(62)
        zp.leftMargin = dp(12)
        root.addView(zoomLabel, zp)

        if (!landscape) {
            root.addView(buildBottomPortrait(), FrameLayout.LayoutParams(A_MATCH, A_WRAP, Gravity.BOTTOM))
            sliderPanel = null
            toolPanel = buildToolPanel(3)
            val tpp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.BOTTOM or Gravity.START)
            tpp.leftMargin = dp(8)
            tpp.bottomMargin = dp(198)
            root.addView(toolPanel, tpp)
            art.setPads(0f, dp(64).toFloat(), 0f, dp(206).toFloat())
        } else {
            val side = buildSideBar()
            val sdp = FrameLayout.LayoutParams(dp(64), A_WRAP, Gravity.END or Gravity.BOTTOM)
            sdp.bottomMargin = dp(4)
            root.addView(side, sdp)

            val sp = buildSliderBlock()
            sp.setBackgroundColor(0xCC121212.toInt())
            sp.isClickable = true
            sliderPanel = sp
            val spp = FrameLayout.LayoutParams(dp(320), A_WRAP, Gravity.BOTTOM or Gravity.START)
            spp.leftMargin = dp(8)
            spp.bottomMargin = dp(8)
            root.addView(sp, spp)

            toolPanel = buildToolPanel(5)
            val tpp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.BOTTOM or Gravity.END)
            tpp.rightMargin = dp(70)
            tpp.bottomMargin = dp(8)
            root.addView(toolPanel, tpp)
            art.setPads(0f, dp(54).toFloat(), dp(64).toFloat(), 0f)
        }
        setContentView(root)
        refreshAll()
    }

    private fun buildTop(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(10), dp(10), dp(10), 0)

        val back = roundBtn("←") { finishSaving() }
        undoBtn = roundBtn("↩") { art.undo() }
        redoBtn = roundBtn("↪") { art.redo() }
        row.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val lpu = LinearLayout.LayoutParams(dp(44), dp(44))
        lpu.leftMargin = dp(8)
        row.addView(undoBtn, lpu)
        val lpr = LinearLayout.LayoutParams(dp(44), dp(44))
        lpr.leftMargin = dp(8)
        row.addView(redoBtn, lpr)
        row.addView(View(this), LinearLayout.LayoutParams(0, dp(44), 1f))

        val fit = roundBtn("⤢") { art.resetView() }
        guideBtn = roundBtn("▦") { cycleGuide() }
        val more = roundBtn("⋮") { showMore() }
        row.addView(fit, LinearLayout.LayoutParams(dp(44), dp(44)))
        val lpg = LinearLayout.LayoutParams(dp(44), dp(44))
        lpg.leftMargin = dp(8)
        row.addView(guideBtn, lpg)
        val lpm = LinearLayout.LayoutParams(dp(44), dp(44))
        lpm.leftMargin = dp(8)
        row.addView(more, lpm)
        return row
    }

    private fun buildTransformBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.visibility = View.GONE
        val cancel = label("✕ Cancelar", 14f, A_WHITE, true)
        cancel.setPadding(dp(18), dp(10), dp(18), dp(10))
        cancel.background = round(0xDD333333.toInt(), 22)
        cancel.setOnClickListener { art.cancelTransform() }
        val ok = label("✓ Aplicar", 14f, A_WHITE, true)
        ok.setPadding(dp(18), dp(10), dp(18), dp(10))
        ok.background = round(Ui.accent, 22)
        ok.setOnClickListener { art.applyTransform() }
        bar.addView(cancel)
        val lp = LinearLayout.LayoutParams(A_WRAP, A_WRAP)
        lp.leftMargin = dp(10)
        bar.addView(ok, lp)
        return bar
    }

    private fun buildSelBar(): HorizontalScrollView {
        val sv = HorizontalScrollView(this)
        sv.visibility = View.GONE
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(8), dp(4), dp(8), dp(4))
        row.background = round(0xDD1A1A1A.toInt(), 22)

        fun add(text: String, onClick: () -> Unit) {
            val t = label(text, 13f, A_WHITE, true)
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            t.setOnClickListener { onClick() }
            row.addView(t)
        }

        add("✂ Cortar") {
            if (!art.selCopyToLayer(true)) toast("Não foi possível (limite de camadas)")
            refreshLayers()
        }
        add("⧉ Copiar") {
            if (!art.selCopyToLayer(false)) toast("Não foi possível (limite de camadas)")
            refreshLayers()
        }
        add("↔ Mover") {
            if (art.selCopyToLayer(true)) {
                art.clearSelection()
                setTool(ArtCanvas.T_TRANSFORM)
                refreshLayers()
                toast("Arraste com um dedo; gire e amplie com dois")
            } else {
                toast("Não foi possível (limite de camadas)")
            }
        }
        add("🗑 Apagar") { art.selErase() }
        add("🎨 Preencher") { art.selFill() }
        add("✕ Soltar") { art.clearSelection() }
        sv.addView(row)
        return sv
    }

    private fun sliderRow(
        title: String, max: Int, initial: Int, fmt: (Int) -> String,
        onChange: (Int) -> Unit, onDone: (() -> Unit)? = null
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), 0, dp(12), 0)
        val lbl = label(title, 12f, A_WHITE)
        val value = label(fmt(initial), 12f, A_WHITE)
        value.gravity = Gravity.END
        val seek = SeekBar(this)
        seek.max = max
        seek.progress = initial
        seek.progressTintList = ColorStateList.valueOf(Ui.accent)
        seek.thumbTintList = ColorStateList.valueOf(Ui.accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = fmt(p)
                onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (onDone != null) onDone()
            }
        })
        row.addView(lbl, LinearLayout.LayoutParams(dp(92), A_WRAP))
        row.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(44), A_WRAP))
        return row
    }

    private fun buildSliderBlock(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val sizeP = (art.brushSize.toInt() - 1).coerceIn(0, 199)
        val opP = (art.opacity * 100 / 255 - 1).coerceIn(0, 99)
        box.addView(
            sliderRow("Tamanho", 199, sizeP, { p -> "${p + 1}" }, { p ->
                art.brushSize = (p + 1).toFloat()
                refreshColor()
            })
        )
        box.addView(
            sliderRow("Opacidade", 99, opP, { p -> "${p + 1}%" }, { p ->
                art.opacity = (p + 1) * 255 / 100
            })
        )
        box.addView(
            sliderRow("Estabilizador", 10, art.stabilizer.coerceIn(0, 10), { p -> "$p" }, { p ->
                art.stabilizer = p
            })
        )
        return box
    }

    /** As cinco opções principais (usadas na barra de baixo, em pé, e na lateral, deitado). */
    private fun buildCells(): ArrayList<View> {
        val out = ArrayList<View>()
        toolBtn = cell("✏️", "Lápis") {
            toolPanel.visibility = if (toolPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        out.add(toolBtn)

        val colorCell = LinearLayout(this)
        colorCell.orientation = LinearLayout.VERTICAL
        colorCell.gravity = Gravity.CENTER
        colorDot = TextView(this)
        colorDot.gravity = Gravity.CENTER
        colorDot.textSize = 11f
        colorDot.typeface = Typeface.DEFAULT_BOLD
        val dotSize = if (landscape) 28 else 34
        colorCell.addView(colorDot, LinearLayout.LayoutParams(dp(dotSize), dp(dotSize)))
        if (!landscape) colorCell.addView(label("Cor", 11f, 0xFFDDDDDD.toInt()))
        colorCell.setOnClickListener { showColorPicker() }
        out.add(colorCell)

        layerBtn = cell("🗂", "Camadas") { showLayers() }
        out.add(layerBtn)

        symBtn = cell("🪞", "Simetria") {
            art.symmetry = (art.symmetry + 1) % 4
            refreshSym()
        }
        out.add(symBtn)

        out.add(cell("🩹", "Borracha") {
            setTool(if (art.tool == ArtCanvas.T_ERASER) ArtCanvas.T_PENCIL else ArtCanvas.T_ERASER)
        })
        return out
    }

    private fun buildBottomPortrait(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0xEE121212.toInt())
        box.isClickable = true
        box.addView(buildSliderBlock())

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xFF1A1A1A.toInt())
        for (v in buildCells()) bar.addView(v, LinearLayout.LayoutParams(0, dp(60), 1f))
        box.addView(bar)
        return box
    }

    private fun buildSideBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.gravity = Gravity.CENTER_HORIZONTAL
        bar.setBackgroundColor(0xEE121212.toInt())
        bar.isClickable = true
        for (v in buildCells()) bar.addView(v, LinearLayout.LayoutParams(A_MATCH, dp(46)))
        val brushCell = cell("🎚", "Pincel") {
            val sp = sliderPanel
            if (sp != null) {
                sp.visibility = if (sp.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }
        bar.addView(brushCell, LinearLayout.LayoutParams(A_MATCH, dp(46)))
        return bar
    }

    private fun buildToolPanel(cols: Int): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        panel.background = round(0xF2262626.toInt(), 18)
        panel.visibility = View.GONE

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val vpad = if (landscape) 4 else 8
        var i = 0
        while (i < toolNames.size) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until cols) {
                val idx = i + k
                if (idx < toolNames.size) {
                    val item = LinearLayout(this)
                    item.orientation = LinearLayout.VERTICAL
                    item.gravity = Gravity.CENTER
                    item.setPadding(dp(6), dp(vpad), dp(6), dp(vpad))
                    val ic = label(toolIcons[idx], if (landscape) 20f else 24f, A_WHITE)
                    ic.gravity = Gravity.CENTER
                    val nm = label(toolNames[idx], 11f, 0xFFDDDDDD.toInt())
                    nm.gravity = Gravity.CENTER
                    item.addView(ic, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
                    item.addView(nm, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
                    item.setOnClickListener { setTool(idx) }
                    toolItems.add(item)
                    line.addView(item, LinearLayout.LayoutParams(dp(88), A_WRAP))
                }
            }
            grid.addView(line)
            i += cols
        }
        val sv = ScrollView(this)
        sv.addView(grid)
        panel.addView(sv, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
        return panel
    }

    // ------------------------------------------------------------ atualizações
    private fun setTool(idx: Int) {
        art.tool = idx
        toolPanel.visibility = View.GONE
        refreshTool()
        refreshBars()
        val hint = when (idx) {
            ArtCanvas.T_TEXT -> "Toque onde quer escrever"
            ArtCanvas.T_SEL_RECT -> "Arraste para selecionar um retângulo"
            ArtCanvas.T_SEL_LASSO -> "Desenhe ao redor do que quer selecionar"
            ArtCanvas.T_GRADIENT -> "Arraste para definir a direção do degradê"
            ArtCanvas.T_TRANSFORM -> "Um dedo move; dois dedos giram e ampliam a camada"
            ArtCanvas.T_BLUR -> "Arraste para desfocar a área"
            ArtCanvas.T_MAGIC -> "Toque numa cor para selecionar a região"
            ArtCanvas.T_LIQUIFY -> "Arraste para empurrar/liquefazer pixels"
            else -> ""
        }
        if (hint.isNotEmpty()) toast(hint)
    }

    private fun refreshAll() {
        refreshTool()
        refreshColor()
        refreshHistory()
        refreshLayers()
        refreshSym()
        refreshGuide()
        refreshBars()
        refreshZoom()
    }

    private fun refreshTool() {
        val t = art.tool.coerceIn(0, toolNames.size - 1)
        toolBtn.text = toolIcons[t] + "\n" + toolNames[t]
        for (i in toolItems.indices) {
            if (i == t) {
                toolItems[i].background = round(0x66E53935, 12)
            } else {
                toolItems[i].background = null
            }
        }
    }

    private fun refreshColor() {
        val opaque = art.color or 0xFF000000.toInt()
        colorDot.background = oval(opaque)
        colorDot.text = art.brushSize.toInt().toString()
        colorDot.setTextColor(Prefs.contrast(opaque))
    }

    private fun refreshHistory() {
        undoBtn.alpha = if (art.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (art.canRedo()) 1f else 0.4f
    }

    private fun refreshLayers() {
        layerBtn.text = "🗂\nCamadas " + art.layers.size
    }

    private fun refreshSym() {
        symBtn.text = "🪞\nSimetria " + symLabels[art.symmetry.coerceIn(0, 3)]
        art.invalidate()
    }

    private fun refreshGuide() {
        guideBtn.alpha = if (art.guideMode == 0) 0.6f else 1f
    }

    private fun refreshBars() {
        transformBar.visibility = if (art.transforming) View.VISIBLE else View.GONE
        selBar.visibility = if (art.hasSelection() && !art.transforming) View.VISIBLE else View.GONE
    }

    private fun refreshZoom() {
        val a = art.viewAngle()
        var txt = art.zoomPercent().toString() + "%"
        if (art.isFlipped()) {
            txt += " • espelhado"
        } else if (a != 0) {
            txt += " • " + a + "°"
        }
        zoomLabel.text = txt
    }

    private fun cycleGuide() {
        art.guideMode = (art.guideMode + 1) % 5
        refreshGuide()
        toast("Guia: " + guideNames[art.guideMode])
    }

    // ---------------------------------------------------------------- cores
    private fun harmony(c: Int, type: Int): List<Int> {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = ArrayList<Int>()

        fun hue(d: Float): Int {
            var h = hsv[0] + d
            while (h < 0f) h += 360f
            while (h >= 360f) h -= 360f
            return Color.HSVToColor(floatArrayOf(h, hsv[1], hsv[2]))
        }

        when (type) {
            0 -> out.add(hue(180f))
            1 -> {
                out.add(hue(-30f))
                out.add(hue(30f))
            }
            2 -> {
                out.add(hue(120f))
                out.add(hue(240f))
            }
            else -> {
                for (v in floatArrayOf(0.25f, 0.5f, 0.75f, 1f)) {
                    out.add(Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v)))
                }
            }
        }
        return out
    }

    private fun showColorPicker() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))

        val wheel = ColorWheelView(this)
        wheel.setColor(art.color)
        box.addView(wheel, LinearLayout.LayoutParams(dp(240), dp(240)))

        val preview = TextView(this)
        preview.gravity = Gravity.CENTER
        preview.textSize = 14f
        val pl = LinearLayout.LayoutParams(A_MATCH, dp(40))
        pl.topMargin = dp(8)
        box.addView(preview, pl)

        val hex = EditText(this)
        hex.setSingleLine()
        hex.hint = "#RRGGBB"
        hex.setTextColor(A_WHITE)
        hex.setHintTextColor(A_GREY)
        hex.gravity = Gravity.CENTER
        box.addView(hex, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        var updatingHex = false

        val harmRow = LinearLayout(this)
        harmRow.orientation = LinearLayout.HORIZONTAL
        var harmType = 0

        fun updatePreview(c: Int) {
            val opaque = c or 0xFF000000.toInt()
            preview.background = round(opaque, 12)
            preview.text = String.format("#%06X", c and 0xFFFFFF)
            preview.setTextColor(Prefs.contrast(opaque))
            updatingHex = true
            hex.setText(String.format("#%06X", c and 0xFFFFFF))
            updatingHex = false
        }

        fun fillHarm(c: Int) {
            harmRow.removeAllViews()
            for (sw in harmony(c, harmType)) {
                val d = View(this)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(sw)
                g.setStroke(dp(2), 0xFF666666.toInt())
                d.background = g
                d.setOnClickListener {
                    wheel.setColor(sw)
                    updatePreview(sw)
                    fillHarm(sw)
                }
                val lp = LinearLayout.LayoutParams(dp(40), dp(40))
                lp.rightMargin = dp(10)
                harmRow.addView(d, lp)
            }
        }

        wheel.onColor = { c ->
            updatePreview(c)
            fillHarm(c)
        }
        hex.doAfterTextChanged { s ->
            if (!updatingHex) {
                val t = s.toString().trim().removePrefix("#")
                if (t.length == 6) {
                    val v = t.toLongOrNull(16)
                    if (v != null) {
                        val col = 0xFF000000.toInt() or v.toInt()
                        wheel.setColor(col)
                        fillHarm(col)
                    }
                }
            }
        }
        updatePreview(art.color)
        fillHarm(art.color)

        val hcap = label("Harmonias de cor", 12f, A_GREY)
        hcap.setPadding(0, dp(12), 0, dp(6))
        box.addView(hcap)
        val hnames = arrayOf("Complementar", "Análogas", "Tríade", "Tons")
        val hchips = LinearLayout(this)
        hchips.orientation = LinearLayout.HORIZONTAL
        val hviews = ArrayList<TextView>()
        fun paintH() {
            for (i in hviews.indices) {
                hviews[i].background = round(if (i == harmType) Ui.accent else 0x33FFFFFF, 12)
            }
        }
        for (i in hnames.indices) {
            val t = label(hnames[i], 11f, A_WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(2), dp(8), dp(2), dp(8))
            t.setOnClickListener {
                harmType = i
                paintH()
                fillHarm(wheel.getColor())
            }
            hviews.add(t)
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            hchips.addView(t, lp)
        }
        paintH()
        box.addView(hchips, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        val hs0 = HorizontalScrollView(this)
        hs0.addView(harmRow)
        val hp = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        hp.topMargin = dp(8)
        box.addView(hs0, hp)

        val cap = label("Minhas cores", 12f, A_GREY)
        cap.setPadding(0, dp(12), 0, dp(6))
        box.addView(cap)
        val prow = LinearLayout(this)
        prow.orientation = LinearLayout.HORIZONTAL
        for (pc in ArtStore.palette(this)) {
            val d = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(pc)
            g.setStroke(dp(2), 0xFF666666.toInt())
            d.background = g
            d.setOnClickListener {
                wheel.setColor(pc)
                updatePreview(pc)
                fillHarm(pc)
            }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.rightMargin = dp(8)
            prow.addView(d, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.addView(prow)
        box.addView(hs, LinearLayout.LayoutParams(A_MATCH, A_WRAP))

        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Cor")
            .setView(sv)
            .setPositiveButton("OK") { _, _ ->
                val c = wheel.getColor()
                art.color = c
                ArtStore.addPalette(this, c)
                refreshColor()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- texto
    private fun showTextDialog(x: Float, y: Float) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))

        val et = EditText(this)
        et.hint = "Digite o texto"
        et.minLines = 2
        et.setTextColor(A_WHITE)
        et.setHintTextColor(A_GREY)
        box.addView(et, LinearLayout.LayoutParams(A_MATCH, A_WRAP))

        var size = 64
        val sizeLbl = label("Tamanho: 64", 13f, A_WHITE)
        sizeLbl.setPadding(0, dp(12), 0, 0)
        box.addView(sizeLbl)
        val seek = SeekBar(this)
        seek.max = 292
        seek.progress = 56
        seek.progressTintList = ColorStateList.valueOf(Ui.accent)
        seek.thumbTintList = ColorStateList.valueOf(Ui.accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                size = p + 8
                sizeLbl.text = "Tamanho: " + size
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(seek, LinearLayout.LayoutParams(A_MATCH, A_WRAP))

        var style = 0
        val names = arrayOf("Normal", "Negrito", "Itálico")
        val chipViews = ArrayList<TextView>()
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL

        fun paintChips() {
            for (i in chipViews.indices) {
                chipViews[i].background = round(if (i == style) Ui.accent else 0x33FFFFFF, 12)
            }
        }
        for (i in names.indices) {
            val t = label(names[i], 13f, A_WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(10), dp(4), dp(10))
            t.setOnClickListener {
                style = i
                paintChips()
            }
            chipViews.add(t)
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            chipRow.addView(t, lp)
        }
        paintChips()
        val cp = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        cp.topMargin = dp(10)
        box.addView(chipRow, cp)

        AlertDialog.Builder(this)
            .setTitle("Texto")
            .setView(box)
            .setPositiveButton("Inserir") { _, _ ->
                val text = et.text.toString()
                if (text.isNotBlank()) art.drawText(x, y, text, size.toFloat(), style == 1, style == 2)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // -------------------------------------------------------------- camadas
    private fun blendChips(cur: ArtCanvas.Layer, from: Int, to: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in from until to) {
            val sel = cur.blend == i
            val t = label(ArtCanvas.BLEND_NAMES[i], 12f, A_WHITE, sel)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(10), dp(4), dp(10))
            t.background = round(if (sel) Ui.accent else 0x33FFFFFF, 12)
            t.setOnClickListener {
                cur.blend = i
                art.layerChanged()
                showLayers()
            }
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            row.addView(t, lp)
        }
        return row
    }

    private fun renameLayer(cur: ArtCanvas.Layer) {
        val et = EditText(this)
        et.setText(cur.name)
        et.setSingleLine()
        et.setTextColor(A_WHITE)
        val box = LinearLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), dp(8))
        box.addView(et, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        AlertDialog.Builder(this)
            .setTitle("Nome da camada")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    cur.name = t
                    art.layerChanged()
                }
                showLayers()
            }
            .setNegativeButton("Cancelar") { _, _ -> showLayers() }
            .show()
    }

    private fun showLayers() {
        layersDialog?.dismiss()
        if (art.layers.isEmpty()) return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(8), dp(12), dp(4))

        for (idx in art.layers.indices.reversed()) {
            val l = art.layers[idx]
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(8), dp(6), dp(8), dp(6))
            line.background = round(if (idx == art.current) 0x55E53935 else 0x22FFFFFF, 12)

            val eye = label(if (l.visible) "👁" else "🚫", 18f, A_WHITE)
            eye.gravity = Gravity.CENTER
            eye.setOnClickListener {
                l.visible = !l.visible
                art.layerChanged()
                showLayers()
            }
            line.addView(eye, LinearLayout.LayoutParams(dp(40), dp(40)))

            val thumb = ImageView(this)
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.setBackgroundColor(0xFFCCCCCC.toInt())
            try {
                thumb.setImageBitmap(
                    Bitmap.createScaledBitmap(l.bmp, 64, maxOf(1, 64 * art.docH / art.docW), true)
                )
            } catch (_: Exception) { }
            val tlp = LinearLayout.LayoutParams(dp(44), dp(maxOf(20, 44 * art.docH / art.docW)))
            tlp.leftMargin = dp(6)
            line.addView(thumb, tlp)

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            info.addView(label((if (l.alphaLock) "🔒 " else "") + l.name, 14f, A_WHITE, true))
            info.addView(
                label(
                    ArtCanvas.BLEND_NAMES[l.blend.coerceIn(0, 6)] + " • " + (l.opacity * 100 / 255) + "%",
                    11f, A_GREY
                )
            )
            val ilp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            ilp.leftMargin = dp(10)
            line.addView(info, ilp)

            line.setOnClickListener {
                art.selectLayer(idx)
                refreshLayers()
                showLayers()
            }
            val llp = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
            llp.bottomMargin = dp(6)
            box.addView(line, llp)
        }

        val cur = art.layers[art.current.coerceIn(0, art.layers.size - 1)]
        val sel = label("Camada selecionada: " + cur.name, 13f, 0xFFDDDDDD.toInt(), true)
        sel.setPadding(0, dp(10), 0, dp(4))
        box.addView(sel)
        box.addView(
            sliderRow("Opacidade", 100, cur.opacity * 100 / 255, { p -> "$p%" }, { p ->
                cur.opacity = p * 255 / 100
                art.invalidate()
            }, { art.layerChanged() })
        )
        val bl = label("Modo de mistura", 12f, A_GREY)
        bl.setPadding(0, dp(6), 0, dp(4))
        box.addView(bl)
        box.addView(blendChips(cur, 0, 4))
        val gap = View(this)
        box.addView(gap, LinearLayout.LayoutParams(A_MATCH, dp(6)))
        box.addView(blendChips(cur, 4, 7))

        val extras = LinearLayout(this)
        extras.orientation = LinearLayout.HORIZONTAL
        val lockLabel = if (cur.alphaLock) "🔒 Transparência travada" else "🔓 Transparência livre"
        val lp1 = LinearLayout.LayoutParams(0, A_WRAP, 1f)
        lp1.rightMargin = dp(3)
        extras.addView(pillBtn(lockLabel) {
            cur.alphaLock = !cur.alphaLock
            art.layerChanged()
            showLayers()
        }, lp1)
        val lp2 = LinearLayout.LayoutParams(0, A_WRAP, 1f)
        lp2.leftMargin = dp(3)
        extras.addView(pillBtn("✏️ Renomear") { renameLayer(cur) }, lp2)
        val ep = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        ep.topMargin = dp(10)
        box.addView(extras, ep)

        val acts1 = LinearLayout(this)
        acts1.orientation = LinearLayout.HORIZONTAL
        val acts2 = LinearLayout(this)
        acts2.orientation = LinearLayout.HORIZONTAL

        fun addAct(row: LinearLayout, text: String, onClick: () -> Unit) {
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            row.addView(pillBtn(text) {
                onClick()
                refreshLayers()
                showLayers()
            }, lp)
        }

        addAct(acts1, "＋ Nova") {
            if (!art.addLayer()) toast("Máximo de " + ArtCanvas.MAX_LAYERS + " camadas")
        }
        addAct(acts1, "⧉ Duplicar") {
            if (!art.duplicateCurrent()) toast("Não foi possível duplicar")
        }
        addAct(acts1, "⬇ Mesclar") {
            if (!art.mergeDown()) toast("Não há camada abaixo")
        }
        addAct(acts2, "🧹 Limpar") { art.clearCurrent() }
        addAct(acts2, "🗑 Excluir") {
            if (!art.removeCurrent()) toast("Mantenha ao menos uma camada")
        }
        addAct(acts2, "▲ Subir") { art.moveCurrent(true) }
        addAct(acts2, "▼ Descer") { art.moveCurrent(false) }

        val a1 = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        a1.topMargin = dp(10)
        box.addView(acts1, a1)
        val a2 = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        a2.topMargin = dp(6)
        box.addView(acts2, a2)

        val sv = ScrollView(this)
        sv.addView(box)
        val d = AlertDialog.Builder(this)
            .setTitle("Camadas")
            .setView(sv)
            .setPositiveButton("Fechar", null)
            .create()
        layersDialog = d
        d.show()
    }

    // ----------------------------------------------------------- mais opções
    private fun showMore() {
        val rot = if (art.rotateGesture) "ligado" else "desligado"
        val items = arrayOf(
            "Novo desenho…",
            "Importar imagem (referência)…",
            "Salvar na galeria (PNG)",
            "Salvar na galeria (JPG)",
            "Compartilhar imagem",
            "Exportar timelapse (vídeo)",
            "Espelhar visão",
            "Girar tela com 2 dedos: $rot",
            "Sair e salvar"
        )
        AlertDialog.Builder(this)
            .setTitle("47 Art Mode")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askNewDoc()
                    1 -> pickImage.launch("image/*")
                    2 -> exportImage(true, false)
                    3 -> exportImage(false, false)
                    4 -> exportImage(true, true)
                    5 -> exportTimelapse()
                    6 -> art.flipView()
                    7 -> {
                        art.rotateGesture = !art.rotateGesture
                        toast("Girar com 2 dedos: " + (if (art.rotateGesture) "ligado" else "desligado"))
                    }
                    else -> finishSaving()
                }
            }
            .show()
    }

    private fun askNewDoc() {
        val dm = resources.displayMetrics
        val sw = minOf(dm.widthPixels, 1440) / 2 * 2
        val sh = minOf(dm.heightPixels, 2560) / 2 * 2
        val sizes = arrayOf(
            "Quadrado 1080×1080", "Retrato 1080×1350", "Paisagem 1350×1080",
            "HD 1920×1080", "Tela cheia 1080×1920", "Tamanho da tela do aparelho ($sw×$sh)"
        )
        val dims = arrayOf(
            intArrayOf(1080, 1080), intArrayOf(1080, 1350), intArrayOf(1350, 1080),
            intArrayOf(1920, 1080), intArrayOf(1080, 1920), intArrayOf(sw, sh)
        )
        AlertDialog.Builder(this)
            .setTitle("Tamanho da tela")
            .setItems(sizes) { _, w1 ->
                val bgs = arrayOf("Fundo branco", "Fundo preto", "Fundo transparente")
                val colors = intArrayOf(Color.WHITE, Color.BLACK, Color.TRANSPARENT)
                AlertDialog.Builder(this)
                    .setTitle("Fundo")
                    .setItems(bgs) { _, w2 ->
                        startNewProject(dims[w1][0], dims[w1][1], colors[w2])
                    }
                    .show()
            }
            .show()
    }

    private fun startNewProject(w: Int, h: Int, bg: Int) {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        projId = ArtStore.newId()
        createDoc(w, h, bg)
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))
        refreshAll()
        toast("Novo desenho criado")
    }

    private fun importImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val maxDim = maxOf(art.docW, art.docH)
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opt = BitmapFactory.Options()
            opt.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
            if (bmp == null) {
                toast("Não foi possível abrir a imagem")
                return
            }
            val ok = art.addImageLayer(bmp, "Imagem")
            bmp.recycle()
            refreshLayers()
            if (ok) {
                toast("Imagem adicionada. Use Transformar para ajustar.")
            } else {
                toast("Máximo de " + ArtCanvas.MAX_LAYERS + " camadas")
            }
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para essa imagem")
        } catch (e: Exception) {
            toast("Não foi possível abrir a imagem")
        }
    }

    private fun shareUri(uri: Uri, mime: String) {
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = mime
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.clipData = ClipData.newRawUri("desenho", uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Compartilhar desenho"))
        } catch (_: Exception) {
            toast("Não foi possível compartilhar")
        }
    }

    private fun exportImage(png: Boolean, share: Boolean) {
        val flat: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        Thread {
            var savedUri: Uri? = null
            try {
                var out = flat
                if (!png) {
                    val bg = Bitmap.createBitmap(flat.width, flat.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(bg)
                    c.drawColor(Color.WHITE)
                    c.drawBitmap(flat, 0f, 0f, null)
                    out = bg
                }
                val ext = if (png) "png" else "jpg"
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "47Art_" + System.currentTimeMillis() + "." + ext)
                values.put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/47 Art")
                values.put(MediaStore.Images.Media.IS_PENDING, 1)
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    val fmt = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    val bmp = out
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(fmt, 95, it) }
                    val v2 = ContentValues()
                    v2.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, v2, null, null)
                    savedUri = uri
                }
                if (out !== flat) out.recycle()
            } catch (_: Exception) { }
            flat.recycle()
            val su = savedUri
            runOnUiThread {
                if (su != null) {
                    Toast.makeText(this, "Salvo em Pictures/47 Art", Toast.LENGTH_LONG).show()
                    if (share) shareUri(su, if (png) "image/png" else "image/jpeg")
                } else {
                    Toast.makeText(this, "Não foi possível salvar", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun exportTimelapse() {
        if (exporting) {
            toast("O timelapse já está sendo gerado")
            return
        }
        val count = timelapse.frameCount()
        if (count < 3) {
            toast("Desenhe um pouco mais para gerar o timelapse")
            return
        }
        val secs = (minOf(count, 150) + 18) / 12 + 1
        AlertDialog.Builder(this)
            .setTitle("Exportar timelapse")
            .setMessage("O vídeo terá cerca de $secs segundos e leva esse mesmo tempo para ser gerado. Continuar?")
            .setPositiveButton("Gerar") { _, _ -> startTimelapseExport() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTimelapseExport() {
        val finalFrame: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        exporting = true
        val cancel = AtomicBoolean(false)
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        val pad = LinearLayout(this)
        pad.setPadding(dp(24), dp(16), dp(24), dp(8))
        pad.addView(pb, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Gerando timelapse…")
            .setView(pad)
            .setCancelable(false)
            .setNegativeButton("Cancelar") { _, _ -> cancel.set(true) }
            .create()
        dlg.show()

        val list = timelapse.filesSnapshot()
        val tl = timelapse
        val w = art.docW
        val h = art.docH
        Thread {
            tl.flush()
            val ok = Timelapse.exportVideo(
                this, list, finalFrame, w, h,
                { p -> runOnUiThread { pb.progress = p } },
                { cancel.get() }
            )
            finalFrame.recycle()
            runOnUiThread {
                dlg.dismiss()
                exporting = false
                Toast.makeText(
                    this,
                    if (ok) "Timelapse salvo em Movies/47 Art" else "Timelapse não gerado",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }
}
