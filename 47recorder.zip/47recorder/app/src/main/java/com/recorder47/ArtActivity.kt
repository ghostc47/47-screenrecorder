package com.recorder47

import android.app.AlertDialog
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

private const val A_MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val A_WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val A_WHITE = 0xFFFFFFFF.toInt()
private val A_GREY = 0xFFB5B5B5.toInt()

/**
 * 47 Art Mode: estúdio de desenho. A tela acompanha a rotação do aparelho (em pé ou deitado):
 * o layout muda e o desenho é reajustado sem perder nada.
 */
class ArtActivity : ComponentActivity() {

    private class Cell(val root: LinearLayout, val icon: ImageView, val label: TextView)
    private class ToolDef(val id: Int, val icon: String, val name: String, val cat: Int, val hint: String)
    private class Tile(
        val icon: String, val title: String, val sub: String?,
        val onClick: () -> Unit, val selected: Boolean = false
    )

    private lateinit var kit: Kit
    private lateinit var art: ArtCanvas
    private lateinit var timelapse: Timelapse
    private lateinit var transformBar: LinearLayout
    private lateinit var selBar: HorizontalScrollView
    private lateinit var zoomLabel: TextView
    private lateinit var hintView: TextView
    private lateinit var undoBtn: View
    private lateinit var redoBtn: View
    private lateinit var symIcon: ImageView
    private lateinit var guideIcon: ImageView
    private lateinit var toolCell: Cell
    private lateinit var eraserCell: Cell
    private lateinit var layerCell: Cell
    private lateinit var colorDot: View
    private lateinit var focusExit: View
    private lateinit var sizeSlider: ArtSlider
    private lateinit var opacitySlider: ArtSlider

    private val chrome = ArrayList<View>()
    private var focus = false
    private var prevTool = ArtCanvas.T_PENCIL
    private var sheet: ArtSheet? = null
    private var layersRender: (() -> Unit)? = null

    private var landscape = false
    private var projId = ""
    private val saveHandler = Handler(Looper.getMainLooper())
    private val autosave = Runnable { saveNow() }
    private val hintHide = Runnable {
        if (::hintView.isInitialized) {
            hintView.animate().alpha(0f).setDuration(200).withEndAction {
                hintView.visibility = View.GONE
            }.start()
        }
    }
    private var exporting = false

    private val tools = listOf(
        ToolDef(ArtCanvas.T_PENCIL, "t_pencil", "Lápis", 0, ""),
        ToolDef(ArtCanvas.T_PEN, "t_pen", "Caneta", 0, ""),
        ToolDef(ArtCanvas.T_BRUSH, "t_brush", "Pincel", 0, ""),
        ToolDef(ArtCanvas.T_AIR, "t_air", "Aerógrafo", 0, ""),
        ToolDef(ArtCanvas.T_MARKER, "t_marker", "Marcador", 0, ""),
        ToolDef(ArtCanvas.T_SPRAY, "t_spray", "Spray", 0, ""),
        ToolDef(ArtCanvas.T_CHALK, "t_chalk", "Giz", 0, ""),
        ToolDef(ArtCanvas.T_WATER, "t_water", "Aquarela", 0, ""),
        ToolDef(ArtCanvas.T_SMUDGE, "t_smudge", "Borrar", 0, ""),
        ToolDef(ArtCanvas.T_ERASER, "t_eraser", "Borracha", 0, ""),
        ToolDef(ArtCanvas.T_LINE, "t_line", "Linha", 1, ""),
        ToolDef(ArtCanvas.T_RECT, "t_rect", "Retângulo", 1, ""),
        ToolDef(ArtCanvas.T_OVAL, "t_oval", "Elipse", 1, ""),
        ToolDef(ArtCanvas.T_FILL, "t_bucket", "Balde", 1, ""),
        ToolDef(ArtCanvas.T_GRADIENT, "t_gradient", "Gradiente", 1, "Arraste para definir a direção do degradê"),
        ToolDef(ArtCanvas.T_TEXT, "t_text", "Texto", 1, "Toque onde quer escrever"),
        ToolDef(ArtCanvas.T_SEL_RECT, "t_sel_rect", "Seleção", 2, "Arraste para selecionar um retângulo"),
        ToolDef(ArtCanvas.T_SEL_LASSO, "t_sel_lasso", "Laço", 2, "Desenhe ao redor do que quer selecionar"),
        ToolDef(ArtCanvas.T_MAGIC, "t_magic", "Varinha", 2, "Toque numa cor para selecionar a região"),
        ToolDef(ArtCanvas.T_TRANSFORM, "t_transform", "Transformar", 3, "Um dedo move; dois dedos giram e ampliam a camada"),
        ToolDef(ArtCanvas.T_LIQUIFY, "t_liquify", "Liquify", 3, "Arraste para empurrar pixels"),
        ToolDef(ArtCanvas.T_BLUR, "t_blur", "Desfoque", 3, "Arraste para desfocar a área"),
        ToolDef(ArtCanvas.T_HAND, "t_hand", "Mão", 3, "Arraste para mover a tela"),
        ToolDef(ArtCanvas.T_PICK, "t_dropper", "Conta-gotas", 3, "Toque para pegar uma cor")
    )
    private val catNames = listOf("Desenhar", "Formas", "Selecionar", "Ajustar")
    private val symNames = arrayOf("desligada", "esquerda/direita", "cima/baixo", "dupla")
    private val guideNames = arrayOf("desligada", "grade", "terços", "perspectiva", "isométrica")

    private fun toolDef(id: Int): ToolDef = tools.firstOrNull { it.id == id } ?: tools[0]

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) importImage(uri)
        }

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            when {
                focus -> setFocus(false)
                art.transforming -> art.cancelTransform()
                art.hasSelection() -> art.clearSelection()
                else -> finishSaving()
            }
        }
    }

    // ------------------------------------------------------------ helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    /** Aviso rápido e discreto sobre o desenho. */
    private fun hint(msg: String) {
        if (!::hintView.isInitialized) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            return
        }
        hintView.text = msg
        hintView.animate().cancel()
        hintView.visibility = View.VISIBLE
        hintView.alpha = 0f
        hintView.animate().alpha(1f).setDuration(150).start()
        saveHandler.removeCallbacks(hintHide)
        saveHandler.postDelayed(hintHide, 2300)
    }

    private fun toast(msg: String) = hint(msg)

    /** Aviso para quando um painel está aberto por cima do desenho. */
    private fun err(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        window.statusBarColor = AU.bg
        window.navigationBarColor = AU.bg
        onBackPressedDispatcher.addCallback(this, backCb)
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        art = ArtCanvas(this)
        art.stabilizer = 2
        art.color = 0xFF000000.toInt()

        val pid = intent.getStringExtra("pid")
        var loaded = false
        if (pid != null) {
            projId = pid
            loaded = loadProject()
        }
        if (!loaded) {
            if (projId.isEmpty()) projId = ArtStore.newId()
            val iw = intent.getIntExtra("w", 0)
            val ih = intent.getIntExtra("h", 0)
            val ibg = intent.getIntExtra("bg", Color.WHITE)
            if (iw >= 64 && ih >= 64) {
                createDoc(iw, ih, ibg)
            } else if (landscape) {
                createDoc(1350, 1080, Color.WHITE)
            } else {
                createDoc(1080, 1350, Color.WHITE)
            }
        }
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))

        buildUi()

        art.onPick = { c ->
            art.color = c
            refreshColor()
        }
        art.onHistoryChanged = { refreshHistory() }
        art.onTransformChanged = { refreshBars() }
        art.onSelectionChanged = { refreshBars() }
        art.onViewChanged = { refreshZoom() }
        art.onCommit = { onCommitted() }
        art.onTextRequest = { x, y -> showTextDialog(x, y) }
        refreshAll()
    }

    /** O aparelho girou (em pé <-> deitado): refaz o layout e reajusta o desenho. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        buildUi()
        refreshAll()
    }

    override fun onPause() {
        super.onPause()
        saveHandler.removeCallbacks(autosave)
        saveNow()
    }

    override fun onDestroy() {
        sheet?.dismiss(false)
        saveHandler.removeCallbacks(autosave)
        super.onDestroy()
    }

    private fun createDoc(w: Int, h: Int, bg: Int) {
        try {
            art.newDoc(w, h, bg)
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente. Usando uma tela menor.")
            art.newDoc(720, 900, bg)
        }
    }

    private fun loadProject(): Boolean {
        return try {
            val d = ArtStore.load(this, projId) ?: return false
            art.setDoc(d.w, d.h, d.bg, d.layers, d.cur)
            true
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    private fun onCommitted() {
        timelapse.capture(art)
        ArtPrefs.pushRecent(this, art.color)
        saveHandler.removeCallbacks(autosave)
        saveHandler.postDelayed(autosave, 4000)
        refreshLayers()
    }

    private fun saveNow() {
        if (!::art.isInitialized) return
        try {
            val snap = art.snapshot()
            val th = maxOf(1, (256f * art.docH / art.docW).toInt())
            val thumb = art.renderSmall(256, th)
            ArtStore.save(this, projId, art.docW, art.docH, art.bgColor, art.current, snap, thumb)
        } catch (e: OutOfMemoryError) {
            // sem memória para a cópia: tenta de novo na próxima alteração
        }
    }

    private fun finishSaving() {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        finish()
    }

    // ------------------------------------------------------------ interface
    private fun capsule(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = kit.glass(24)
        c.setPadding(kit.dp(4), kit.dp(4), kit.dp(4), kit.dp(4))
        c.elevation = kit.dp(6).toFloat()
        return c
    }

    private fun topBtn(icon: String, onClick: () -> Unit): FrameLayout {
        val b = FrameLayout(this)
        b.addView(kit.icon(icon), FrameLayout.LayoutParams(kit.dp(22), kit.dp(22), Gravity.CENTER))
        kit.press(b, onClick)
        return b
    }

    private fun dockCell(icon: String, caption: String, onClick: () -> Unit): Cell {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        val ic = kit.icon(icon)
        root.addView(ic, LinearLayout.LayoutParams(kit.dp(24), kit.dp(24)))
        val lb = kit.text(caption, 10f, AU.sub, true)
        lb.maxLines = 1
        lb.gravity = Gravity.CENTER
        root.addView(lb, kit.lp(A_WRAP, A_WRAP, 0, 3))
        kit.press(root, onClick)
        return Cell(root, ic, lb)
    }

    private fun chipBtn(icon: String, text: String, primary: Boolean, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(kit.dp(14), kit.dp(9), kit.dp(14), kit.dp(9))
        if (primary) row.background = kit.round(Ui.accent, 20)
        row.addView(kit.icon(icon), LinearLayout.LayoutParams(kit.dp(18), kit.dp(18)).apply { rightMargin = kit.dp(6) })
        row.addView(kit.text(text, 13f, AU.text, true))
        kit.press(row, onClick)
        return row
    }

    private fun sliderToSize(v: Int): Int {
        val t = v / 1000f
        return (1f + 199f * t * t).toInt().coerceIn(1, 200)
    }

    private fun sizeToSlider(s: Float): Int {
        val t = Math.sqrt(((s - 1f) / 199f).coerceIn(0f, 1f).toDouble()).toFloat()
        return (t * 1000f).toInt()
    }

    private fun syncSliders() {
        if (!::sizeSlider.isInitialized) return
        sizeSlider.value = sizeToSlider(art.brushSize)
        opacitySlider.value = (art.opacity * 100 / 255).coerceAtLeast(1)
    }

    private fun buildUi() {
        if (!::kit.isInitialized) kit = Kit(this)
        chrome.clear()
        sheet?.dismiss(false)
        sheet = null
        layersRender = null
        val oldParent = art.parent
        if (oldParent is ViewGroup) oldParent.removeView(art)

        val root = FrameLayout(this)
        root.setBackgroundColor(AU.bg)
        root.addView(art, FrameLayout.LayoutParams(A_MATCH, A_MATCH))

        // ---- barra superior (flutuante)
        val topLeft = capsule()
        topLeft.addView(topBtn("back") { finishSaving() }, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        val undo = topBtn("undo") { art.undo() }
        val redo = topBtn("redo") { art.redo() }
        undoBtn = undo
        redoBtn = redo
        topLeft.addView(undo, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        topLeft.addView(redo, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        root.addView(topLeft, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.START).apply {
            topMargin = kit.dp(8); leftMargin = kit.dp(10)
        })
        chrome.add(topLeft)

        val topRight = capsule()
        topRight.addView(topBtn("fit") { art.resetView() }, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        val sym = topBtn("sym") { cycleSym() }
        symIcon = sym.getChildAt(0) as ImageView
        topRight.addView(sym, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        val guide = topBtn("grid") { cycleGuide() }
        guideIcon = guide.getChildAt(0) as ImageView
        topRight.addView(guide, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        topRight.addView(topBtn("more") { showMore() }, LinearLayout.LayoutParams(kit.dp(42), kit.dp(42)))
        root.addView(topRight, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.END).apply {
            topMargin = kit.dp(8); rightMargin = kit.dp(if (landscape) 82 else 10)
        })
        chrome.add(topRight)

        zoomLabel = kit.text("100%", 11f, AU.text, true)
        zoomLabel.setPadding(kit.dp(10), kit.dp(5), kit.dp(10), kit.dp(5))
        zoomLabel.background = kit.glass(14)
        root.addView(zoomLabel, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.START).apply {
            topMargin = kit.dp(62); leftMargin = kit.dp(12)
        })
        chrome.add(zoomLabel)

        // ---- sliders de tamanho e opacidade nas bordas
        val sliderH = kit.dp(if (landscape) 190 else 240)
        val sliderLift = kit.dp(if (landscape) 0 else 70)

        sizeSlider = ArtSlider(this, true, 0)
        sizeSlider.min = 0
        sizeSlider.max = 1000
        sizeSlider.fmt = { v -> sliderToSize(v).toString() + " px" }
        sizeSlider.icon = kit.drawable("size")
        sizeSlider.onChange = { v ->
            art.brushSize = sliderToSize(v).toFloat()
            refreshColor()
        }
        root.addView(sizeSlider, FrameLayout.LayoutParams(kit.dp(130), sliderH, Gravity.START or Gravity.CENTER_VERTICAL).apply {
            leftMargin = kit.dp(6); bottomMargin = sliderLift
        })
        chrome.add(sizeSlider)

        opacitySlider = ArtSlider(this, true, 1)
        opacitySlider.min = 1
        opacitySlider.max = 100
        opacitySlider.fmt = { v -> "$v%" }
        opacitySlider.icon = kit.drawable("opacity")
        opacitySlider.onChange = { v -> art.opacity = (v * 255 / 100).coerceIn(1, 255) }
        root.addView(opacitySlider, FrameLayout.LayoutParams(kit.dp(130), sliderH, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = kit.dp(if (landscape) 76 else 6); bottomMargin = sliderLift
        })
        chrome.add(opacitySlider)

        // ---- dock de ferramentas
        val dock = LinearLayout(this)
        dock.orientation = if (landscape) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        dock.background = kit.glass(28)
        dock.elevation = kit.dp(10).toFloat()
        dock.setPadding(kit.dp(6), kit.dp(6), kit.dp(6), kit.dp(6))

        toolCell = dockCell("t_pencil", "Lápis") { showTools() }
        eraserCell = dockCell("t_eraser", "Borracha") { toggleEraser() }
        val colorRoot = LinearLayout(this)
        colorRoot.orientation = LinearLayout.VERTICAL
        colorRoot.gravity = Gravity.CENTER
        colorDot = View(this)
        colorRoot.addView(colorDot, LinearLayout.LayoutParams(kit.dp(26), kit.dp(26)))
        colorRoot.addView(kit.text("Cor", 10f, AU.sub, true), kit.lp(A_WRAP, A_WRAP, 0, 4))
        kit.press(colorRoot) { showColorPicker() }
        layerCell = dockCell("layers", "Camadas") { showLayers() }
        val brushCell = dockCell("sliders", "Pincel") { showBrush() }
        val fxCell = dockCell("sparkles", "Efeitos") { showEffects() }

        val cells = listOf(toolCell.root, eraserCell.root, colorRoot, layerCell.root, brushCell.root, fxCell.root)
        for (v in cells) {
            if (landscape) dock.addView(v, LinearLayout.LayoutParams(kit.dp(58), kit.dp(48)))
            else dock.addView(v, LinearLayout.LayoutParams(0, kit.dp(58), 1f))
        }
        if (landscape) {
            root.addView(dock, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply {
                rightMargin = kit.dp(8)
            })
        } else {
            root.addView(dock, FrameLayout.LayoutParams(A_MATCH, A_WRAP, Gravity.BOTTOM).apply {
                leftMargin = kit.dp(10); rightMargin = kit.dp(10); bottomMargin = kit.dp(10)
            })
        }
        chrome.add(dock)

        // ---- barras de contexto
        transformBar = buildTransformBar()
        root.addView(transformBar, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = kit.dp(62)
        })
        selBar = buildSelBar()
        root.addView(selBar, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = kit.dp(62); leftMargin = kit.dp(8); rightMargin = kit.dp(8)
        })

        // ---- aviso e saída do modo foco
        hintView = kit.text("", 13f, AU.text, true)
        hintView.gravity = Gravity.CENTER
        hintView.setPadding(kit.dp(16), kit.dp(10), kit.dp(16), kit.dp(10))
        hintView.background = kit.round(0xE6000000.toInt(), 20, AU.glassLine, 1f)
        hintView.visibility = View.GONE
        hintView.elevation = kit.dp(12).toFloat()
        root.addView(hintView, FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = kit.dp(if (landscape) 56 else 110)
        })

        val fx = FrameLayout(this)
        fx.background = kit.glass(22)
        fx.addView(kit.icon("fit"), FrameLayout.LayoutParams(kit.dp(20), kit.dp(20), Gravity.CENTER))
        kit.press(fx) { setFocus(false) }
        fx.visibility = View.GONE
        fx.alpha = 0.75f
        root.addView(fx, FrameLayout.LayoutParams(kit.dp(44), kit.dp(44), Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = kit.dp(12); bottomMargin = kit.dp(12)
        })
        focusExit = fx

        setContentView(root)
        applyFocusState()
        refreshAll()
    }

    private fun applyPads() {
        if (landscape) art.setPads(0f, dp(54).toFloat(), dp(72).toFloat(), 0f)
        else art.setPads(0f, dp(64).toFloat(), 0f, dp(94).toFloat())
    }

    private fun applyFocusState() {
        for (v in chrome) v.visibility = if (focus) View.GONE else View.VISIBLE
        focusExit.visibility = if (focus) View.VISIBLE else View.GONE
        if (focus) art.setPads(0f, 0f, 0f, 0f) else applyPads()
    }

    private fun setFocus(on: Boolean) {
        focus = on
        applyFocusState()
        if (on) hint("Modo foco · toque no botão para sair")
    }

    private fun buildTransformBar(): LinearLayout {
        val bar = capsule()
        bar.visibility = View.GONE
        bar.addView(chipBtn("close", "Cancelar", false) { art.cancelTransform() })
        bar.addView(chipBtn("check", "Aplicar", true) { art.applyTransform() }, kit.lp(A_WRAP, A_WRAP, 6, 0, 0, 0))
        return bar
    }

    private fun buildSelBar(): HorizontalScrollView {
        val sv = HorizontalScrollView(this)
        sv.visibility = View.GONE
        sv.isHorizontalScrollBarEnabled = false
        val bar = capsule()
        bar.addView(chipBtn("scissors", "Cortar", false) {
            if (!art.selCopyToLayer(true)) hint("Não foi possível (limite de camadas)")
            refreshLayers()
        })
        bar.addView(chipBtn("copy", "Copiar", false) {
            if (!art.selCopyToLayer(false)) hint("Não foi possível (limite de camadas)")
            refreshLayers()
        })
        bar.addView(chipBtn("t_hand", "Mover", false) {
            if (art.selCopyToLayer(true)) {
                art.clearSelection()
                setTool(ArtCanvas.T_TRANSFORM)
                refreshLayers()
            } else {
                hint("Não foi possível (limite de camadas)")
            }
        })
        bar.addView(chipBtn("trash", "Apagar", false) { art.selErase() })
        bar.addView(chipBtn("t_bucket", "Preencher", false) { art.selFill() })
        bar.addView(chipBtn("close", "Soltar", false) { art.clearSelection() })
        sv.addView(bar)
        return sv
    }

    // ------------------------------------------------------------ atualizações
    private fun setTool(id: Int) {
        if (art.tool != ArtCanvas.T_ERASER) prevTool = art.tool
        art.tool = id
        refreshTool()
        refreshBars()
        val h = toolDef(id).hint
        if (h.isNotEmpty()) hint(h)
    }

    private fun toggleEraser() {
        if (art.tool == ArtCanvas.T_ERASER) setTool(prevTool) else setTool(ArtCanvas.T_ERASER)
    }

    private fun refreshAll() {
        refreshTool()
        refreshColor()
        refreshHistory()
        refreshLayers()
        refreshSym()
        refreshGuide()
        refreshBars()
        refreshZoom()
        syncSliders()
    }

    private fun refreshTool() {
        val d = toolDef(art.tool)
        val id = kit.iconRes(d.icon)
        if (id != 0) toolCell.icon.setImageResource(id)
        toolCell.icon.imageTintList = ColorStateList.valueOf(AU.accent)
        toolCell.label.text = d.name
        toolCell.label.setTextColor(AU.accent)
        val er = art.tool == ArtCanvas.T_ERASER
        eraserCell.icon.imageTintList = ColorStateList.valueOf(if (er) AU.accent else AU.text)
        eraserCell.label.setTextColor(if (er) AU.accent else AU.sub)
    }

    private fun refreshColor() {
        val opaque = art.color or 0xFF000000.toInt()
        colorDot.background = kit.oval(opaque, 0xFFFFFFFF.toInt(), 2f)
    }

    private fun refreshHistory() {
        undoBtn.alpha = if (art.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (art.canRedo()) 1f else 0.35f
    }

    private fun refreshLayers() {
        val n = art.layers.size
        layerCell.label.text = if (n == 1) "1 camada" else "$n camadas"
    }

    private fun cycleSym() {
        art.symmetry = (art.symmetry + 1) % 4
        refreshSym()
        hint("Simetria: " + symNames[art.symmetry.coerceIn(0, 3)])
    }

    private fun refreshSym() {
        val m = art.symmetry.coerceIn(0, 3)
        symIcon.imageTintList = ColorStateList.valueOf(if (m == 0) AU.text else AU.accent)
        symIcon.rotation = if (m == 2) 90f else 0f
        symIcon.alpha = if (m == 0) 0.7f else 1f
        art.invalidate()
    }

    private fun refreshGuide() {
        guideIcon.imageTintList = ColorStateList.valueOf(if (art.guideMode == 0) AU.text else AU.accent)
        guideIcon.alpha = if (art.guideMode == 0) 0.7f else 1f
    }

    private fun refreshBars() {
        transformBar.visibility = if (art.transforming) View.VISIBLE else View.GONE
        selBar.visibility = if (art.hasSelection() && !art.transforming) View.VISIBLE else View.GONE
    }

    private fun refreshZoom() {
        val a = art.viewAngle()
        var txt = art.zoomPercent().toString() + "%"
        if (art.isFlipped()) {
            txt += " • espelhado"
        } else if (a != 0) {
            txt += " • " + a + "°"
        }
        zoomLabel.text = txt
    }

    private fun cycleGuide() {
        art.guideMode = (art.guideMode + 1) % 5
        refreshGuide()
        hint("Guia: " + guideNames[art.guideMode])
    }

    // ---------------------------------------------------------------- cores
    private fun harmony(c: Int, type: Int): List<Int> {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = ArrayList<Int>()

        fun hue(d: Float): Int {
            var h = hsv[0] + d
            while (h < 0f) h += 360f
            while (h >= 360f) h -= 360f
            return Color.HSVToColor(floatArrayOf(h, hsv[1], hsv[2]))
        }

        when (type) {
            0 -> out.add(hue(180f))
            1 -> {
                out.add(hue(-30f))
                out.add(hue(30f))
            }
            2 -> {
                out.add(hue(120f))
                out.add(hue(240f))
            }
            else -> {
                for (v in floatArrayOf(0.25f, 0.5f, 0.75f, 1f)) {
                    out.add(Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v)))
                }
            }
        }
        return out
    }

    // ------------------------------------------------------- componentes de painel
    private fun sectionTitle(t: String): TextView {
        val tv = kit.text(t.uppercase(), 11f, AU.sub, true)
        tv.letterSpacing = 0.08f
        tv.setPadding(kit.dp(2), kit.dp(14), 0, kit.dp(8))
        return tv
    }

    private fun settingRow(
        title: String, min: Int, max: Int, initial: Int, fmt: (Int) -> String,
        onChange: (Int) -> Unit, onDone: (() -> Unit)? = null
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, kit.dp(4), 0, kit.dp(2))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(kit.text(title, 13f, AU.sub, true), LinearLayout.LayoutParams(0, A_WRAP, 1f))
        val value = kit.text(fmt(initial), 13f, AU.text, true)
        head.addView(value)
        box.addView(head)
        val sl = ArtSlider(this, false)
        sl.min = min
        sl.max = max
        sl.value = initial
        sl.onChange = { v ->
            value.text = fmt(v)
            onChange(v)
        }
        sl.onFinish = { onDone?.invoke() }
        box.addView(sl, LinearLayout.LayoutParams(A_MATCH, kit.dp(32)))
        return box
    }

    private fun field(hint: String, text: String, lines: Int = 1): EditText {
        val et = EditText(this)
        et.setText(text)
        et.hint = hint
        et.setTextColor(AU.text)
        et.setHintTextColor(AU.sub)
        et.textSize = 15f
        et.background = kit.round(AU.surface, 14)
        et.setPadding(kit.dp(14), kit.dp(12), kit.dp(14), kit.dp(12))
        if (lines > 1) {
            et.minLines = lines
            et.gravity = Gravity.TOP
        } else {
            et.setSingleLine()
        }
        return et
    }

    private fun tileView(t: Tile): LinearLayout {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        v.setPadding(kit.dp(4), kit.dp(8), kit.dp(4), kit.dp(8))
        v.background = if (t.selected) kit.round(AU.accentSoft(), 16, AU.accent, 1.5f) else kit.round(AU.surface, 16)
        v.addView(kit.icon(t.icon, if (t.selected) AU.accent else AU.text), LinearLayout.LayoutParams(kit.dp(28), kit.dp(28)))
        val tt = kit.text(t.title, 11.5f, if (t.selected) AU.accent else AU.text, true)
        tt.gravity = Gravity.CENTER
        tt.maxLines = 1
        v.addView(tt, kit.lp(A_WRAP, A_WRAP, 0, 6))
        if (t.sub != null) {
            val st = kit.text(t.sub, 10f, AU.sub)
            st.gravity = Gravity.CENTER
            st.maxLines = 1
            v.addView(st, kit.lp(A_WRAP, A_WRAP, 0, 1))
        }
        kit.press(v, t.onClick)
        return v
    }

    private fun tileGrid(tiles: List<Tile>, cols: Int): LinearLayout {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until cols) {
                val lpTile = LinearLayout.LayoutParams(0, kit.dp(88), 1f)
                lpTile.setMargins(kit.dp(4), kit.dp(4), kit.dp(4), kit.dp(4))
                if (i + k < tiles.size) row.addView(tileView(tiles[i + k]), lpTile)
                else row.addView(View(this), lpTile)
            }
            grid.addView(row)
            i += cols
        }
        return grid
    }

    private fun colorStrip(colors: List<Int>, current: Int, first: View?, onPick: (Int) -> Unit): HorizontalScrollView {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        if (first != null) row.addView(first, LinearLayout.LayoutParams(kit.dp(38), kit.dp(38)).apply { rightMargin = kit.dp(8) })
        val cur = current or 0xFF000000.toInt()
        for (c in colors) {
            val opaque = c or 0xFF000000.toInt()
            val d = View(this)
            d.background = if (opaque == cur) kit.oval(opaque, 0xFFFFFFFF.toInt(), 2.5f) else kit.oval(opaque, 0x55FFFFFF, 1f)
            d.setOnClickListener { onPick(opaque) }
            row.addView(d, LinearLayout.LayoutParams(kit.dp(38), kit.dp(38)).apply { rightMargin = kit.dp(8) })
        }
        hs.addView(row)
        return hs
    }

    // ----------------------------------------------------------- ferramentas
    private fun showTools() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Ferramentas")
        sheet = s
        var cat = toolDef(art.tool).cat
        val tabsHolder = FrameLayout(this)
        fun render() {
            tabsHolder.removeAllViews()
            tabsHolder.addView(kit.segmented(catNames, cat, 12f) { i ->
                cat = i
                render()
            })
            s.body.removeAllViews()
            val tiles = tools.filter { it.cat == cat }.map { d ->
                Tile(d.icon, d.name, null, {
                    s.dismiss(true)
                    setTool(d.id)
                }, d.id == art.tool)
            }
            s.body.addView(tileGrid(tiles, 4))
        }
        render()
        s.pinned.addView(tabsHolder, kit.lp(A_MATCH, A_WRAP, 0, 0, 0, 8))
        s.show()
    }

    // ---------------------------------------------------------------- pincel
    private fun favChip(text: String, primary: Boolean, onClick: () -> Unit, onLong: (() -> Unit)? = null): TextView {
        val t = kit.text(text, 12.5f, if (primary) Color.WHITE else AU.text, true)
        t.setPadding(kit.dp(14), kit.dp(10), kit.dp(14), kit.dp(10))
        t.background = if (primary) kit.round(Ui.accent, 18) else kit.round(AU.surface, 18)
        t.setOnClickListener { onClick() }
        if (onLong != null) {
            t.setOnLongClickListener {
                onLong()
                true
            }
        }
        return t
    }

    private fun showBrush() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Ajustes do pincel")
        sheet = s
        val prev = BrushPreview(this)
        fun upd() {
            prev.color = art.color
            prev.size = art.brushSize
            prev.opacity = art.opacity
            prev.hardness = art.hardness
            prev.invalidate()
        }
        upd()
        s.pinned.addView(prev, kit.lp(A_MATCH, kit.dp(84), 0, 0, 0, 6))

        val b = s.body
        b.addView(settingRow("Tamanho", 0, 1000, sizeToSlider(art.brushSize), { v -> "${sliderToSize(v)} px" }, { v ->
            art.brushSize = sliderToSize(v).toFloat()
            refreshColor()
            syncSliders()
            upd()
        }))
        b.addView(settingRow("Opacidade", 1, 100, (art.opacity * 100 / 255).coerceAtLeast(1), { v -> "$v%" }, { v ->
            art.opacity = (v * 255 / 100).coerceIn(1, 255)
            syncSliders()
            upd()
        }))
        b.addView(settingRow("Dureza", 0, 100, art.hardness.coerceIn(0, 100), { v -> "$v%" }, { v ->
            art.hardness = v
            upd()
        }))
        b.addView(settingRow("Fluxo", 1, 100, art.flow.coerceIn(1, 100), { v -> "$v%" }, { v -> art.flow = v }))
        b.addView(settingRow("Espaçamento", 5, 80, art.spacing.coerceIn(5, 80), { v -> "$v%" }, { v -> art.spacing = v }))
        b.addView(settingRow("Estabilizador", 0, 10, art.stabilizer.coerceIn(0, 10), { v -> if (v == 0) "off" else "$v" }, { v ->
            art.stabilizer = v
        }))

        // pressão
        val pr = LinearLayout(this)
        pr.orientation = LinearLayout.HORIZONTAL
        pr.gravity = Gravity.CENTER_VERTICAL
        pr.setPadding(0, kit.dp(12), 0, kit.dp(2))
        pr.addView(kit.text("Sensibilidade à pressão", 13f, AU.sub, true), LinearLayout.LayoutParams(0, A_WRAP, 1f))
        val sw = kit.text("", 12f, Color.WHITE, true)
        sw.setPadding(kit.dp(14), kit.dp(7), kit.dp(14), kit.dp(7))
        fun paintSw() {
            sw.text = if (art.pressureOn) "Ligada" else "Desligada"
            sw.background = if (art.pressureOn) kit.round(Ui.accent, 16) else kit.round(AU.surface2, 16)
        }
        paintSw()
        sw.setOnClickListener {
            art.pressureOn = !art.pressureOn
            paintSw()
        }
        pr.addView(sw)
        b.addView(pr)

        // simetria
        b.addView(sectionTitle("Simetria"))
        val symHolder = FrameLayout(this)
        fun renderSym() {
            symHolder.removeAllViews()
            symHolder.addView(kit.segmented(listOf("Off", "Esq./dir.", "Cima/baixo", "Dupla"), art.symmetry.coerceIn(0, 3), 11.5f) { i ->
                art.symmetry = i
                refreshSym()
                renderSym()
            })
        }
        renderSym()
        b.addView(symHolder)

        // guia
        b.addView(sectionTitle("Guia de desenho"))
        val guideHolder = FrameLayout(this)
        fun renderGuide() {
            guideHolder.removeAllViews()
            guideHolder.addView(kit.segmented(listOf("Off", "Grade", "Terços", "Perspec.", "Isométr."), art.guideMode.coerceIn(0, 4), 11f) { i ->
                art.guideMode = i
                refreshGuide()
                renderGuide()
            })
        }
        renderGuide()
        b.addView(guideHolder)

        // favoritos
        b.addView(sectionTitle("Favoritos"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val favRow = LinearLayout(this)
        favRow.orientation = LinearLayout.HORIZONTAL
        favRow.addView(favChip("＋ Salvar atual", true, {
            ArtPrefs.addPreset(
                this,
                ArtPrefs.Preset(art.tool, art.brushSize.toInt(), art.opacity, art.hardness, art.flow, art.spacing, art.stabilizer)
            )
            s.dismiss(false)
            showBrush()
        }), kit.lp(A_WRAP, A_WRAP, 0, 0, 8, 0))
        val presets = ArtPrefs.presets(this)
        presets.forEachIndexed { i, p ->
            val nm = "★ " + toolDef(p.tool).name + " " + p.size + "px"
            favRow.addView(favChip(nm, false, {
                if (art.tool != ArtCanvas.T_ERASER) prevTool = art.tool
                art.tool = p.tool
                art.brushSize = p.size.toFloat()
                art.opacity = p.opacity
                art.hardness = p.hardness
                art.flow = p.flow
                art.spacing = p.spacing
                art.stabilizer = p.stab
                refreshAll()
                s.dismiss(false)
                showBrush()
            }, {
                ArtPrefs.removePreset(this, i)
                s.dismiss(false)
                showBrush()
                err("Favorito removido")
            }), kit.lp(A_WRAP, A_WRAP, 0, 0, 8, 0))
        }
        hs.addView(favRow)
        b.addView(hs)
        if (presets.isEmpty()) {
            b.addView(kit.text("Salve o ajuste atual para reutilizar. Segure um favorito para remover.", 11.5f, AU.sub).apply {
                setPadding(kit.dp(2), kit.dp(8), 0, 0)
            })
        }
        s.show()
    }

    // ------------------------------------------------------------------- cor
    private fun showColorPicker() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Cor")
        sheet = s
        val startColor = art.color or 0xFF000000.toInt()

        val wheel = ColorWheelView(this)
        wheel.setColor(art.color)
        s.body.addView(wheel, LinearLayout.LayoutParams(kit.dp(250), kit.dp(250)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val prow = LinearLayout(this)
        prow.orientation = LinearLayout.HORIZONTAL
        prow.gravity = Gravity.CENTER_VERTICAL
        val swatch = LinearLayout(this)
        swatch.orientation = LinearLayout.HORIZONTAL
        val swOld = View(this)
        swOld.setBackgroundColor(startColor)
        val swNew = View(this)
        swNew.setBackgroundColor(startColor)
        swatch.addView(swOld, LinearLayout.LayoutParams(0, A_MATCH, 1f))
        swatch.addView(swNew, LinearLayout.LayoutParams(0, A_MATCH, 1f))
        kit.clipRound(swatch, 14)
        prow.addView(swatch, LinearLayout.LayoutParams(kit.dp(96), kit.dp(46)))
        val hex = field("#RRGGBB", "")
        hex.gravity = Gravity.CENTER
        prow.addView(hex, kit.lp(0, A_WRAP, 10, 0, 0, 0).apply { weight = 1f })
        s.body.addView(prow, kit.lp(A_MATCH, A_WRAP, 0, 10, 0, 0))

        var updatingHex = false
        var harmType = 0
        val harmRow = LinearLayout(this)
        harmRow.orientation = LinearLayout.HORIZONTAL
        var applyRef: (Int) -> Unit = { }

        fun updatePreview(c: Int, setHex: Boolean) {
            val opaque = c or 0xFF000000.toInt()
            swNew.setBackgroundColor(opaque)
            if (setHex) {
                updatingHex = true
                hex.setText(String.format("#%06X", c and 0xFFFFFF))
                updatingHex = false
            }
        }

        fun fillHarm(c: Int) {
            harmRow.removeAllViews()
            for (col in harmony(c, harmType)) {
                val d = View(this)
                d.background = kit.oval(col or 0xFF000000.toInt(), 0x66FFFFFF, 1.5f)
                d.setOnClickListener { applyRef(col) }
                harmRow.addView(d, LinearLayout.LayoutParams(kit.dp(40), kit.dp(40)).apply { rightMargin = kit.dp(10) })
            }
        }

        applyRef = { c ->
            wheel.setColor(c)
            art.color = c
            refreshColor()
            updatePreview(c, true)
            fillHarm(c)
        }

        wheel.onColor = { c ->
            art.color = c
            refreshColor()
            updatePreview(c, true)
            fillHarm(c)
        }
        hex.doAfterTextChanged { e ->
            if (!updatingHex) {
                val t = e.toString().trim().removePrefix("#")
                if (t.length == 6) {
                    val v = t.toLongOrNull(16)
                    if (v != null) {
                        val col = 0xFF000000.toInt() or v.toInt()
                        wheel.setColor(col)
                        art.color = col
                        refreshColor()
                        updatePreview(col, false)
                        fillHarm(col)
                    }
                }
            }
        }
        updatePreview(art.color, true)
        fillHarm(art.color)

        s.body.addView(sectionTitle("Harmonias"))
        val hnames = listOf("Complementar", "Análogas", "Tríade", "Tons")
        val hHolder = FrameLayout(this)
        fun renderHarmTabs() {
            hHolder.removeAllViews()
            hHolder.addView(kit.segmented(hnames, harmType, 11f) { i ->
                harmType = i
                renderHarmTabs()
                fillHarm(wheel.getColor())
            })
        }
        renderHarmTabs()
        s.body.addView(hHolder)
        val hs0 = HorizontalScrollView(this)
        hs0.isHorizontalScrollBarEnabled = false
        hs0.addView(harmRow)
        s.body.addView(hs0, kit.lp(A_MATCH, A_WRAP, 0, 10, 0, 0))

        val recents = ArtPrefs.recents(this)
        if (recents.isNotEmpty()) {
            s.body.addView(sectionTitle("Recentes"))
            s.body.addView(colorStrip(recents, art.color, null) { c -> applyRef(c) })
        }

        s.body.addView(sectionTitle("Minhas cores"))
        val plus = FrameLayout(this)
        plus.background = kit.oval(AU.surface2, 0x66FFFFFF, 1.5f)
        plus.addView(kit.icon("plus"), FrameLayout.LayoutParams(kit.dp(18), kit.dp(18), Gravity.CENTER))
        plus.setOnClickListener {
            ArtStore.addPalette(this, wheel.getColor())
            s.dismiss(false)
            showColorPicker()
        }
        s.body.addView(colorStrip(ArtStore.palette(this), art.color, plus) { c -> applyRef(c) })

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(kit.button("Conta-gotas", "t_dropper", false) {
            s.dismiss(true)
            setTool(ArtCanvas.T_PICK)
        }, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply { rightMargin = kit.dp(6) })
        btns.addView(kit.button("Concluir", "check", true) {
            ArtStore.addPalette(this, wheel.getColor())
            s.dismiss(true)
        }, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply { leftMargin = kit.dp(6) })
        s.footer.addView(btns)
        s.show()
    }

    // ----------------------------------------------------------------- texto
    private fun showTextDialog(x: Float, y: Float) {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Texto")
        sheet = s
        val et = field("Digite o texto", "", 3)
        s.body.addView(et, kit.lp(A_MATCH, A_WRAP, 0, 0, 0, 8))
        var size = 64
        var style = 0
        s.body.addView(settingRow("Tamanho", 8, 300, 64, { v -> "$v px" }, { v -> size = v }))
        s.body.addView(sectionTitle("Estilo"))
        val holder = FrameLayout(this)
        fun renderStyle() {
            holder.removeAllViews()
            holder.addView(kit.segmented(listOf("Normal", "Negrito", "Itálico"), style, 13f) { i ->
                style = i
                renderStyle()
            })
        }
        renderStyle()
        s.body.addView(holder)
        s.footer.addView(kit.button("Inserir texto", "check", true) {
            val t = et.text.toString()
            if (t.isNotBlank()) art.drawText(x, y, t, size.toFloat(), style == 1, style == 2)
            s.dismiss(true)
        })
        s.show()
    }

    // --------------------------------------------------------------- camadas
    private fun renameLayer(cur: ArtCanvas.Layer) {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Nome da camada")
        sheet = s
        val et = field("Nome", cur.name)
        s.body.addView(et)
        s.footer.addView(kit.button("Salvar", "check", true) {
            val t = et.text.toString().trim()
            if (t.isNotEmpty()) {
                cur.name = t
                art.layerChanged()
            }
            s.dismiss(false)
            showLayers()
        })
        s.show()
    }

    private fun showLayers() {
        if (art.layers.isEmpty()) return
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Camadas")
        sheet = s
        s.onDismiss = { layersRender = null }

        fun render() {
            s.pinned.removeAllViews()
            s.body.removeAllViews()
            refreshLayers()

            val acts = LinearLayout(this)
            acts.orientation = LinearLayout.HORIZONTAL
            fun action(icon: String, cap: String, f: () -> Unit) {
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.setPadding(0, kit.dp(9), 0, kit.dp(8))
                cell.background = kit.round(AU.surface, 14)
                cell.addView(kit.icon(icon), LinearLayout.LayoutParams(kit.dp(20), kit.dp(20)))
                val t = kit.text(cap, 10f, AU.sub, true)
                t.maxLines = 1
                cell.addView(t, kit.lp(A_WRAP, A_WRAP, 0, 3))
                kit.press(cell) {
                    f()
                    render()
                }
                acts.addView(cell, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply {
                    setMargins(kit.dp(2), 0, kit.dp(2), 0)
                })
            }
            action("plus", "Nova") { if (!art.addLayer()) err("Máximo de " + ArtCanvas.MAX_LAYERS + " camadas") }
            action("copy", "Duplicar") { if (!art.duplicateCurrent()) err("Não foi possível duplicar") }
            action("merge", "Mesclar") { if (!art.mergeDown()) err("Não há camada abaixo") }
            action("t_eraser", "Limpar") { art.clearCurrent() }
            action("trash", "Excluir") { if (!art.removeCurrent()) err("Mantenha ao menos uma camada") }
            action("up", "Subir") { art.moveCurrent(true) }
            action("down", "Descer") { art.moveCurrent(false) }
            s.pinned.addView(acts, kit.lp(A_MATCH, A_WRAP, 0, 0, 0, 8))

            for (idx in art.layers.indices.reversed()) {
                val l = art.layers[idx]
                val on = idx == art.current
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.gravity = Gravity.CENTER_VERTICAL
                line.setPadding(kit.dp(6), kit.dp(8), kit.dp(10), kit.dp(8))
                line.background = if (on) kit.round(AU.accentSoft(), 16, AU.accent, 1.5f) else kit.round(AU.surface, 16)

                val eye = FrameLayout(this)
                eye.addView(
                    kit.icon(if (l.visible) "eye" else "eye_off", if (l.visible) AU.text else AU.sub),
                    FrameLayout.LayoutParams(kit.dp(20), kit.dp(20), Gravity.CENTER)
                )
                eye.setOnClickListener {
                    l.visible = !l.visible
                    art.layerChanged()
                    render()
                }
                line.addView(eye, LinearLayout.LayoutParams(kit.dp(40), kit.dp(40)))

                val th = (56 * art.docH / art.docW).coerceIn(28, 72)
                val thumb = ImageView(this)
                thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                thumb.background = kit.checker()
                kit.clipRound(thumb, 8)
                try {
                    thumb.setImageBitmap(Bitmap.createScaledBitmap(l.bmp, 64, maxOf(1, 64 * art.docH / art.docW), true))
                } catch (_: Exception) { }
                line.addView(thumb, LinearLayout.LayoutParams(kit.dp(56), kit.dp(th)).apply { leftMargin = kit.dp(4) })

                val info = LinearLayout(this)
                info.orientation = LinearLayout.VERTICAL
                val nm = kit.text(l.name, 14f, AU.text, true)
                nm.maxLines = 1
                info.addView(nm)
                info.addView(
                    kit.text(
                        ArtCanvas.BLEND_NAMES[l.blend.coerceIn(0, ArtCanvas.BLEND_NAMES.size - 1)] +
                            " • " + (l.opacity * 100 / 255) + "%", 11f, AU.sub
                    ), kit.lp(A_WRAP, A_WRAP, 0, 2)
                )
                line.addView(info, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply { leftMargin = kit.dp(10) })
                if (l.clipping) line.addView(kit.icon("scissors", AU.accent), LinearLayout.LayoutParams(kit.dp(16), kit.dp(16)).apply { leftMargin = kit.dp(4) })
                if (l.alphaLock) line.addView(kit.icon("unlock", AU.accent), LinearLayout.LayoutParams(kit.dp(16), kit.dp(16)).apply { leftMargin = kit.dp(4) })
                if (l.locked) line.addView(kit.icon("lock", AU.sub), LinearLayout.LayoutParams(kit.dp(16), kit.dp(16)).apply { leftMargin = kit.dp(4) })
                line.setOnClickListener {
                    art.selectLayer(idx)
                    render()
                }
                s.body.addView(line, kit.lp(A_MATCH, A_WRAP, 0, 0, 0, 6))
            }

            val cur = art.layers[art.current.coerceIn(0, art.layers.size - 1)]
            s.body.addView(sectionTitle("Selecionada · " + cur.name))
            s.body.addView(settingRow("Opacidade", 0, 100, cur.opacity * 100 / 255, { v -> "$v%" }, { v ->
                cur.opacity = v * 255 / 100
                art.invalidate()
            }, {
                art.layerChanged()
                render()
            }))

            s.body.addView(sectionTitle("Modo de mistura"))
            val bs = HorizontalScrollView(this)
            bs.isHorizontalScrollBarEnabled = false
            val br = LinearLayout(this)
            br.orientation = LinearLayout.HORIZONTAL
            for (i in ArtCanvas.BLEND_NAMES.indices) {
                val sel = cur.blend == i
                val t = kit.text(ArtCanvas.BLEND_NAMES[i], 12f, if (sel) Color.WHITE else AU.sub, true)
                t.setPadding(kit.dp(14), kit.dp(9), kit.dp(14), kit.dp(9))
                t.background = if (sel) kit.round(Ui.accent, 16) else kit.round(AU.surface, 16)
                t.setOnClickListener {
                    cur.blend = i
                    art.layerChanged()
                    render()
                }
                br.addView(t, kit.lp(A_WRAP, A_WRAP, 0, 0, 6, 0))
            }
            bs.addView(br)
            s.body.addView(bs)

            val tg = LinearLayout(this)
            tg.orientation = LinearLayout.HORIZONTAL
            fun toggle(icon: String, text: String, active: Boolean, rerender: Boolean, f: () -> Unit) {
                val p = LinearLayout(this)
                p.orientation = LinearLayout.HORIZONTAL
                p.gravity = Gravity.CENTER
                p.setPadding(kit.dp(14), kit.dp(10), kit.dp(14), kit.dp(10))
                p.background = if (active) kit.round(AU.accentSoft(), 18, AU.accent, 1.2f) else kit.round(AU.surface, 18)
                p.addView(kit.icon(icon, if (active) AU.accent else AU.text), LinearLayout.LayoutParams(kit.dp(16), kit.dp(16)).apply { rightMargin = kit.dp(6) })
                p.addView(kit.text(text, 12.5f, if (active) AU.accent else AU.text, true))
                p.setOnClickListener {
                    f()
                    if (rerender) render()
                }
                tg.addView(p, kit.lp(A_WRAP, A_WRAP, 0, 0, 8, 0))
            }
            toggle(if (cur.alphaLock) "unlock" else "lock", "Alpha lock", cur.alphaLock, true) {
                cur.alphaLock = !cur.alphaLock
                art.layerChanged()
            }
            toggle("scissors", "Clipping", cur.clipping, true) {
                cur.clipping = !cur.clipping
                art.layerChanged()
            }
            toggle("lock", "Bloquear", cur.locked, true) {
                cur.locked = !cur.locked
                art.layerChanged()
            }
            toggle("edit", "Renomear", false, false) { renameLayer(cur) }
            val tgs = HorizontalScrollView(this)
            tgs.isHorizontalScrollBarEnabled = false
            tgs.addView(tg)
            s.body.addView(tgs, kit.lp(A_MATCH, A_WRAP, 0, 12, 0, 0))
        }

        layersRender = { render() }
        render()
        s.show()
    }

    // ------------------------------------------------------------ mais opções
    private fun showMore() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "47 Art")
        sheet = s
        fun go(f: () -> Unit): () -> Unit = {
            s.dismiss(false)
            f()
        }
        val tiles = listOf(
            Tile("newdoc", "Novo", null, go { askNewDoc(false) }),
            Tile("resize", "Papel", null, go { askNewDoc(true) }),
            Tile("image", "Referência", null, go { pickImage.launch("image/*") }),
            Tile("download", "PNG", "na galeria", go { exportImage(true, false) }),
            Tile("download", "JPG", "na galeria", go { exportImage(false, false) }),
            Tile("share", "Enviar", null, go { exportImage(true, true) }),
            Tile("film", "Timelapse", "vídeo", go { exportTimelapse() }),
            Tile("flip", "Espelhar", "a visão", go { art.flipView() }),
            Tile("rotate", "Girar", if (art.rotateGesture) "2 dedos: on" else "2 dedos: off", {
                art.rotateGesture = !art.rotateGesture
                s.dismiss(false)
                showMore()
            }),
            Tile("focus", "Modo foco", null, go { setFocus(true) }),
            Tile("exit", "Salvar e sair", null, go { finishSaving() })
        )
        s.body.addView(tileGrid(tiles, 4))
        s.body.addView(
            kit.text(
                "Dicas: toque com 2 dedos desfaz, 3 dedos refaz. Pinça dá zoom e 2 dedos giram a tela. " +
                    "Segure um favorito do pincel para remover.", 12f, AU.sub
            ).apply { setPadding(kit.dp(4), kit.dp(10), kit.dp(4), kit.dp(6)) }
        )
        s.show()
    }

    // ---------------------------------------------------------------- efeitos
    private fun showEffects() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Efeitos · camada atual")
        sheet = s
        fun go(f: () -> Unit): () -> Unit = {
            s.dismiss(false)
            f()
        }
        fun fx(f: () -> Unit): () -> Unit = {
            s.dismiss(false)
            f()
            hint("Efeito aplicado")
        }
        val tiles = listOf(
            Tile("sliders", "Brilho/Contraste", null, go { applyBrightnessContrast() }),
            Tile("palette", "Matiz/Satur.", null, go { applyHueSat() }),
            Tile("f_invert", "Inverter", null, fx { art.applyFilterInvert() }),
            Tile("f_gray", "Cinza", null, fx { art.applyFilterGrayscale() }),
            Tile("f_dots", "Screentone", null, fx { art.applyFilterScreentone() }),
            Tile("f_emboss", "Relevo", null, fx { art.applyFilterEmboss() }),
            Tile("t_blur", "Desfoque", "leve", fx { art.applyFilterBlurLight() })
        )
        s.body.addView(tileGrid(tiles, 4))
        s.show()
    }

    private fun applyBrightnessContrast() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Brilho / Contraste")
        sheet = s
        var bright = 0
        var contr = 0
        s.body.addView(settingRow("Brilho", -50, 50, 0, { v -> "$v" }, { v -> bright = v }))
        s.body.addView(settingRow("Contraste", -50, 50, 0, { v -> "$v" }, { v -> contr = v }))
        s.footer.addView(kit.button("Aplicar", "check", true) {
            art.applyFilterBrightnessContrast(bright, contr)
            s.dismiss(true)
            hint("Efeito aplicado")
        })
        s.show()
    }

    private fun applyHueSat() {
        sheet?.dismiss(false)
        val s = ArtSheet(this, kit, "Matiz / Saturação")
        sheet = s
        var hue = 0
        var sat = 0
        s.body.addView(settingRow("Matiz", -180, 180, 0, { v -> "$v" }, { v -> hue = v }))
        s.body.addView(settingRow("Saturação", -100, 100, 0, { v -> "$v" }, { v -> sat = v }))
        s.footer.addView(kit.button("Aplicar", "check", true) {
            art.applyFilterHueSat(hue, sat)
            s.dismiss(true)
            hint("Efeito aplicado")
        })
        s.show()
    }

    /**
     * Dialog moderno de tamanho do papel.
     * @param resize se true, redimensiona o documento atual em vez de criar novo.
     */
    private fun askNewDoc(resize: Boolean) {
        val dm = resources.displayMetrics
        val sw = (minOf(dm.widthPixels, 1440) / 2) * 2
        val sh = (minOf(dm.heightPixels, 2560) / 2) * 2

        // name, w, h, group
        val presets = listOf(
            arrayOf("Quadrado", "1080", "1080", "Social"),
            arrayOf("Instagram post", "1080", "1350", "Social"),
            arrayOf("Instagram story", "1080", "1920", "Social"),
            arrayOf("YouTube thumb", "1280", "720", "Social"),
            arrayOf("Twitter/X", "1600", "900", "Social"),
            arrayOf("Retrato", "1080", "1440", "Geral"),
            arrayOf("Paisagem", "1440", "1080", "Geral"),
            arrayOf("HD 720p", "1280", "720", "Vídeo"),
            arrayOf("Full HD", "1920", "1080", "Vídeo"),
            arrayOf("2K", "2560", "1440", "Vídeo"),
            arrayOf("A4 150dpi", "1240", "1754", "Impressão"),
            arrayOf("A4 300dpi", "2480", "3508", "Impressão"),
            arrayOf("A5 150dpi", "874", "1240", "Impressão"),
            arrayOf("Tela do aparelho", sw.toString(), sh.toString(), "Aparelho"),
            arrayOf("Atual (${art.docW}×${art.docH})", art.docW.toString(), art.docH.toString(), "Aparelho")
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        // Custom size inputs
        root.addView(label("Tamanho personalizado (px)", 13f, A_GREY, true).apply {
            setPadding(0, dp(4), 0, dp(8))
        })
        val sizeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun numField(hint: String, value: Int): EditText {
            return EditText(this).apply {
                setText(value.toString())
                setHint(hint)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setTextColor(A_WHITE)
                setHintTextColor(0xFF888888.toInt())
                setBackgroundColor(0xFF2A2A2A.toInt())
                setPadding(dp(12), dp(10), dp(12), dp(10))
                filters = arrayOf(android.text.InputFilter.LengthFilter(4))
            }
        }
        val wField = numField("Largura", if (resize) art.docW else 1080)
        val hField = numField("Altura", if (resize) art.docH else 1350)
        sizeRow.addView(wField, LinearLayout.LayoutParams(0, A_WRAP, 1f))
        sizeRow.addView(label(" × ", 16f, A_WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
        sizeRow.addView(hField, LinearLayout.LayoutParams(0, A_WRAP, 1f))
        root.addView(sizeRow)

        // Swap button
        val swap = label("⇄ Trocar largura ↔ altura", 12f, Ui.accent, true).apply {
            setPadding(0, dp(8), 0, dp(4))
            setOnClickListener {
                val a = wField.text.toString()
                wField.setText(hField.text.toString())
                hField.setText(a)
            }
        }
        root.addView(swap)

        // Background (only for new)
        var bgChoice = Color.WHITE
        if (!resize) {
            root.addView(label("Fundo", 13f, A_GREY, true).apply { setPadding(0, dp(12), 0, dp(6)) })
            val bgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val bgOpts = listOf(
                Triple("Branco", Color.WHITE, 0xFFFFFFFF.toInt()),
                Triple("Preto", Color.BLACK, 0xFF222222.toInt()),
                Triple("Cinza", 0xFF808080.toInt(), 0xFF808080.toInt()),
                Triple("Transp.", Color.TRANSPARENT, 0xFF333333.toInt())
            )
            val bgBtns = ArrayList<TextView>()
            bgOpts.forEachIndexed { i, (name, col, _) ->
                val b = label(name, 11f, A_WHITE, i == 0).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(10), 0, dp(10))
                    background = round(if (i == 0) Ui.accent else 0xFF2A2A2A.toInt(), 12)
                    setOnClickListener {
                        bgChoice = col
                        bgBtns.forEachIndexed { j, tv ->
                            tv.background = round(if (j == i) Ui.accent else 0xFF2A2A2A.toInt(), 12)
                            tv.typeface = if (j == i) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        }
                    }
                }
                bgBtns.add(b)
                bgRow.addView(b, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply {
                    leftMargin = dp(3); rightMargin = dp(3)
                })
            }
            root.addView(bgRow)
        } else {
            root.addView(label("Modo ao redimensionar", 13f, A_GREY, true).apply { setPadding(0, dp(12), 0, dp(6)) })
        }
        var stretch = false
        if (resize) {
            val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val m1 = label("Centralizar", 12f, A_WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                background = round(Ui.accent, 12)
            }
            val m2 = label("Esticar", 12f, A_WHITE, false).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                background = round(0xFF2A2A2A.toInt(), 12)
            }
            m1.setOnClickListener {
                stretch = false
                m1.background = round(Ui.accent, 12); m1.typeface = Typeface.DEFAULT_BOLD
                m2.background = round(0xFF2A2A2A.toInt(), 12); m2.typeface = Typeface.DEFAULT
            }
            m2.setOnClickListener {
                stretch = true
                m2.background = round(Ui.accent, 12); m2.typeface = Typeface.DEFAULT_BOLD
                m1.background = round(0xFF2A2A2A.toInt(), 12); m1.typeface = Typeface.DEFAULT
            }
            modeRow.addView(m1, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply { rightMargin = dp(4) })
            modeRow.addView(m2, LinearLayout.LayoutParams(0, A_WRAP, 1f).apply { leftMargin = dp(4) })
            root.addView(modeRow)
        }

        // Presets scroll
        root.addView(label("Formatos prontos", 13f, A_GREY, true).apply {
            setPadding(0, dp(14), 0, dp(6))
        })
        val presetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var lastGroup = ""
        for (pr in presets) {
            val pName = pr[0]
            val pW = pr[1]
            val pH = pr[2]
            val pGroup = pr[3]
            if (pGroup != lastGroup) {
                lastGroup = pGroup
                presetBox.addView(label(pGroup.uppercase(), 10f, 0xFF888888.toInt(), true).apply {
                    setPadding(dp(4), dp(8), 0, dp(4))
                    letterSpacing = 0.08f
                })
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = round(0xFF222222.toInt(), 12)
                setOnClickListener {
                    wField.setText(pW)
                    hField.setText(pH)
                }
            }
            row.addView(label(pName, 13f, A_WHITE), LinearLayout.LayoutParams(0, A_WRAP, 1f))
            row.addView(label("${pW}×${pH}", 12f, Ui.accent, true))
            presetBox.addView(row, LinearLayout.LayoutParams(A_MATCH, A_WRAP).apply {
                bottomMargin = dp(4)
            })
        }
        val sv = ScrollView(this)
        sv.addView(presetBox)
        root.addView(sv, LinearLayout.LayoutParams(A_MATCH, dp(220)))

        val title = if (resize) "Redimensionar papel" else "Novo desenho — tamanho do papel"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(root)
            .setPositiveButton(if (resize) "Redimensionar" else "Criar") { _, _ ->
                val w = wField.text.toString().toIntOrNull()?.coerceIn(64, 4096) ?: 0
                val h = hField.text.toString().toIntOrNull()?.coerceIn(64, 4096) ?: 0
                if (w < 64 || h < 64) {
                    toast("Largura e altura mínimas: 64 px")
                    return@setPositiveButton
                }
                if (w * h.toLong() > 16_000_000L) {
                    toast("Tamanho muito grande (máx. ~16 MP)")
                    return@setPositiveButton
                }
                if (resize) {
                    if (art.resizeCanvas(w, h, stretch)) {
                        refreshAll()
                        toast("Papel: ${w}×${h}")
                    } else {
                        toast("Memória insuficiente para esse tamanho")
                    }
                } else {
                    startNewProject(w, h, bgChoice)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startNewProject(w: Int, h: Int, bg: Int) {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        projId = ArtStore.newId()
        createDoc(w, h, bg)
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))
        refreshAll()
        toast("Novo desenho criado")
    }

    private fun importImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val maxDim = maxOf(art.docW, art.docH)
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opt = BitmapFactory.Options()
            opt.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
            if (bmp == null) {
                toast("Não foi possível abrir a imagem")
                return
            }
            val ok = art.addImageLayer(bmp, "Imagem")
            bmp.recycle()
            refreshLayers()
            if (ok) {
                toast("Imagem adicionada. Use Transformar para ajustar.")
            } else {
                toast("Máximo de " + ArtCanvas.MAX_LAYERS + " camadas")
            }
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para essa imagem")
        } catch (e: Exception) {
            toast("Não foi possível abrir a imagem")
        }
    }

    private fun shareUri(uri: Uri, mime: String) {
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = mime
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.clipData = ClipData.newRawUri("desenho", uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Compartilhar desenho"))
        } catch (_: Exception) {
            toast("Não foi possível compartilhar")
        }
    }

    private fun exportImage(png: Boolean, share: Boolean) {
        val flat: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        Thread {
            var savedUri: Uri? = null
            try {
                var out = flat
                if (!png) {
                    val bg = Bitmap.createBitmap(flat.width, flat.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(bg)
                    c.drawColor(Color.WHITE)
                    c.drawBitmap(flat, 0f, 0f, null)
                    out = bg
                }
                val ext = if (png) "png" else "jpg"
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "47Art_" + System.currentTimeMillis() + "." + ext)
                values.put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/47 Art")
                values.put(MediaStore.Images.Media.IS_PENDING, 1)
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    val fmt = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    val bmp = out
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(fmt, 95, it) }
                    val v2 = ContentValues()
                    v2.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, v2, null, null)
                    savedUri = uri
                }
                if (out !== flat) out.recycle()
            } catch (_: Exception) { }
            flat.recycle()
            val su = savedUri
            runOnUiThread {
                if (su != null) {
                    Toast.makeText(this, "Salvo em Pictures/47 Art", Toast.LENGTH_LONG).show()
                    if (share) shareUri(su, if (png) "image/png" else "image/jpeg")
                } else {
                    Toast.makeText(this, "Não foi possível salvar", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun exportTimelapse() {
        if (exporting) {
            toast("O timelapse já está sendo gerado")
            return
        }
        val count = timelapse.frameCount()
        if (count < 3) {
            toast("Desenhe um pouco mais para gerar o timelapse")
            return
        }
        val secs = (minOf(count, 150) + 18) / 12 + 1
        AlertDialog.Builder(this)
            .setTitle("Exportar timelapse")
            .setMessage("O vídeo terá cerca de $secs segundos e leva esse mesmo tempo para ser gerado. Continuar?")
            .setPositiveButton("Gerar") { _, _ -> startTimelapseExport() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTimelapseExport() {
        val finalFrame: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        exporting = true
        val cancel = AtomicBoolean(false)
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        val pad = LinearLayout(this)
        pad.setPadding(dp(24), dp(16), dp(24), dp(8))
        pad.addView(pb, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Gerando timelapse…")
            .setView(pad)
            .setCancelable(false)
            .setNegativeButton("Cancelar") { _, _ -> cancel.set(true) }
            .create()
        dlg.show()

        val list = timelapse.filesSnapshot()
        val tl = timelapse
        val w = art.docW
        val h = art.docH
        Thread {
            tl.flush()
            val ok = Timelapse.exportVideo(
                this, list, finalFrame, w, h,
                { p -> runOnUiThread { pb.progress = p } },
                { cancel.get() }
            )
            finalFrame.recycle()
            runOnUiThread {
                dlg.dismiss()
                exporting = false
                Toast.makeText(
                    this,
                    if (ok) "Timelapse salvo em Movies/47 Art" else "Timelapse não gerado",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }
}
