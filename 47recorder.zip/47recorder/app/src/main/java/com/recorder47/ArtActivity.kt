package com.recorder47

import android.app.AlertDialog
import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

private const val A_MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val A_WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val A_WHITE = 0xFFFFFFFF.toInt()
private val A_GREY = 0xFFB5B5B5.toInt()

/** 47 Art Mode: estúdio de desenho com camadas, pincéis, simetria, timelapse e salvamento automático. */
class ArtActivity : ComponentActivity() {

    private lateinit var art: ArtCanvas
    private lateinit var toolPanel: LinearLayout
    private lateinit var transformBar: LinearLayout
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var toolBtn: TextView
    private lateinit var colorDot: TextView
    private lateinit var layerBtn: TextView
    private lateinit var symBtn: TextView
    private lateinit var gridBtn: TextView
    private lateinit var timelapse: Timelapse

    private var projId = ""
    private val toolItems = ArrayList<LinearLayout>()
    private var layersDialog: AlertDialog? = null
    private val saveHandler = Handler(Looper.getMainLooper())
    private val autosave = Runnable { saveNow() }
    private var exporting = false

    private val toolIcons = arrayOf(
        "✏️", "🖋️", "🖌️", "💨", "🖍️", "🩹", "🪣", "💧", "📏", "▭", "⬭", "🔄", "✋"
    )
    private val toolNames = arrayOf(
        "Lápis", "Caneta", "Pincel", "Aerógrafo", "Marcador", "Borracha", "Balde",
        "Conta-gotas", "Linha", "Retângulo", "Elipse", "Transformar", "Mão"
    )
    private val symLabels = arrayOf("off", "↔", "↕", "✛")

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (toolPanel.visibility == View.VISIBLE) {
                toolPanel.visibility = View.GONE
            } else if (art.transforming) {
                art.cancelTransform()
            } else {
                finishSaving()
            }
        }
    }

    // ------------------------------------------------------------ helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun roundBtn(symbol: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = symbol
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.setTextColor(A_WHITE)
        t.background = oval(0xAA000000.toInt())
        t.setOnClickListener { onClick() }
        return t
    }

    private fun cell(icon: String, caption: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = icon + "\n" + caption
        t.gravity = Gravity.CENTER
        t.textSize = 11f
        t.setTextColor(0xFFDDDDDD.toInt())
        t.setOnClickListener { onClick() }
        return t
    }

    // ------------------------------------------------------------- ciclo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF121212.toInt()
        onBackPressedDispatcher.addCallback(this, backCb)

        art = ArtCanvas(this)
        art.padTop = dp(64).toFloat()
        art.padBottom = dp(200).toFloat()
        art.stabilizer = 2
        art.color = 0xFF000000.toInt()

        val pid = intent.getStringExtra("pid")
        var loaded = false
        if (pid != null) {
            projId = pid
            loaded = loadProject()
        }
        if (!loaded) {
            if (projId.isEmpty()) projId = ArtStore.newId()
            createDoc(1080, 1350, Color.WHITE)
        }
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF1B1B1B.toInt())
        root.addView(art, FrameLayout.LayoutParams(A_MATCH, A_MATCH))
        root.addView(buildTop(), FrameLayout.LayoutParams(A_MATCH, A_WRAP, Gravity.TOP))

        transformBar = buildTransformBar()
        val tbp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        tbp.topMargin = dp(70)
        root.addView(transformBar, tbp)

        root.addView(buildBottom(), FrameLayout.LayoutParams(A_MATCH, A_WRAP, Gravity.BOTTOM))

        toolPanel = buildToolPanel()
        val tpp = FrameLayout.LayoutParams(A_WRAP, A_WRAP, Gravity.BOTTOM or Gravity.START)
        tpp.leftMargin = dp(10)
        tpp.bottomMargin = dp(192)
        root.addView(toolPanel, tpp)
        setContentView(root)

        art.onPick = { c ->
            art.color = c
            refreshColor()
        }
        art.onHistoryChanged = { refreshHistory() }
        art.onTransformChanged = {
            transformBar.visibility = if (art.transforming) View.VISIBLE else View.GONE
        }
        art.onCommit = { onCommitted() }

        refreshAll()
    }

    override fun onPause() {
        super.onPause()
        saveHandler.removeCallbacks(autosave)
        saveNow()
    }

    override fun onDestroy() {
        saveHandler.removeCallbacks(autosave)
        super.onDestroy()
    }

    private fun createDoc(w: Int, h: Int, bg: Int) {
        try {
            art.newDoc(w, h, bg)
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente. Usando uma tela menor.")
            art.newDoc(720, 900, bg)
        }
    }

    private fun loadProject(): Boolean {
        return try {
            val d = ArtStore.load(this, projId) ?: return false
            art.setDoc(d.w, d.h, d.bg, d.layers, d.cur)
            true
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    private fun onCommitted() {
        timelapse.capture(art)
        saveHandler.removeCallbacks(autosave)
        saveHandler.postDelayed(autosave, 4000)
        refreshLayers()
    }

    private fun saveNow() {
        if (!::art.isInitialized) return
        try {
            val snap = art.snapshot()
            val th = maxOf(1, (256f * art.docH / art.docW).toInt())
            val thumb = art.renderSmall(256, th)
            ArtStore.save(this, projId, art.docW, art.docH, art.bgColor, art.current, snap, thumb)
        } catch (e: OutOfMemoryError) {
            // sem memória para a cópia: tenta de novo na próxima alteração
        }
    }

    private fun finishSaving() {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        finish()
    }

    // ------------------------------------------------------------ interface
    private fun buildTop(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(10), dp(10), dp(10), 0)

        val back = roundBtn("←") { finishSaving() }
        undoBtn = roundBtn("↩") { art.undo() }
        redoBtn = roundBtn("↪") { art.redo() }
        row.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val lpu = LinearLayout.LayoutParams(dp(44), dp(44))
        lpu.leftMargin = dp(8)
        row.addView(undoBtn, lpu)
        val lpr = LinearLayout.LayoutParams(dp(44), dp(44))
        lpr.leftMargin = dp(8)
        row.addView(redoBtn, lpr)
        row.addView(View(this), LinearLayout.LayoutParams(0, dp(44), 1f))

        val fit = roundBtn("⤢") { art.resetView() }
        gridBtn = roundBtn("▦") {
            art.showGrid = !art.showGrid
            gridBtn.alpha = if (art.showGrid) 1f else 0.6f
        }
        gridBtn.alpha = 0.6f
        val more = roundBtn("⋮") { showMore() }
        row.addView(fit, LinearLayout.LayoutParams(dp(44), dp(44)))
        val lpg = LinearLayout.LayoutParams(dp(44), dp(44))
        lpg.leftMargin = dp(8)
        row.addView(gridBtn, lpg)
        val lpm = LinearLayout.LayoutParams(dp(44), dp(44))
        lpm.leftMargin = dp(8)
        row.addView(more, lpm)
        return row
    }

    private fun buildTransformBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.visibility = View.GONE
        val cancel = label("✕ Cancelar", 14f, A_WHITE, true)
        cancel.setPadding(dp(18), dp(10), dp(18), dp(10))
        cancel.background = round(0xDD333333.toInt(), 22)
        cancel.setOnClickListener { art.cancelTransform() }
        val ok = label("✓ Aplicar", 14f, A_WHITE, true)
        ok.setPadding(dp(18), dp(10), dp(18), dp(10))
        ok.background = round(Ui.accent, 22)
        ok.setOnClickListener { art.applyTransform() }
        bar.addView(cancel)
        val lp = LinearLayout.LayoutParams(A_WRAP, A_WRAP)
        lp.leftMargin = dp(10)
        bar.addView(ok, lp)
        return bar
    }

    private fun sliderRow(
        title: String, max: Int, initial: Int, fmt: (Int) -> String,
        onChange: (Int) -> Unit, onDone: (() -> Unit)? = null
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), 0, dp(12), 0)
        val lbl = label(title, 12f, A_WHITE)
        val value = label(fmt(initial), 12f, A_WHITE)
        value.gravity = Gravity.END
        val seek = SeekBar(this)
        seek.max = max
        seek.progress = initial
        seek.progressTintList = ColorStateList.valueOf(Ui.accent)
        seek.thumbTintList = ColorStateList.valueOf(Ui.accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = fmt(p)
                onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (onDone != null) onDone()
            }
        })
        row.addView(lbl, LinearLayout.LayoutParams(dp(92), A_WRAP))
        row.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(44), A_WRAP))
        return row
    }

    private fun buildBottom(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0xEE121212.toInt())
        box.isClickable = true

        box.addView(
            sliderRow("Tamanho", 199, 11, { p -> "${p + 1}" }, { p ->
                art.brushSize = (p + 1).toFloat()
                refreshColor()
            })
        )
        box.addView(
            sliderRow("Opacidade", 99, 99, { p -> "${p + 1}%" }, { p ->
                art.opacity = (p + 1) * 255 / 100
            })
        )
        box.addView(
            sliderRow("Estabilizador", 10, 2, { p -> "$p" }, { p ->
                art.stabilizer = p
            })
        )

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xFF1A1A1A.toInt())

        toolBtn = cell("✏️", "Lápis") {
            toolPanel.visibility = if (toolPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        bar.addView(toolBtn, LinearLayout.LayoutParams(0, dp(60), 1f))

        val colorCell = LinearLayout(this)
        colorCell.orientation = LinearLayout.VERTICAL
        colorCell.gravity = Gravity.CENTER
        colorDot = TextView(this)
        colorDot.gravity = Gravity.CENTER
        colorDot.textSize = 11f
        colorDot.typeface = Typeface.DEFAULT_BOLD
        colorCell.addView(colorDot, LinearLayout.LayoutParams(dp(34), dp(34)))
        colorCell.addView(label("Cor", 11f, 0xFFDDDDDD.toInt()))
        colorCell.setOnClickListener { showColorPicker() }
        bar.addView(colorCell, LinearLayout.LayoutParams(0, dp(60), 1f))

        layerBtn = cell("🗂", "Camadas") { showLayers() }
        bar.addView(layerBtn, LinearLayout.LayoutParams(0, dp(60), 1f))

        symBtn = cell("🪞", "Simetria") {
            art.symmetry = (art.symmetry + 1) % 4
            refreshSym()
        }
        bar.addView(symBtn, LinearLayout.LayoutParams(0, dp(60), 1f))

        val eraser = cell("🩹", "Borracha") {
            setTool(if (art.tool == ArtCanvas.T_ERASER) ArtCanvas.T_PENCIL else ArtCanvas.T_ERASER)
        }
        bar.addView(eraser, LinearLayout.LayoutParams(0, dp(60), 1f))

        box.addView(bar)
        return box
    }

    private fun buildToolPanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(8), dp(8), dp(8), dp(8))
        panel.background = round(0xF2262626.toInt(), 18)
        panel.visibility = View.GONE
        var i = 0
        while (i < toolNames.size) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val idx = i + k
                if (idx < toolNames.size) {
                    val item = LinearLayout(this)
                    item.orientation = LinearLayout.VERTICAL
                    item.gravity = Gravity.CENTER
                    item.setPadding(dp(10), dp(8), dp(10), dp(8))
                    val ic = label(toolIcons[idx], 24f, A_WHITE)
                    ic.gravity = Gravity.CENTER
                    val nm = label(toolNames[idx], 11f, 0xFFDDDDDD.toInt())
                    nm.gravity = Gravity.CENTER
                    item.addView(ic, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
                    item.addView(nm, LinearLayout.LayoutParams(A_WRAP, A_WRAP))
                    item.setOnClickListener { setTool(idx) }
                    toolItems.add(item)
                    line.addView(item, LinearLayout.LayoutParams(dp(104), A_WRAP))
                }
            }
            panel.addView(line)
            i += 2
        }
        return panel
    }

    // ------------------------------------------------------------ atualizações
    private fun setTool(idx: Int) {
        art.tool = idx
        toolPanel.visibility = View.GONE
        refreshTool()
    }

    private fun refreshAll() {
        refreshTool()
        refreshColor()
        refreshHistory()
        refreshLayers()
        refreshSym()
    }

    private fun refreshTool() {
        val t = art.tool.coerceIn(0, toolNames.size - 1)
        toolBtn.text = toolIcons[t] + "\n" + toolNames[t]
        for (i in toolItems.indices) {
            if (i == t) {
                toolItems[i].background = round(0x66E53935, 12)
            } else {
                toolItems[i].background = null
            }
        }
    }

    private fun refreshColor() {
        val opaque = art.color or 0xFF000000.toInt()
        colorDot.background = oval(opaque)
        colorDot.text = art.brushSize.toInt().toString()
        colorDot.setTextColor(Prefs.contrast(opaque))
    }

    private fun refreshHistory() {
        undoBtn.alpha = if (art.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (art.canRedo()) 1f else 0.4f
    }

    private fun refreshLayers() {
        layerBtn.text = "🗂\nCamadas " + art.layers.size
    }

    private fun refreshSym() {
        symBtn.text = "🪞\nSimetria " + symLabels[art.symmetry.coerceIn(0, 3)]
        art.invalidate()
    }

    // ---------------------------------------------------------------- cores
    private fun showColorPicker() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))

        val preview = TextView(this)
        preview.gravity = Gravity.CENTER
        preview.textSize = 14f

        fun updatePreview(c: Int) {
            val opaque = c or 0xFF000000.toInt()
            preview.background = round(opaque, 12)
            preview.text = String.format("#%06X", c and 0xFFFFFF)
            preview.setTextColor(Prefs.contrast(opaque))
        }

        val wheel = ColorWheelView(this)
        wheel.setColor(art.color)
        wheel.onColor = { c -> updatePreview(c) }
        box.addView(wheel, LinearLayout.LayoutParams(dp(260), dp(260)))
        val pl = LinearLayout.LayoutParams(A_MATCH, dp(44))
        pl.topMargin = dp(8)
        box.addView(preview, pl)
        updatePreview(art.color)

        val cap = label("Minhas cores", 12f, A_GREY)
        cap.setPadding(0, dp(12), 0, dp(6))
        box.addView(cap)
        val prow = LinearLayout(this)
        prow.orientation = LinearLayout.HORIZONTAL
        for (pc in ArtStore.palette(this)) {
            val d = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(pc)
            g.setStroke(dp(2), 0xFF666666.toInt())
            d.background = g
            d.setOnClickListener {
                wheel.setColor(pc)
                updatePreview(pc)
            }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.rightMargin = dp(8)
            prow.addView(d, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.addView(prow)
        box.addView(hs, LinearLayout.LayoutParams(A_MATCH, A_WRAP))

        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Cor")
            .setView(sv)
            .setPositiveButton("OK") { _, _ ->
                val c = wheel.getColor()
                art.color = c
                ArtStore.addPalette(this, c)
                refreshColor()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // -------------------------------------------------------------- camadas
    private fun pillBtn(text: String, onClick: () -> Unit): TextView {
        val t = label(text, 13f, A_WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(10), dp(10), dp(10))
        t.background = round(0x33FFFFFF, 12)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun blendChips(cur: ArtCanvas.Layer, from: Int, to: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in from until to) {
            val sel = cur.blend == i
            val t = label(ArtCanvas.BLEND_NAMES[i], 12f, A_WHITE, sel)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(10), dp(4), dp(10))
            t.background = round(if (sel) Ui.accent else 0x33FFFFFF, 12)
            t.setOnClickListener {
                cur.blend = i
                art.layerChanged()
                showLayers()
            }
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            row.addView(t, lp)
        }
        return row
    }

    private fun showLayers() {
        layersDialog?.dismiss()
        if (art.layers.isEmpty()) return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(8), dp(12), dp(4))

        for (idx in art.layers.indices.reversed()) {
            val l = art.layers[idx]
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(8), dp(6), dp(8), dp(6))
            line.background = round(if (idx == art.current) 0x55E53935 else 0x22FFFFFF, 12)

            val eye = label(if (l.visible) "👁" else "🚫", 18f, A_WHITE)
            eye.gravity = Gravity.CENTER
            eye.setOnClickListener {
                l.visible = !l.visible
                art.layerChanged()
                showLayers()
            }
            line.addView(eye, LinearLayout.LayoutParams(dp(40), dp(40)))

            val thumb = ImageView(this)
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.setBackgroundColor(0xFFCCCCCC.toInt())
            try {
                thumb.setImageBitmap(
                    Bitmap.createScaledBitmap(l.bmp, 64, maxOf(1, 64 * art.docH / art.docW), true)
                )
            } catch (_: Exception) { }
            val tlp = LinearLayout.LayoutParams(dp(44), dp(maxOf(20, 44 * art.docH / art.docW)))
            tlp.leftMargin = dp(6)
            line.addView(thumb, tlp)

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            info.addView(label(l.name, 14f, A_WHITE, true))
            info.addView(
                label(
                    ArtCanvas.BLEND_NAMES[l.blend.coerceIn(0, 6)] + " • " + (l.opacity * 100 / 255) + "%",
                    11f, A_GREY
                )
            )
            val ilp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            ilp.leftMargin = dp(10)
            line.addView(info, ilp)

            line.setOnClickListener {
                art.selectLayer(idx)
                refreshLayers()
                showLayers()
            }
            val llp = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
            llp.bottomMargin = dp(6)
            box.addView(line, llp)
        }

        val cur = art.layers[art.current.coerceIn(0, art.layers.size - 1)]
        val sel = label("Camada selecionada: " + cur.name, 13f, 0xFFDDDDDD.toInt(), true)
        sel.setPadding(0, dp(10), 0, dp(4))
        box.addView(sel)
        box.addView(
            sliderRow("Opacidade", 100, cur.opacity * 100 / 255, { p -> "$p%" }, { p ->
                cur.opacity = p * 255 / 100
                art.invalidate()
            }, { art.layerChanged() })
        )
        val bl = label("Modo de mistura", 12f, A_GREY)
        bl.setPadding(0, dp(6), 0, dp(4))
        box.addView(bl)
        box.addView(blendChips(cur, 0, 4))
        val gap = View(this)
        box.addView(gap, LinearLayout.LayoutParams(A_MATCH, dp(6)))
        box.addView(blendChips(cur, 4, 7))

        val acts1 = LinearLayout(this)
        acts1.orientation = LinearLayout.HORIZONTAL
        val acts2 = LinearLayout(this)
        acts2.orientation = LinearLayout.HORIZONTAL

        fun addAct(row: LinearLayout, text: String, onClick: () -> Unit) {
            val lp = LinearLayout.LayoutParams(0, A_WRAP, 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            row.addView(pillBtn(text) {
                onClick()
                refreshLayers()
                showLayers()
            }, lp)
        }

        addAct(acts1, "＋ Nova") {
            if (!art.addLayer()) toast("Máximo de " + ArtCanvas.MAX_LAYERS + " camadas")
        }
        addAct(acts1, "⧉ Duplicar") {
            if (!art.duplicateCurrent()) toast("Não foi possível duplicar")
        }
        addAct(acts1, "⬇ Mesclar") {
            if (!art.mergeDown()) toast("Não há camada abaixo")
        }
        addAct(acts2, "🧹 Limpar") { art.clearCurrent() }
        addAct(acts2, "🗑 Excluir") {
            if (!art.removeCurrent()) toast("Mantenha ao menos uma camada")
        }
        addAct(acts2, "▲ Subir") { art.moveCurrent(true) }
        addAct(acts2, "▼ Descer") { art.moveCurrent(false) }

        val a1 = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        a1.topMargin = dp(12)
        box.addView(acts1, a1)
        val a2 = LinearLayout.LayoutParams(A_MATCH, A_WRAP)
        a2.topMargin = dp(6)
        box.addView(acts2, a2)

        val sv = ScrollView(this)
        sv.addView(box)
        val d = AlertDialog.Builder(this)
            .setTitle("Camadas")
            .setView(sv)
            .setPositiveButton("Fechar", null)
            .create()
        layersDialog = d
        d.show()
    }

    // ----------------------------------------------------------- mais opções
    private fun showMore() {
        val items = arrayOf(
            "Novo desenho…",
            "Salvar na galeria (PNG)",
            "Salvar na galeria (JPG)",
            "Exportar timelapse (vídeo)",
            "Sair e salvar"
        )
        AlertDialog.Builder(this)
            .setTitle("47 Art Mode")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askNewDoc()
                    1 -> exportImage(true)
                    2 -> exportImage(false)
                    3 -> exportTimelapse()
                    else -> finishSaving()
                }
            }
            .show()
    }

    private fun askNewDoc() {
        val sizes = arrayOf("Quadrado 1080×1080", "Retrato 1080×1350", "Paisagem 1350×1080", "Tela 1080×1920")
        val dims = arrayOf(intArrayOf(1080, 1080), intArrayOf(1080, 1350), intArrayOf(1350, 1080), intArrayOf(1080, 1920))
        AlertDialog.Builder(this)
            .setTitle("Tamanho da tela")
            .setItems(sizes) { _, w1 ->
                val bgs = arrayOf("Fundo branco", "Fundo preto", "Fundo transparente")
                val colors = intArrayOf(Color.WHITE, Color.BLACK, Color.TRANSPARENT)
                AlertDialog.Builder(this)
                    .setTitle("Fundo")
                    .setItems(bgs) { _, w2 ->
                        startNewProject(dims[w1][0], dims[w1][1], colors[w2])
                    }
                    .show()
            }
            .show()
    }

    private fun startNewProject(w: Int, h: Int, bg: Int) {
        saveHandler.removeCallbacks(autosave)
        saveNow()
        projId = ArtStore.newId()
        createDoc(w, h, bg)
        timelapse = Timelapse(File(ArtStore.projDir(this, projId), "frames"))
        refreshAll()
        toast("Novo desenho criado")
    }

    private fun exportImage(png: Boolean) {
        val flat: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        Thread {
            var ok = false
            try {
                var out = flat
                if (!png) {
                    val bg = Bitmap.createBitmap(flat.width, flat.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(bg)
                    c.drawColor(Color.WHITE)
                    c.drawBitmap(flat, 0f, 0f, null)
                    out = bg
                }
                val ext = if (png) "png" else "jpg"
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "47Art_" + System.currentTimeMillis() + "." + ext)
                values.put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/47 Art")
                values.put(MediaStore.Images.Media.IS_PENDING, 1)
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    val fmt = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    val bmp = out
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(fmt, 95, it) }
                    val v2 = ContentValues()
                    v2.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, v2, null, null)
                    ok = true
                }
                if (out !== flat) out.recycle()
            } catch (_: Exception) { }
            flat.recycle()
            runOnUiThread {
                Toast.makeText(
                    this, if (ok) "Salvo em Pictures/47 Art" else "Não foi possível salvar", Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun exportTimelapse() {
        if (exporting) {
            toast("O timelapse já está sendo gerado")
            return
        }
        val count = timelapse.frameCount()
        if (count < 3) {
            toast("Desenhe um pouco mais para gerar o timelapse")
            return
        }
        val secs = (minOf(count, 150) + 18) / 12 + 1
        AlertDialog.Builder(this)
            .setTitle("Exportar timelapse")
            .setMessage("O vídeo terá cerca de $secs segundos e leva esse mesmo tempo para ser gerado. Continuar?")
            .setPositiveButton("Gerar") { _, _ -> startTimelapseExport() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startTimelapseExport() {
        val finalFrame: Bitmap = try {
            art.flatten()
        } catch (e: OutOfMemoryError) {
            toast("Memória insuficiente para exportar")
            return
        }
        exporting = true
        val cancel = AtomicBoolean(false)
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        val pad = LinearLayout(this)
        pad.setPadding(dp(24), dp(16), dp(24), dp(8))
        pad.addView(pb, LinearLayout.LayoutParams(A_MATCH, A_WRAP))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Gerando timelapse…")
            .setView(pad)
            .setCancelable(false)
            .setNegativeButton("Cancelar") { _, _ -> cancel.set(true) }
            .create()
        dlg.show()

        val list = timelapse.filesSnapshot()
        val tl = timelapse
        val w = art.docW
        val h = art.docH
        Thread {
            tl.flush()
            val ok = Timelapse.exportVideo(
                this, list, finalFrame, w, h,
                { p -> runOnUiThread { pb.progress = p } },
                { cancel.get() }
            )
            finalFrame.recycle()
            runOnUiThread {
                dlg.dismiss()
                exporting = false
                Toast.makeText(
                    this,
                    if (ok) "Timelapse salvo em Movies/47 Art" else "Timelapse não gerado",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }
}
