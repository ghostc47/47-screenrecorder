package com.recorder47

import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Editor de vídeo: cortar (início/fim), juntar vários vídeos e mudar a velocidade.
 * Exporta com recodificação (precisão de quadro) usando o Media3 Transformer.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class EditorActivity : ComponentActivity() {

    companion object {
        fun open(ctx: Context, uris: List<Uri>, names: List<String>) {
            val i = android.content.Intent(ctx, EditorActivity::class.java)
            i.putStringArrayListExtra("uris", ArrayList(uris.map { it.toString() }))
            i.putStringArrayListExtra("names", ArrayList(names))
            if (ctx !is android.app.Activity) i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private class Clip(val uri: Uri, val name: String, val durMs: Long, val w: Int, val h: Int) {
        var start = 0L
        var end = durMs
    }

    private val main = Handler(Looper.getMainLooper())
    private val white = 0xFFFFFFFF.toInt()
    private val clips = mutableListOf<Clip>()
    private var sel = 0
    private var speed = 1f
    private var mute = false

    private lateinit var preview: VideoView
    private lateinit var playBtn: TextView
    private lateinit var panel: LinearLayout
    private var tvStart: TextView? = null
    private var tvEnd: TextView? = null
    private var tvInfo: TextView? = null

    private var transformer: Transformer? = null
    private var progressDialog: AlertDialog? = null
    private val holder = ProgressHolder()
    private var outFile: File? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- ciclo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Ui.barDark
        window.navigationBarColor = Ui.bg

        val uris = (intent.getStringArrayListExtra("uris") ?: arrayListOf()).map { Uri.parse(it) }
        val names = intent.getStringArrayListExtra("names") ?: arrayListOf()
        uris.forEachIndexed { i, u -> probe(u, names.getOrNull(i) ?: "Vídeo")?.let { clips.add(it) } }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg)
        }
        // topo
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.accent)
            setPadding(dp(6), dp(30), dp(14), dp(10))
        }
        top.addView(tv("←", 24f, white).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { finish() }
        })
        top.addView(tv("✂️ Editor de vídeo", 18f, white, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // pré-visualização
        val box = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = VideoView(this)
        box.addView(preview, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        playBtn = tv("▶", 34f, white).apply {
            gravity = Gravity.CENTER
            background = Ui.pillDrawable(0x88000000.toInt(), dp(32).toFloat())
            setOnClickListener { togglePreview() }
        }
        box.addView(playBtn, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        root.addView(box, LinearLayout.LayoutParams(MATCH, dp(220)))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(panel) }, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // rodapé: exportar
        val exportBtn = tv("Exportar vídeo", 16f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
            background = Ui.gradientButton(Ui.lighten(Ui.accent, 0.1f), Ui.darken(Ui.accent, 0.12f), dp(26).toFloat())
            setOnClickListener { export() }
        }
        root.addView(exportBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(16), dp(8), dp(16), dp(16))
        })
        setContentView(root)

        render()
        if (clips.isEmpty()) addClips() else loadPreview()
    }

    override fun onPause() {
        super.onPause()
        try { preview.pause() } catch (_: Exception) { }
        playBtn.text = "▶"
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { transformer?.cancel() } catch (_: Exception) { }
        try { preview.stopPlayback() } catch (_: Exception) { }
        super.onDestroy()
    }

    // --------------------------------------------------------------- helpers
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val t = (ms % 1000) / 100
        return String.format("%d:%02d.%d", s / 60, s % 60, t)
    }

    private fun probe(uri: Uri, name: String): Clip? = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(this, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) { val x = w; w = h; h = x }
        r.release()
        if (dur > 0) Clip(uri, name, dur, w, h) else null
    } catch (_: Exception) { null }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.cardDrawable(Ui.card, Ui.radius)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    // ------------------------------------------------------------------ UI
    private fun render() {
        panel.removeAllViews()
        tvStart = null; tvEnd = null; tvInfo = null

        // lista de clipes
        val list = card()
        list.addView(tv("Vídeos (${clips.size})", 14f, Ui.txt, true))
        clips.forEachIndexed { i, c ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8))
                background = Ui.cardDrawable(if (i == sel) Ui.accent else Ui.chip, dp(14))
                setOnClickListener { sel = i; render(); loadPreview() }
            }
            row.addView(tv("${i + 1}. ${c.name}\n${fmt(c.end - c.start)} de ${fmt(c.durMs)}", 12f, white),
                LinearLayout.LayoutParams(0, WRAP, 1f))
            if (i > 0) row.addView(small("↑") { swap(i, i - 1) })
            if (i < clips.size - 1) row.addView(small("↓") { swap(i, i + 1) })
            row.addView(small("✕") {
                clips.removeAt(i)
                sel = sel.coerceIn(0, maxOf(0, clips.size - 1))
                render(); loadPreview()
            })
            list.addView(row, lp(6))
        }
        list.addView(tv("+ Adicionar vídeos", 13f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            background = Ui.cardDrawable(Ui.chip, dp(14))
            setOnClickListener { addClips() }
        }, lp(8))
        panel.addView(list, lp(0))

        val c = clips.getOrNull(sel)
        if (c != null) {
            // cortar
            val trim = card()
            trim.addView(tv("✂️ Cortar o vídeo ${sel + 1}", 14f, Ui.txt, true))
            tvStart = tv("Início: ${fmt(c.start)}", 12f, Ui.sub)
            trim.addView(tvStart, lp(8))
            trim.addView(SeekBar(this).apply {
                max = c.durMs.toInt(); progress = c.start.toInt()
                tint(this)
                setOnSeekBarChangeListener(seekListener { p ->
                    val v = minOf(p.toLong(), c.end - 300).coerceAtLeast(0)
                    if (v != p.toLong()) progress = v.toInt()
                    c.start = v
                    tvStart?.text = "Início: ${fmt(v)}"
                    updateInfo(c)
                    preview.seekTo(v.toInt())
                })
            })
            tvEnd = tv("Fim: ${fmt(c.end)}", 12f, Ui.sub)
            trim.addView(tvEnd, lp(8))
            trim.addView(SeekBar(this).apply {
                max = c.durMs.toInt(); progress = c.end.toInt()
                tint(this)
                setOnSeekBarChangeListener(seekListener { p ->
                    val v = maxOf(p.toLong(), c.start + 300).coerceAtMost(c.durMs)
                    if (v != p.toLong()) progress = v.toInt()
                    c.end = v
                    tvEnd?.text = "Fim: ${fmt(v)}"
                    updateInfo(c)
                    preview.seekTo(maxOf(0L, v - 200).toInt())
                })
            })
            panel.addView(trim, lp(10))
        }

        // velocidade
        val sp = card()
        sp.addView(tv("⏩ Velocidade", 14f, Ui.txt, true))
        val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        speeds.forEach { s ->
            val on = s == speed
            chips.addView(tv((if (s == s.toInt().toFloat()) "${s.toInt()}" else "$s") + "x", 13f,
                white, on).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = Ui.cardDrawable(if (on) Ui.accent else Ui.chip, dp(20))
                setOnClickListener { speed = s; render() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        hs.addView(chips)
        sp.addView(hs, lp(8))
        panel.addView(sp, lp(10))

        // áudio
        val au = card()
        au.addView(tv("🔇 Remover áudio: " + if (mute) "Sim" else "Não", 14f, Ui.txt, true).apply {
            setOnClickListener { mute = !mute; render() }
        })
        panel.addView(au, lp(10))

        tvInfo = tv("", 13f, Ui.sub).apply { setPadding(dp(4), dp(10), dp(4), 0) }
        panel.addView(tvInfo)
        updateInfo(c)
    }

    private fun small(t: String, onClick: () -> Unit) = tv(t, 16f, white, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(6), dp(12), dp(6))
        setOnClickListener { onClick() }
    }

    private fun tint(s: SeekBar) {
        s.progressTintList = android.content.res.ColorStateList.valueOf(Ui.accent)
        s.thumbTintList = android.content.res.ColorStateList.valueOf(Ui.accent)
    }

    private fun seekListener(onUser: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onUser(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { render() }
    }

    private fun updateInfo(@Suppress("UNUSED_PARAMETER") c: Clip?) {
        val total = clips.sumOf { it.end - it.start }
        val out = (total / speed).toLong()
        tvInfo?.text = "Duração final: ${fmt(out)}  •  ${clips.size} vídeo(s)  •  ${if (speed == 1f) "velocidade normal" else "${speed}x"}"
    }

    private fun swap(a: Int, b: Int) {
        val t = clips[a]; clips[a] = clips[b]; clips[b] = t
        if (sel == a) sel = b else if (sel == b) sel = a
        render()
    }

    // ------------------------------------------------------------- preview
    private fun loadPreview() {
        val c = clips.getOrNull(sel)
        main.removeCallbacks(previewTick)
        playBtn.text = "▶"
        if (c == null) { try { preview.stopPlayback() } catch (_: Exception) { }; return }
        preview.setOnPreparedListener { preview.seekTo(c.start.toInt()) }
        preview.setOnCompletionListener { playBtn.text = "▶" }
        preview.setVideoURI(c.uri)
    }

    private val previewTick = object : Runnable {
        override fun run() {
            val c = clips.getOrNull(sel) ?: return
            if (preview.isPlaying) {
                if (preview.currentPosition >= c.end) {
                    preview.pause()
                    playBtn.text = "▶"
                    return
                }
                main.postDelayed(this, 80)
            }
        }
    }

    private fun togglePreview() {
        val c = clips.getOrNull(sel) ?: return
        if (preview.isPlaying) {
            preview.pause(); playBtn.text = "▶"
        } else {
            val pos = preview.currentPosition
            if (pos < c.start || pos >= c.end - 100) preview.seekTo(c.start.toInt())
            preview.start()
            playBtn.text = "⏸"
            main.removeCallbacks(previewTick)
            main.post(previewTick)
        }
    }

    // -------------------------------------------------------- escolher vídeos
    private fun addClips() {
        val ids = ArrayList<Long>()
        val labels = ArrayList<String>()
        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DURATION),
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("Movies/47 Recorder%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    ids.add(c.getLong(0))
                    val s = c.getLong(2) / 1000
                    labels.add("${c.getString(1)}  (${s / 60}:${String.format("%02d", s % 60)})")
                }
            }
        } catch (_: Exception) { }
        if (ids.isEmpty()) {
            Toast.makeText(this, "Nenhuma gravação encontrada", Toast.LENGTH_SHORT).show()
            return
        }
        val checked = BooleanArray(ids.size)
        AlertDialog.Builder(this)
            .setTitle("Escolha os vídeos (na ordem)")
            .setMultiChoiceItems(labels.toTypedArray(), checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("Adicionar") { _, _ ->
                var added = 0
                ids.forEachIndexed { i, id ->
                    if (checked[i]) {
                        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                        val name = labels[i].substringBefore("  (")
                        probe(uri, name)?.let { clips.add(it); added++ }
                    }
                }
                if (added > 0) {
                    sel = clips.size - added
                    render(); loadPreview()
                }
            }
            .setNegativeButton("Cancelar") { _, _ -> if (clips.isEmpty()) finish() }
            .setOnCancelListener { if (clips.isEmpty()) finish() }
            .show()
    }

    // --------------------------------------------------------------- exportar
    private fun export() {
        if (clips.isEmpty()) {
            Toast.makeText(this, "Adicione um vídeo", Toast.LENGTH_SHORT).show()
            return
        }
        try { preview.pause() } catch (_: Exception) { }
        playBtn.text = "▶"

        val outW = clips[0].w
        val outH = clips[0].h
        val items = clips.map { c ->
            val clip = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(c.start)
                .setEndPositionMs(c.end)
                .build()
            val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(clip).build()
            val vEffects = ArrayList<Effect>()
            val aProcs = ArrayList<AudioProcessor>()
            if (clips.size > 1 && outW > 0 && outH > 0) {
                vEffects.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT))
            }
            if (speed != 1f) {
                vEffects.add(SpeedChangeEffect(speed))
                aProcs.add(SonicAudioProcessor().apply { setSpeed(speed) })
            }
            EditedMediaItem.Builder(mi)
                .setRemoveAudio(mute)
                .setEffects(Effects(aProcs, vEffects))
                .build()
        }

        val f = File(cacheDir, "edit_${System.currentTimeMillis()}.mp4")
        outFile = f
        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    main.removeCallbacks(poll)
                    saveResult(f)
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    main.removeCallbacks(poll)
                    progressDialog?.dismiss()
                    try { f.delete() } catch (_: Exception) { }
                    AlertDialog.Builder(this@EditorActivity)
                        .setTitle("Falha ao exportar")
                        .setMessage(exportException.message ?: "Erro desconhecido")
                        .setPositiveButton("OK", null)
                        .show()
                }
            })
            .build()
        transformer = t

        progressDialog = AlertDialog.Builder(this)
            .setTitle("Exportando…")
            .setMessage("0%")
            .setCancelable(false)
            .setNegativeButton("Cancelar") { _, _ ->
                main.removeCallbacks(poll)
                try { t.cancel() } catch (_: Exception) { }
                try { f.delete() } catch (_: Exception) { }
            }
            .show()

        try {
            if (items.size == 1) {
                t.start(items[0], f.absolutePath)
            } else {
                val comp = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
                t.start(comp, f.absolutePath)
            }
            main.post(poll)
        } catch (e: Exception) {
            progressDialog?.dismiss()
            Toast.makeText(this, "Não foi possível iniciar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val st = t.getProgress(holder)
            if (st == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressDialog?.setMessage("${holder.progress}%")
            }
            main.postDelayed(this, 400)
        }
    }

    private fun saveResult(f: File) {
        progressDialog?.setMessage("Salvando…")
        Thread {
            var saved: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "47Edit_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        f.inputStream().use { it.copyTo(out) }
                    }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    saved = uri
                }
            } catch (_: Exception) { }
            try { f.delete() } catch (_: Exception) { }
            runOnUiThread {
                progressDialog?.dismiss()
                val uri = saved
                if (uri == null) {
                    Toast.makeText(this, "Não foi possível salvar o vídeo", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Vídeo salvo")
                        .setMessage("Salvo em Movies/47 Recorder")
                        .setPositiveButton("Abrir") { _, _ ->
                            PlayerActivity.open(this, listOf(uri), listOf("Vídeo editado"), 0, 0)
                            finish()
                        }
                        .setNegativeButton("Fechar") { _, _ -> finish() }
                        .show()
                }
            }
        }.start()
    }
}
