package com.recorder47

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.recorder47.START"
        const val ACTION_STOP = "com.recorder47.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_MIC = "mic"
        private const val CHANNEL_ID = "rec47"
        private const val NOTIF_ID = 47
        private const val SAMPLE_RATE = 44_100
    }

    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var inputSurface: Surface? = null
    private var pfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null
    private var overlay: View? = null

    @Volatile private var recording = false
    @Volatile private var finishing = false

    // Codecs / captura de áudio / muxer
    private var muxer: MediaMuxer? = null
    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var internalRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val muxLock = Any()
    private val muxReady = CountDownLatch(1)
    private var videoTrack = -1
    private var audioTrack = -1
    private var hasAudio = false
    @Volatile private var muxStarted = false
    private var baseUs = -1L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startAsForeground()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val mic = intent.getBooleanExtra(EXTRA_MIC, false)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    startRecording(code, data, mic)
                } catch (e: Exception) {
                    Toast.makeText(this, "Falha ao iniciar: ${e.message}", Toast.LENGTH_LONG).show()
                    recording = false
                    cleanupAfterFailure()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_STOP -> if (recording) stopRecording() else if (!finishing) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("47 Recorder")
            .setContentText("Gravando a tela…")
            .setOngoing(true)
            .addAction(0, "Parar", stopIntent)
            .build()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notif,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ---------------------------------------------------------------- início
    private fun startRecording(code: Int, data: Intent, useMic: Boolean) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        // Obrigatório no Android 14+ antes de criar o VirtualDisplay
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { if (recording) stopRecording() }
        }, main)

        // Resolução: limita a menor lateral a 1080 e usa múltiplos de 16
        val metrics = resources.displayMetrics
        val scale = minOf(1f, 1080f / minOf(metrics.widthPixels, metrics.heightPixels))
        val w = ((metrics.widthPixels * scale) / 16).toInt() * 16
        val h = ((metrics.heightPixels * scale) / 16).toInt() * 16

        // Arquivo de saída na galeria
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "47Recorder_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        videoUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        pfd = contentResolver.openFileDescriptor(videoUri!!, "w")
        muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // Encoder de vídeo (entrada por Surface)
        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000)
        }
        val venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = venc.createInputSurface()
        venc.start()
        videoEnc = venc

        // Áudio interno (+ microfone opcional)
        hasAudio = setupAudio(proj, useMic)
        if (!hasAudio) {
            Toast.makeText(this, "Áudio indisponível. Gravando só vídeo.", Toast.LENGTH_LONG).show()
        }

        display = proj.createVirtualDisplay(
            "47Recorder", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null
        )

        recording = true
        videoThread = Thread({ videoLoop() }, "47-video").also { it.start() }
        if (hasAudio) {
            audioThread = Thread({ audioLoop() }, "47-audio").also { it.start() }
        }
        showOverlay()
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio(proj: MediaProjection, useMic: Boolean): Boolean {
        return try {
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val minStereo = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(maxOf(minStereo, 16_384) * 2)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }
            internalRec = rec

            if (useMic) {
                val minMono = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val m = AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minMono, 8_192) * 2
                )
                if (m.state == AudioRecord.STATE_INITIALIZED) micRec = m else m.release()
            }

            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
            audioEnc = aenc
            true
        } catch (e: Exception) {
            internalRec?.release(); internalRec = null
            micRec?.release(); micRec = null
            audioEnc?.release(); audioEnc = null
            false
        }
    }

    // ------------------------------------------------------------ threads
    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(true, enc.outputFormat)
                    i >= 0 -> {
                        val ob = enc.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            if (!muxStarted && !muxReady.await(3, TimeUnit.SECONDS)) forceStart()
                            writeSample(true, ob, info)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun audioLoop() {
        val enc = audioEnc ?: return
        val rec = internalRec ?: return
        val mic = micRec
        val buf = ShortArray(2048)          // 1024 frames estéreo
        val micBuf = ShortArray(1024)
        val info = MediaCodec.BufferInfo()
        var frames = 0L
        var startUs = -1L
        try {
            rec.startRecording()
            mic?.startRecording()
            while (recording) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                if (startUs < 0) startUs = System.nanoTime() / 1000
                if (mic != null) {
                    val want = n / 2
                    var got = 0
                    while (got < want && recording) {
                        val r = mic.read(micBuf, got, want - got)
                        if (r <= 0) break
                        got += r
                    }
                    for (k in 0 until want) {
                        val m = if (k < got) micBuf[k].toInt() else 0
                        buf[2 * k] = (buf[2 * k] + m).coerceIn(-32768, 32767).toShort()
                        buf[2 * k + 1] = (buf[2 * k + 1] + m).coerceIn(-32768, 32767).toShort()
                    }
                }
                val pts = startUs + frames * 1_000_000L / SAMPLE_RATE
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buf, 0, n)
                    enc.queueInputBuffer(idx, 0, n * 2, pts, 0)
                }
                frames += n / 2
                drainAudio(enc, info, false)
            }
            try { rec.stop() } catch (_: Exception) { }
            try { mic?.stop() } catch (_: Exception) { }

            // Fim de stream
            val pts = (if (startUs < 0) System.nanoTime() / 1000 else startUs) +
                frames * 1_000_000L / SAMPLE_RATE
            var tries = 0
            while (tries++ < 20) {
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
            }
            drainAudio(enc, info, true)
        } catch (_: Exception) { }
    }

    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, untilEos: Boolean) {
        var idleRounds = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(info, if (untilEos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(false, enc.outputFormat)
                i >= 0 -> {
                    val ob = enc.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0) writeSample(false, ob, info)
                    enc.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!untilEos || ++idleRounds > 100) return
                }
            }
        }
    }

    // -------------------------------------------------------------- muxer
    private fun onFormat(video: Boolean, f: MediaFormat) {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (video) videoTrack = m.addTrack(f) else audioTrack = m.addTrack(f)
            if (!muxStarted && videoTrack >= 0 && (!hasAudio || audioTrack >= 0)) {
                m.start(); muxStarted = true; muxReady.countDown()
            }
        }
    }

    /** Áudio não chegou a tempo: começa só com vídeo. */
    private fun forceStart() {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (!muxStarted && videoTrack >= 0) {
                hasAudio = false
                m.start(); muxStarted = true; muxReady.countDown()
            }
        }
    }

    private fun writeSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(muxLock) {
            if (!muxStarted) return
            if (baseUs < 0) baseUs = info.presentationTimeUs
            info.presentationTimeUs = maxOf(0L, info.presentationTimeUs - baseUs)
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            val track = if (video) videoTrack else audioTrack
            if (track < 0) return
            try { muxer?.writeSampleData(track, buf, info) } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------ overlay
    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }

        val btn = TextView(this).apply {
            text = "■ 47"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCCD32F2F.toInt())
            setPadding(36, 28, 36, 28)
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    wm.updateViewLayout(btn, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) stopRecording()
            }
            true
        }
        overlay = btn
        wm.addView(btn, params)
    }

    private fun removeOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) { }
        }
        overlay = null
    }

    // --------------------------------------------------------------- parar
    private fun stopRecording() {
        if (!recording) return
        recording = false
        finishing = true
        removeOverlay()
        Thread({ finalizeRecording() }, "47-finalize").start()
    }

    private fun finalizeRecording() {
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { videoEnc?.signalEndOfInputStream() } catch (_: Exception) { }
        try { videoThread?.join(5000) } catch (_: Exception) { }
        try { audioThread?.join(5000) } catch (_: Exception) { }

        try { videoEnc?.stop() } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.stop() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { inputSurface?.release() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        videoEnc = null; audioEnc = null; inputSurface = null
        internalRec = null; micRec = null

        synchronized(muxLock) {
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            muxer = null
        }
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        try { pfd?.close() } catch (_: Exception) { }
        pfd = null

        videoUri?.let {
            val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(it, v, null, null)
        }

        main.post {
            Toast.makeText(this, "Vídeo salvo em Movies/47 Recorder", Toast.LENGTH_LONG).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cleanupAfterFailure() {
        removeOverlay()
        try { display?.release() } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        try { muxer?.release() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        try { pfd?.close() } catch (_: Exception) { }
        videoUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) { } }
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        super.onDestroy()
    }
}
