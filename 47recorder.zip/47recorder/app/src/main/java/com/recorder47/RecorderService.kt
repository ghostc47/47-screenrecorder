package com.recorder47

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.Image
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.media.MediaCodecList
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import android.widget.RemoteViews
import androidx.core.app.ServiceCompat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.recorder47.START"
        const val ACTION_STOP = "com.recorder47.STOP"
        const val ACTION_PAUSE = "com.recorder47.PAUSE"
        const val ACTION_REC = "com.recorder47.REC"
        const val ACTION_SHOT = "com.recorder47.SHOT"
        const val ACTION_SAVE_REPLAY = "com.recorder47.SAVE_REPLAY"
        const val ACTION_CLOSE = "com.recorder47.CLOSE"
        const val ACTION_HIDE_ORB = "com.recorder47.HIDE_ORB"
        const val ACTION_SHOW_ORB = "com.recorder47.SHOW_ORB"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_MIC = "mic"
        const val EXTRA_MODE = "mode"
        const val MODE_RECORD = 0     // abre o círculo e já grava
        const val MODE_REPLAY = 1     // abre o círculo e já grava só na memória
        const val MODE_MENU = 2       // abre só o círculo flutuante
        private const val CHANNEL_ID = "rec47"
        private const val NOTIF_ID = 47
        private const val SAMPLE_RATE = 44_100
        private const val ST_IDLE = 0
        private const val ST_REC = 1
        private const val ST_PAUSED = 2

        /** true enquanto a sessão de captura está aberta (com ou sem círculo) */
        @Volatile var active = false
    }

    private class Sample(val video: Boolean, val data: ByteArray, val ptsUs: Long, val flags: Int)

    private val main = Handler(Looper.getMainLooper())
    private var mode = MODE_MENU
    private var recKind = MODE_RECORD
    @Volatile private var recState = ST_IDLE
    @Volatile private var finishing = false
    @Volatile private var endAfterStop = false
    @Volatile private var shotBusy = false
    @Volatile private var audioRun = false
    @Volatile private var waitKey = false
    @Volatile private var pauseStartUs = 0L
    @Volatile private var pauseOffsetUs = 0L
    @Volatile private var orbHidden = false
    private var useMicFlag = false
    private var counting = false
    private var countdownView: View? = null
    private var orbView: TextView? = null
    private var recStartMs = 0L
    private var pausedTotalMs = 0L
    private var pauseBeganMs = 0L
    private var lastSavedUri: Uri? = null
    private var sensorMgr: SensorManager? = null
    private var lastShake = 0L
    private var shakeCount = 0

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var inputSurface: Surface? = null
    private var reader: ImageReader? = null
    private var pfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null
    private var vw = 0
    private var vh = 0

    // Overlays
    private var menuRoot: View? = null
    private var faceView: View? = null
    private var wmView: View? = null
    private var camDevice: CameraDevice? = null
    private var camSession: CameraCaptureSession? = null
    private var menuRefresh: (() -> Unit)? = null

    // Codecs / captura de áudio / muxer
    private var muxer: MediaMuxer? = null
    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var internalRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val muxLock = Any()
    private var muxReady = CountDownLatch(1)
    private var videoTrack = -1
    private var audioTrack = -1
    private var hasAudio = false
    @Volatile private var muxStarted = false
    private var baseUs = -1L

    // Replay (buffer circular na memória)
    private val ring = ArrayDeque<Sample>()
    private val ringLock = Any()
    @Volatile private var videoFormat: MediaFormat? = null
    @Volatile private var audioFormat: MediaFormat? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                mode = intent.getIntExtra(EXTRA_MODE, MODE_MENU)
                useMicFlag = intent.getBooleanExtra(EXTRA_MIC, false)
                startAsForeground()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (!active) {
                    if (data == null) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        return START_NOT_STICKY
                    }
                    try {
                        startSession(code, data)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Falha ao iniciar: ${e.message}", Toast.LENGTH_LONG).show()
                        cleanupAfterFailure()
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
            ACTION_REC -> if (active) beginRecording(MODE_RECORD)
            ACTION_PAUSE -> if (active) togglePause()
            ACTION_STOP -> if (active) {
                if (recState != ST_IDLE) stopRecording() else endSession()
            }
            ACTION_SHOT -> if (active) takeShot()
            ACTION_SAVE_REPLAY -> if (active) saveReplay()
            ACTION_CLOSE -> if (active) endSession()
            ACTION_HIDE_ORB -> if (active) hideOrb()
            ACTION_SHOW_ORB -> if (active) showOrb()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------ notificação
    private fun buildNotification(): Notification {
        fun act(action: String, rc: Int) = PendingIntent.getService(
            this, rc,
            Intent(this, RecorderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )
        val timeStr = if (recState != ST_IDLE) {
            val s = elapsedRecMs() / 1000
            String.format("%02d:%02d", s / 60, s % 60)
        } else ""
        val text = when {
            recState == ST_REC && recKind == MODE_REPLAY -> "Replay ativo · $timeStr"
            recState == ST_REC -> "Gravando · $timeStr"
            recState == ST_PAUSED -> "Pausado · $timeStr"
            orbHidden -> "Círculo oculto — toque em Mostrar"
            else -> "Círculo flutuante ativo"
        }
        // Botões desenhados como RemoteViews: ficam sempre visíveis na vista
        // recolhida (MediaStyle com ícone 0 deixava as ações invisíveis).
        val buttons: List<Pair<String, PendingIntent>> = when {
            recState == ST_IDLE -> listOf(
                "● Gravar" to act(ACTION_REC, 1),
                "📷 Print" to act(ACTION_SHOT, 2),
                if (orbHidden) "Mostrar" to act(ACTION_SHOW_ORB, 6)
                else "Encerrar" to act(ACTION_CLOSE, 3)
            )
            recKind == MODE_REPLAY -> listOf(
                "💾 Salvar" to act(ACTION_SAVE_REPLAY, 4),
                "⏹ Parar" to act(ACTION_STOP, 0),
                "📷 Print" to act(ACTION_SHOT, 2)
            )
            else -> listOf(
                (if (recState == ST_PAUSED) "▶ Retomar" else "⏸ Pausar") to act(ACTION_PAUSE, 5),
                "⏹ Parar" to act(ACTION_STOP, 0),
                "📷 Print" to act(ACTION_SHOT, 2)
            )
        }
        val ids = intArrayOf(R.id.btn1, R.id.btn2, R.id.btn3)
        val rv = RemoteViews(packageName, R.layout.notif_controls)
        buttons.forEachIndexed { i, (label, pi) ->
            rv.setTextViewText(ids[i], label)
            rv.setOnClickPendingIntent(ids[i], pi)
        }
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("47 Recorder")
            .setContentText(text)
            .setSubText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setShowWhen(false)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(rv)
            .setCustomBigContentView(rv)
        return b.build()
    }

    private fun updateNotification() {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) { }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setShowBadge(false)
                description = "Controles de gravação"
            }
        )
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), currentFgsTypes())
    }

    /** Tipos de FGS atuais (projection + mic/câmera se permitidos). */
    private fun currentFgsTypes(): Int {
        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        if (Prefs.facecam(this) &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        return types
    }

    /** Garante tipo MICROPHONE no FGS antes de abrir o AudioRecord (Android 14+). */
    private fun ensureMicForeground() {
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), currentFgsTypes())
        } catch (_: Exception) { }
    }

    // ----------------------------------------------------------------- sessão
    private fun startSession(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        // Obrigatório no Android 14+ antes de criar o VirtualDisplay
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (active) endSession()
            }
        }, main)

        val metrics = resources.displayMetrics
        val size = computeSize()
        vw = size[0]
        vh = size[1]

        reader = ImageReader.newInstance(vw, vh, PixelFormat.RGBA_8888, 2)
        // um único VirtualDisplay durante toda a sessão; a superfície é trocada conforme o uso
        display = proj.createVirtualDisplay(
            "47Recorder", vw, vh, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null
        )
        active = true
        orbHidden = false
        showMenu()
        if (mode == MODE_RECORD) beginRecording(MODE_RECORD)
        else if (mode == MODE_REPLAY) startRecording(MODE_REPLAY)
        updateNotification()
    }

    private fun endSession() {
        removeCountdown()
        orbHidden = false
        removeOverlays()
        try { stopService(Intent(this, DrawService::class.java)) } catch (_: Exception) { }
        endAfterStop = true
        if (recState != ST_IDLE) {
            stopRecording()
        } else if (!finishing) {
            releaseSession()
        }
    }

    private fun releaseSession() {
        active = false
        removeOverlays()
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        menuRefresh = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanupAfterFailure() {
        active = false
        removeOverlays()
        abortEncoding()
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
    }

    // ------------------------------------------------- tamanho / rotação da tela
    /** Medidas reais da tela na rotação ATUAL (retrato ou paisagem). */
    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        try {
            val dmgr = getSystemService(DISPLAY_SERVICE) as DisplayManager
            val d = dmgr.getDisplay(Display.DEFAULT_DISPLAY)
            if (d != null) {
                d.getRealMetrics(dm)
                if (dm.widthPixels > 0 && dm.heightPixels > 0) return dm
            }
        } catch (_: Exception) { }
        return resources.displayMetrics
    }

    /** Tamanho do vídeo: lado menor = resolução escolhida, em múltiplos de 16. */
    private fun computeSize(): IntArray {
        val dm = realMetrics()
        val fullW = dm.widthPixels / 2 * 2
        val fullH = dm.heightPixels / 2 * 2
        val scale = minOf(1f, Prefs.resolution(this).toFloat() / minOf(fullW, fullH))
        val w = maxOf(16, ((fullW * scale) / 16).toInt() * 16)
        val h = maxOf(16, ((fullH * scale) / 16).toInt() * 16)
        var rw = w
        var rh = h
        // 4K/1440p: se o aparelho não codifica nesse tamanho, reduz até caber
        var guard = 0
        while (pickEncoder(rw, rh) == null && guard++ < 30) {
            rw = maxOf(16, ((rw * 0.9f) / 16).toInt() * 16)
            rh = maxOf(16, ((rh * 0.9f) / 16).toInt() * 16)
        }
        return intArrayOf(rw, rh)
    }

    /** Melhor encoder para o codec escolhido (HEVC com queda para H.264) que aceita o tamanho. */
    private fun pickEncoder(w: Int, h: Int): Pair<String, MediaCodecInfo>? {
        val mimes = if (Prefs.codec(this) == 1)
            listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)
        else listOf(MediaFormat.MIMETYPE_VIDEO_AVC)
        val infos = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }
        } catch (_: Exception) { return null }
        for (mime in mimes) {
            val ok = infos.filter { ci -> ci.supportedTypes.any { it.equals(mime, true) } }
                .filter { ci ->
                    try {
                        ci.getCapabilitiesForType(mime).videoCapabilities.isSizeSupported(w, h)
                    } catch (_: Exception) { false }
                }
            // prefere hardware
            val best = ok.firstOrNull { !it.isSoftwareOnly } ?: ok.firstOrNull()
            if (best != null) return mime to best
        }
        return null
    }

    // Toques na tela e CPU acordada (tela apagada)
    private var wakeLock: PowerManager.WakeLock? = null
    private var oldShowTouches = -1

    private fun applyRecExtras() {
        releaseRecExtras()
        if (Prefs.screenOff(this)) {
            try {
                wakeLock = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "47rec:rec")
                    .apply { acquire(6 * 60 * 60 * 1000L) }
            } catch (_: Exception) { }
        }
        if (Prefs.showTouches(this) && Settings.System.canWrite(this)) {
            try {
                oldShowTouches = Settings.System.getInt(contentResolver, "show_touches", 0)
                Settings.System.putInt(contentResolver, "show_touches", 1)
            } catch (_: Exception) { oldShowTouches = -1 }
        }
    }

    private fun releaseRecExtras() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        if (oldShowTouches >= 0) {
            try { Settings.System.putInt(contentResolver, "show_touches", oldShowTouches) } catch (_: Exception) { }
            oldShowTouches = -1
        }
    }

    /** Se a tela girou desde a última vez, ajusta o display virtual e o leitor de prints. */
    private fun syncDisplaySize() {
        val disp = display ?: return
        if (recState != ST_IDLE || finishing) return
        val s = computeSize()
        if (s[0] == vw && s[1] == vh) return
        vw = s[0]
        vh = s[1]
        try { disp.resize(vw, vh, resources.displayMetrics.densityDpi) } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        reader = ImageReader.newInstance(vw, vh, PixelFormat.RGBA_8888, 2)
    }

    // --------------------------------------------------------------- gravação
    private fun startRecording(kind: Int) {
        if (!active || recState != ST_IDLE || finishing) return
        val disp = display ?: return
        syncDisplaySize()   // pega a orientação de AGORA (paisagem ou retrato)
        recKind = kind
        videoTrack = -1
        audioTrack = -1
        muxStarted = false
        baseUs = -1L
        muxReady = CountDownLatch(1)
        videoFormat = null
        audioFormat = null
        pauseOffsetUs = 0L
        waitKey = false
        synchronized(ringLock) { ring.clear() }

        try {
            if (kind == MODE_RECORD) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "47Recorder_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                videoUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                pfd = contentResolver.openFileDescriptor(videoUri!!, "rw")
                muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            }

            val pick = pickEncoder(vw, vh)
            val mime = pick?.first ?: MediaFormat.MIMETYPE_VIDEO_AVC
            var br = Prefs.bitrate(this) * 1_000_000
            var fps = Prefs.fps(this)
            try {
                val caps = pick?.second?.getCapabilitiesForType(mime)?.videoCapabilities
                if (caps != null) {
                    br = br.coerceIn(caps.bitrateRange.lower, caps.bitrateRange.upper)
                    if (!caps.areSizeAndRateSupported(vw, vh, fps.toDouble())) {
                        fps = caps.getSupportedFrameRatesFor(vw, vh).upper.toInt().coerceAtLeast(15)
                    }
                }
            } catch (_: Exception) { }
            if (Prefs.codec(this) == 1 && mime != MediaFormat.MIMETYPE_VIDEO_HEVC) {
                toast("HEVC indisponível neste aparelho/tamanho. Usando H.264.")
            }
            val vf = MediaFormat.createVideoFormat(mime, vw, vh).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000)
                if (fps > 30) {
                    try {
                        setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
                        setInteger(MediaFormat.KEY_PRIORITY, 0)
                    } catch (_: Exception) { }
                }
            }
            val venc = if (pick != null) MediaCodec.createByCodecName(pick.second.name)
                else MediaCodec.createEncoderByType(mime)
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = venc.createInputSurface()
            venc.start()
            videoEnc = venc

            val proj = projection
            val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val wantInternal = Prefs.internal(this)
            // Lê a preferência atual (não só o flag do início da sessão)
            val wantMic = useMicFlag || Prefs.mic(this)
            if (micOk && (wantInternal || wantMic)) {
                // Android 14+: precisa do tipo MICROPHONE no FGS antes do AudioRecord
                ensureMicForeground()
            }
            hasAudio = if (micOk && (wantInternal || wantMic)) {
                setupAudio(proj, wantInternal, wantMic)
            } else {
                false
            }
            if (!hasAudio && micOk && (wantInternal || wantMic)) {
                toast("Áudio indisponível. Gravando só vídeo.")
            } else if (!micOk && (wantInternal || wantMic)) {
                toast("Sem permissão de microfone. Gravando só vídeo.")
            }

            disp.setSurface(inputSurface)
        } catch (e: Exception) {
            toast("Falha ao iniciar a gravação: ${e.message}")
            abortEncoding()
            return
        }

        recState = ST_REC
        audioRun = true
        videoThread = Thread({ videoLoop() }, "47-video").also { it.start() }
        if (hasAudio) {
            audioThread = Thread({ audioLoop() }, "47-audio").also { it.start() }
        }
        showRecOverlays()
        applyClean()
        updateNotification()
        menuRefresh?.invoke()
        onRecordingStarted()
    }

    // ------------------------------------- extras: contagem, tempo, agitar, aviso
    private val autoStopRunnable = Runnable {
        if (recState != ST_IDLE) {
            toast("Tempo máximo atingido. Gravação parada.")
            stopRecording()
        }
    }

    private val orbTicker = object : Runnable {
        override fun run() {
            if (recState == ST_IDLE) return
            val v = orbView
            if (v != null) {
                val s = elapsedRecMs() / 1000
                val icon = if (recState == ST_PAUSED) "⏸ " else ""
                v.text = icon + String.format("%02d:%02d", s / 60, s % 60)
            }
            // Atualiza minutagem na notificação (principalmente quando o círculo está oculto)
            updateNotification()
            main.postDelayed(this, 1000)
        }
    }

    private val shakeListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val g = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat() / SensorManager.GRAVITY_EARTH
            if (g > 2.8f) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastShake > 1200L) shakeCount = 0
                if (now - lastShake > 150L) {
                    shakeCount++
                    lastShake = now
                }
                if (shakeCount >= 3) {
                    shakeCount = 0
                    main.post {
                        if (recState != ST_IDLE) {
                            toast("Gravação parada (celular agitado)")
                            stopRecording()
                        }
                    }
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun elapsedRecMs(): Long {
        val now = SystemClock.elapsedRealtime()
        val extra = if (recState == ST_PAUSED) now - pauseBeganMs else 0L
        return maxOf(0L, now - recStartMs - pausedTotalMs - extra)
    }

    private fun styleOrbTime() {
        val v = orbView ?: return
        v.textSize = Prefs.size(this) / 5.2f
    }

    private fun styleOrbIdle() {
        val v = orbView ?: return
        val label = Prefs.orbText(this)
        v.text = label
        v.textSize = Prefs.size(this) / (if (label.length >= 3) 4.2f else 3.2f)
    }

    private fun onRecordingStarted() {
        recStartMs = SystemClock.elapsedRealtime()
        pausedTotalMs = 0L
        pauseBeganMs = 0L
        styleOrbTime()
        main.removeCallbacks(orbTicker)
        main.post(orbTicker)
        main.removeCallbacks(autoStopRunnable)
        val mins = Prefs.autoStopMin(this)
        if (mins > 0 && recKind == MODE_RECORD) main.postDelayed(autoStopRunnable, mins * 60_000L)
        startShake()
        applyRecExtras()
    }

    private fun onRecordingStopped() {
        releaseRecExtras()
        main.removeCallbacks(orbTicker)
        main.removeCallbacks(autoStopRunnable)
        stopShake()
        styleOrbIdle()
    }

    private fun startShake() {
        if (!Prefs.shake(this)) return
        try {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sensorMgr = sm
            shakeCount = 0
            lastShake = 0L
            sm.registerListener(shakeListener, acc, SensorManager.SENSOR_DELAY_UI)
        } catch (_: Exception) { }
    }

    private fun stopShake() {
        try { sensorMgr?.unregisterListener(shakeListener) } catch (_: Exception) { }
        sensorMgr = null
    }

    /** Começa a gravar, com contagem regressiva se estiver ligada. */
    private fun beginRecording(kind: Int) {
        if (!active || recState != ST_IDLE || finishing || counting) return
        val secs = Prefs.countdown(this)
        if (secs <= 0 || kind != MODE_RECORD) {
            startRecording(kind)
            return
        }
        counting = true
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.textSize = 96f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(Color.WHITE)
        tv.setShadowLayer(16f, 0f, 0f, Color.BLACK)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.CENTER
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, p)
            countdownView = tv
        } catch (_: Exception) {
            counting = false
            startRecording(kind)
            return
        }
        var left = secs
        val tick = object : Runnable {
            override fun run() {
                if (!counting) return
                if (left <= 0) {
                    removeCountdown()
                    startRecording(kind)
                    return
                }
                tv.text = left.toString()
                left--
                main.postDelayed(this, 1000)
            }
        }
        main.post(tick)
    }

    private fun removeCountdown() {
        counting = false
        val v = countdownView
        if (v != null) {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) { }
        }
        countdownView = null
    }

    /** Aviso "Vídeo salvo" com atalhos para abrir e compartilhar. */
    private fun notifySaved(uri: Uri) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("saved47", "Gravações salvas", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val view = Intent(this, PlayerActivity::class.java)
            view.putStringArrayListExtra("uris", arrayListOf(uri.toString()))
            view.putStringArrayListExtra("names", arrayListOf("Gravação"))
            view.putExtra("kind", 0)
            view.putExtra("index", 0)
            view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val send = Intent(Intent.ACTION_SEND)
            send.type = "video/mp4"
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.clipData = ClipData.newRawUri("video", uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(send, "Compartilhar vídeo")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val piView = PendingIntent.getActivity(this, 91, view, flags)
            val piSend = PendingIntent.getActivity(this, 92, chooser, flags)
            val n = NotificationCompat.Builder(this, "saved47")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Vídeo salvo")
                .setContentText("Toque para abrir ou compartilhe")
                .setContentIntent(piView)
                .setAutoCancel(true)
                .addAction(0, "Compartilhar", piSend)
                .addAction(0, "Abrir", piView)
                .build()
            nm.notify(93, n)
        } catch (_: Exception) { }
    }

    private fun togglePause() {
        if (recKind != MODE_RECORD) return
        if (recState == ST_REC) {
            pauseStartUs = System.nanoTime() / 1000
            pauseBeganMs = SystemClock.elapsedRealtime()
            recState = ST_PAUSED
        } else if (recState == ST_PAUSED) {
            pauseOffsetUs += System.nanoTime() / 1000 - pauseStartUs
            pausedTotalMs += SystemClock.elapsedRealtime() - pauseBeganMs
            waitKey = true   // só volta a gravar vídeo a partir de um quadro-chave
            try {
                val b = Bundle()
                b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                videoEnc?.setParameters(b)
            } catch (_: Exception) { }
            recState = ST_REC
        } else {
            return
        }
        updateNotification()
        menuRefresh?.invoke()
    }

    private fun stopRecording() {
        if (recState == ST_IDLE || finishing) return
        finishing = true
        recState = ST_IDLE
        audioRun = false
        onRecordingStopped()
        removeRecOverlays()
        applyClean()
        updateNotification()
        menuRefresh?.invoke()
        Thread({
            finalizeEncoding()
            main.post { onFinalized() }
        }, "47-finalize").start()
    }

    private fun onFinalized() {
        finishing = false
        val msg = if (recKind == MODE_REPLAY) "Replay encerrado" else "Vídeo salvo em Movies/47 Recorder"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        val su = lastSavedUri
        lastSavedUri = null
        if (recKind == MODE_RECORD && su != null) notifySaved(su)
        if (endAfterStop) {
            releaseSession()
        } else {
            updateNotification()
            menuRefresh?.invoke()
        }
    }

    private fun finalizeEncoding() {
        try { display?.setSurface(null) } catch (_: Exception) { }
        try { videoEnc?.signalEndOfInputStream() } catch (_: Exception) { }
        try { videoThread?.join(5000) } catch (_: Exception) { }
        try { audioThread?.join(5000) } catch (_: Exception) { }

        try { videoEnc?.stop() } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.stop() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { inputSurface?.release() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        videoEnc = null
        audioEnc = null
        inputSurface = null
        internalRec = null
        micRec = null
        videoThread = null
        audioThread = null

        synchronized(muxLock) {
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            muxer = null
        }
        synchronized(ringLock) { ring.clear() }
        try { pfd?.close() } catch (_: Exception) { }
        pfd = null

        val u = videoUri
        if (u != null) {
            val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            try { contentResolver.update(u, v, null, null) } catch (_: Exception) { }
            lastSavedUri = u
        }
        videoUri = null
    }

    private fun abortEncoding() {
        audioRun = false
        try { display?.setSurface(null) } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { inputSurface?.release() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        try { muxer?.release() } catch (_: Exception) { }
        try { pfd?.close() } catch (_: Exception) { }
        val u = videoUri
        if (u != null) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
        }
        videoEnc = null
        audioEnc = null
        inputSurface = null
        internalRec = null
        micRec = null
        muxer = null
        pfd = null
        videoUri = null
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio(proj: MediaProjection?, useInternal: Boolean, useMic: Boolean): Boolean {
        if (!useInternal && !useMic) return false
        // Limpa restos de tentativas anteriores
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        internalRec = null
        micRec = null

        // Captura interna (som do aparelho) — falha isolada não impede o microfone
        if (useInternal && proj != null) {
            try {
                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()
                val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val minStereo = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setBufferSizeInBytes(maxOf(minStereo, 16_384) * 2)
                    .build()
                if (rec.state == AudioRecord.STATE_INITIALIZED) {
                    internalRec = rec
                } else {
                    rec.release()
                }
            } catch (_: Exception) {
                try { internalRec?.release() } catch (_: Exception) { }
                internalRec = null
            }
        }

        // Microfone — tenta MIC e, se falhar, VOICE_COMMUNICATION
        if (useMic) {
            micRec = openMicRecord()
        }

        if (internalRec == null && micRec == null) return false

        return try {
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
            audioEnc = aenc
            true
        } catch (e: Exception) {
            try { internalRec?.release() } catch (_: Exception) { }
            try { micRec?.release() } catch (_: Exception) { }
            try { audioEnc?.release() } catch (_: Exception) { }
            internalRec = null
            micRec = null
            audioEnc = null
            false
        }
    }

    @SuppressLint("MissingPermission")
    private fun openMicRecord(): AudioRecord? {
        val minMono = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minMono <= 0) return null
        val buf = maxOf(minMono, 8_192) * 2
        val sources = intArrayOf(
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.CAMCORDER,
            MediaRecorder.AudioSource.DEFAULT
        )
        for (src in sources) {
            try {
                val m = AudioRecord(src, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, buf)
                if (m.state == AudioRecord.STATE_INITIALIZED) {
                    // Fixa o microfone escolhido (fone, celular, Bluetooth…)
                    MicDevices.applyPreferred(this, m)
                    return m
                }
                m.release()
            } catch (_: Exception) { }
        }
        return null
    }

    // ------------------------------------------------------------ threads
    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(true, enc.outputFormat)
                    i >= 0 -> {
                        val ob = enc.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            if (recKind == MODE_RECORD && !muxStarted &&
                                !muxReady.await(3, TimeUnit.SECONDS)) forceStart()
                            writeSample(true, ob, info)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun audioLoop() {
        val enc = audioEnc ?: return
        val rec = internalRec
        val mic = micRec
        // Bloco fixo: 1024 frames estéreo (~21 ms @ 48 kHz)
        val framesPerBlock = 1024
        val stereo = ShortArray(framesPerBlock * 2)
        val internalBuf = ShortArray(framesPerBlock * 2)
        val micBuf = ShortArray(framesPerBlock)
        val info = MediaCodec.BufferInfo()
        var frames = 0L
        var startUs = -1L
        // Quando os dois estão ativos: mic com prioridade, interno um pouco mais baixo
        val both = rec != null && mic != null
        val micGain = if (both) 1.15f else 1f
        val intGain = if (both) 0.65f else 1f
        // O som interno é capturado ANTES do controle de volume do Android.
        // Para respeitar o volume que o usuário baixou, aplicamos o mesmo nível na gravação.
        val followVol = Prefs.followVolume(this)
        var volTarget = if (followVol) deviceVolumeGain() else 1f
        var volCur = volTarget
        var blockCount = 0
        try {
            rec?.startRecording()
            mic?.startRecording()
            while (audioRun) {
                // Zera o bloco de saída
                java.util.Arrays.fill(stereo, 0.toShort())

                // ---- lê os dois de forma independente (não-bloqueante) ----
                val deadline = System.nanoTime() + 25_000_000L // ~25 ms por bloco
                var intGot = 0
                var micGot = 0
                var intDead = false
                var micDead = false
                while (audioRun && System.nanoTime() < deadline) {
                    var progress = false
                    if (rec != null && !intDead && intGot < internalBuf.size) {
                        val r = rec.read(
                            internalBuf, intGot, internalBuf.size - intGot,
                            AudioRecord.READ_NON_BLOCKING
                        )
                        when {
                            r == AudioRecord.ERROR_INVALID_OPERATION ||
                                r == AudioRecord.ERROR_BAD_VALUE ||
                                r == AudioRecord.ERROR_DEAD_OBJECT -> intDead = true
                            r > 0 -> { intGot += r; progress = true }
                        }
                    }
                    if (mic != null && !micDead && micGot < micBuf.size) {
                        val r = mic.read(
                            micBuf, micGot, micBuf.size - micGot,
                            AudioRecord.READ_NON_BLOCKING
                        )
                        when {
                            r == AudioRecord.ERROR_INVALID_OPERATION ||
                                r == AudioRecord.ERROR_BAD_VALUE ||
                                r == AudioRecord.ERROR_DEAD_OBJECT -> micDead = true
                            r > 0 -> { micGot += r; progress = true }
                        }
                    }
                    val intDone = rec == null || intDead || intGot >= internalBuf.size
                    val micDone = mic == null || micDead || micGot >= micBuf.size
                    if (intDone && micDone) break
                    if (!progress) {
                        try { Thread.sleep(1) } catch (_: InterruptedException) { }
                    }
                }
                if (intDead) intGot = -1
                if (micDead) micGot = -1

                if (intGot < 0 && micGot < 0) break
                if (intGot <= 0 && micGot <= 0) {
                    try { Thread.sleep(4) } catch (_: InterruptedException) { }
                    continue
                }

                // Acompanha o volume do aparelho (~5x por segundo) com transição suave
                if (followVol) {
                    if (blockCount++ % 8 == 0) volTarget = deviceVolumeGain()
                    volCur += (volTarget - volCur) * 0.2f
                    if (volTarget == 0f && volCur < 0.002f) volCur = 0f
                }

                // // Mistura: interno (L/R) + mic (mono → L e R), com ganhos e soft-clip
                val nFrames = framesPerBlock
                for (k in 0 until nFrames) {
                    var l = 0f
                    var r = 0f
                    if (intGot > 0) {
                        val il = if (k * 2 < intGot) internalBuf[k * 2].toInt() else 0
                        val ir = if (k * 2 + 1 < intGot) internalBuf[k * 2 + 1].toInt() else il
                        l += il * intGain * volCur
                        r += ir * intGain * volCur
                    }
                    if (micGot > 0) {
                        val m = if (k < micGot) micBuf[k].toInt() else 0
                        val mg = m * micGain
                        l += mg
                        r += mg
                    }
                    stereo[k * 2] = softClip(l)
                    stereo[k * 2 + 1] = softClip(r)
                }

                val n = nFrames * 2
                if (startUs < 0) startUs = System.nanoTime() / 1000
                val pts = startUs + frames * 1_000_000L / SAMPLE_RATE
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(stereo, 0, n)
                    enc.queueInputBuffer(idx, 0, n * 2, pts, 0)
                }
                frames += nFrames
                drainAudio(enc, info, false)
            }
            try { rec?.stop() } catch (_: Exception) { }
            try { mic?.stop() } catch (_: Exception) { }

            // Fim de stream
            val pts = (if (startUs < 0) System.nanoTime() / 1000 else startUs) +
                frames * 1_000_000L / SAMPLE_RATE
            var tries = 0
            while (tries++ < 20) {
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
            }
            drainAudio(enc, info, true)
        } catch (_: Exception) { }
    }

    /** Ganho (0..1) equivalente ao volume de mídia do aparelho; 0 quando está no mudo. */
    private fun deviceVolumeGain(): Float {
        return try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val v = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (v <= 0 || am.isStreamMute(AudioManager.STREAM_MUSIC)) 0f
            else {
                // o volume do Android é logarítmico: uma curva quadrática se aproxima bem
                val f = v.toFloat() / max
                f * f
            }
        } catch (_: Exception) { 1f }
    }

    /** Evita distorção seca quando mic + interno somam alto. */
    private fun softClip(v: Float): Short {
        val x = v / 32768f
        val y = if (x > 1f) 1f else if (x < -1f) -1f else {
            // soft knee leve
            val a = kotlin.math.abs(x)
            if (a < 0.9f) x else {
                val s = if (x >= 0) 1f else -1f
                s * (0.9f + (a - 0.9f) / (1f + (a - 0.9f) * 8f))
            }
        }
        return (y * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }

    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, untilEos: Boolean) {
        var idleRounds = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(info, if (untilEos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(false, enc.outputFormat)
                i >= 0 -> {
                    val ob = enc.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0) writeSample(false, ob, info)
                    enc.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!untilEos || ++idleRounds > 100) return
                }
            }
        }
    }

    // -------------------------------------------------------------- muxer
    private fun onFormat(video: Boolean, f: MediaFormat) {
        if (recKind == MODE_REPLAY) {
            if (video) videoFormat = f else audioFormat = f
            return
        }
        synchronized(muxLock) {
            val m = muxer ?: return
            if (video) videoTrack = m.addTrack(f) else audioTrack = m.addTrack(f)
            if (!muxStarted && videoTrack >= 0 && (!hasAudio || audioTrack >= 0)) {
                m.start()
                muxStarted = true
                muxReady.countDown()
            }
        }
    }

    /** Áudio não chegou a tempo: começa só com vídeo. */
    private fun forceStart() {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (!muxStarted && videoTrack >= 0) {
                hasAudio = false
                m.start()
                muxStarted = true
                muxReady.countDown()
            }
        }
    }

    private fun writeSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (recState == ST_PAUSED) return            // pausado: descarta
        if (video && waitKey) {
            if (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME == 0) return
            waitKey = false
        }
        if (recKind == MODE_REPLAY) {
            bufferSample(video, buf, info)
            return
        }
        synchronized(muxLock) {
            if (!muxStarted) return
            if (baseUs < 0) baseUs = info.presentationTimeUs
            info.presentationTimeUs = maxOf(0L, info.presentationTimeUs - baseUs - pauseOffsetUs)
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            val track = if (video) videoTrack else audioTrack
            if (track < 0) return
            try { muxer?.writeSampleData(track, buf, info) } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------- replay
    private fun bufferSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        val arr = ByteArray(info.size)
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        buf.get(arr)
        val keepUs = (Prefs.replaySec(this) + 3) * 1_000_000L
        synchronized(ringLock) {
            ring.addLast(Sample(video, arr, info.presentationTimeUs, info.flags))
            while (true) {
                val first = ring.peekFirst() ?: break
                if (info.presentationTimeUs - first.ptsUs > keepUs) ring.removeFirst() else break
            }
        }
    }

    private fun saveReplay() {
        if (recKind != MODE_REPLAY || recState != ST_REC) return
        val vf = videoFormat
        if (vf == null) {
            toast("O replay ainda não tem dados. Aguarde um instante.")
            return
        }
        val af = audioFormat
        val snapshot: List<Sample> = synchronized(ringLock) { ring.toList() }
        val windowSec = Prefs.replaySec(this)
        Thread({
            var uri: Uri? = null
            var fd: ParcelFileDescriptor? = null
            var mux: MediaMuxer? = null
            var saved = false
            try {
                val latest = snapshot.maxOfOrNull { it.ptsUs } ?: 0L
                val windowStart = latest - windowSec * 1_000_000L
                val keyFlag = MediaCodec.BUFFER_FLAG_KEY_FRAME
                val start = snapshot.firstOrNull {
                    it.video && (it.flags and keyFlag) != 0 && it.ptsUs >= windowStart
                }?.ptsUs ?: snapshot.firstOrNull {
                    it.video && (it.flags and keyFlag) != 0
                }?.ptsUs

                if (start == null) {
                    toast("O replay ainda não tem dados. Aguarde um instante.")
                } else {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "47Replay_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    fd = contentResolver.openFileDescriptor(uri!!, "rw")
                    mux = MediaMuxer(fd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    val vt = mux!!.addTrack(vf)
                    val at = if (af != null) mux!!.addTrack(af) else -1
                    mux!!.start()
                    val bi = MediaCodec.BufferInfo()
                    for (s in snapshot) {
                        if (s.ptsUs < start) continue
                        val track = if (s.video) vt else at
                        if (track < 0) continue
                        bi.set(0, s.data.size, s.ptsUs - start, s.flags)
                        mux!!.writeSampleData(track, ByteBuffer.wrap(s.data), bi)
                    }
                    mux!!.stop()
                    toast("Replay salvo em Movies/47 Recorder")
                    saved = true
                }
            } catch (e: Exception) {
                toast("Falha ao salvar o replay")
            } finally {
                try { mux?.release() } catch (_: Exception) { }
                try { fd?.close() } catch (_: Exception) { }
                uri?.let {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    try { contentResolver.update(it, v, null, null) } catch (_: Exception) { }
                }
            }
            val su = uri
            if (saved && su != null) main.post { notifySaved(su) }
        }, "47-replay-save").start()
    }

    // -------------------------------------------------------------- print
    private fun takeShot() {
        syncDisplaySize()
        val rd = reader ?: return
        val disp = display ?: return
        if (shotBusy || finishing) return
        shotBusy = true
        val target: Surface? = inputSurface   // null quando só o círculo está aberto
        main.post { menuRoot?.visibility = View.INVISIBLE }

        Thread({
            val box = arrayOfNulls<Image>(1)
            val latch = CountDownLatch(1)
            try {
                Thread.sleep(350)   // dá tempo do botão sumir da tela
                rd.setOnImageAvailableListener({ r ->
                    val img = r.acquireLatestImage()
                    if (img != null) {
                        if (box[0] == null) {
                            box[0] = img
                            latch.countDown()
                        } else {
                            img.close()
                        }
                    }
                }, main)
                disp.setSurface(rd.surface)
                latch.await(2, TimeUnit.SECONDS)
                disp.setSurface(target)
                rd.setOnImageAvailableListener(null, null)
                val img = box[0]
                if (img == null) toast("Não foi possível capturar a tela") else saveShot(img)
            } catch (e: Exception) {
                try { disp.setSurface(target) } catch (_: Exception) { }
                toast("Falha ao capturar a tela")
            } finally {
                shotBusy = false
                main.post { applyClean() }
            }
        }, "47-shot").start()
    }

    private fun saveShot(img: Image) {
        val w = img.width
        val h = img.height
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val padded = Bitmap.createBitmap(
            w + (rowStride - pixelStride * w) / pixelStride, h, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        img.close()
        val bmp = Bitmap.createBitmap(padded, 0, 0, w, h)

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "47Print_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/47 Recorder")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            toast("Não foi possível salvar o print")
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        toast("Print salvo em Pictures/47 Recorder")
    }

    // ------------------------------------------------------------ overlays
    private fun applyClean() {
        val v = menuRoot ?: return
        v.visibility = if (Prefs.clean(this) && recState != ST_IDLE) View.GONE else View.VISIBLE
    }

    private fun showRecOverlays() {
        if (Prefs.watermark(this)) showWatermark()
        if (Prefs.facecam(this) &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) showFaceCam()
    }

    private fun removeRecOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val f = faceView
        if (f != null) {
            try { wm.removeView(f) } catch (_: Exception) { }
        }
        val w = wmView
        if (w != null) {
            try { wm.removeView(w) } catch (_: Exception) { }
        }
        faceView = null
        wmView = null
        try { camSession?.close() } catch (_: Exception) { }
        try { camDevice?.close() } catch (_: Exception) { }
        camSession = null
        camDevice = null
    }

    private fun removeOverlays() {
        removeRecOverlays()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = menuRoot
        if (m != null) {
            try { wm.removeView(m) } catch (_: Exception) { }
        }
        menuRoot = null
        orbView = null
    }

    /** Só esconde o círculo; gravação e sessão continuam. */
    private fun hideOrb() {
        if (orbHidden) return
        orbHidden = true
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = menuRoot
        if (m != null) {
            try { wm.removeView(m) } catch (_: Exception) { }
        }
        menuRoot = null
        orbView = null
        updateNotification()
        toast("Círculo oculto. Use a notificação para trazer de volta.")
    }

    /** Traz o círculo de volta. */
    private fun showOrb() {
        if (!active || !orbHidden) return
        orbHidden = false
        showMenu()
        if (recState != ST_IDLE) {
            main.removeCallbacks(orbTicker)
            main.post(orbTicker)
        }
        updateNotification()
    }

    private fun attachDrag(
        target: View, windowView: View, params: WindowManager.LayoutParams, onClick: (() -> Unit)?
    ) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        target.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { wm.updateViewLayout(windowView, params) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    private fun toggleDraw() {
        try {
            startForegroundService(
                Intent(this, DrawService::class.java).setAction(DrawService.ACTION_TOGGLE)
            )
        } catch (_: Exception) {
            toast("Não foi possível abrir o desenho agora")
        }
    }

    private fun toggleVoice() {
        if (VoiceService.state != 0) {
            try {
                startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            } catch (_: Exception) { }
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Permita o microfone no app (aba 🎙️) primeiro")
            return
        }
        try {
            startForegroundService(
                Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_START)
            )
        } catch (_: Exception) {
            toast("Não foi possível gravar áudio agora")
        }
    }

    private fun showMenu() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val svc = this
        val sizePx = dp(Prefs.size(svc))
        val btnColor = Prefs.color(svc)
        val alphaV = Prefs.opacity(svc) / 100f
        val panelBg = Prefs.menuBg(svc)
        val panelTxt = Prefs.contrast(panelBg)
        val orbLabel = Prefs.orbText(svc)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(12)
        params.y = dp(200)

        val root = LinearLayout(svc)
        root.orientation = LinearLayout.VERTICAL

        val panel = LinearLayout(svc)
        panel.orientation = LinearLayout.VERTICAL
        panel.visibility = View.GONE
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        val panelShape = GradientDrawable()
        panelShape.cornerRadius = dp(22).toFloat()
        panelShape.setColor(panelBg)
        panel.background = panelShape

        val btn = TextView(svc)
        btn.text = orbLabel
        btn.gravity = Gravity.CENTER
        btn.textSize = Prefs.size(svc) / (if (orbLabel.length >= 3) 4.2f else 3.2f)
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.setTextColor(Prefs.contrast(btnColor))
        btn.background = Ui.orbDrawable(btnColor, Prefs.orbShape(svc), sizePx)
        btn.alpha = alphaV
        orbView = btn

        var expanded = false
        var shift = 0
        var xView: View? = null

        fun layoutRoot(panelFirst: Boolean) {
            root.removeAllViews()
            val bl = LinearLayout.LayoutParams(sizePx, sizePx)
            val pl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (panelFirst) {
                pl.bottomMargin = dp(8)
                root.addView(panel, pl)
                root.addView(btn, bl)
            } else {
                pl.topMargin = dp(8)
                root.addView(btn, bl)
                root.addView(panel, pl)
            }
        }

        fun collapse() {
            if (!expanded) return
            expanded = false
            panel.visibility = View.GONE
            layoutRoot(false)
            params.y += shift
            shift = 0
            try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        }

        fun addItem(iconStr: String, labelStr: String, action: () -> Unit) {
            val line = LinearLayout(svc)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(4), dp(4), dp(16), dp(4))

            val ic = TextView(svc)
            ic.text = iconStr
            ic.gravity = Gravity.CENTER
            ic.textSize = 17f
            ic.setTextColor(Prefs.contrast(btnColor))
            ic.background = Ui.orbDrawable(btnColor, 0, dp(44))
            line.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))

            val tv = TextView(svc)
            tv.text = labelStr
            tv.textSize = 15f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(panelTxt)
            val tl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            tl.leftMargin = dp(12)
            line.addView(tv, tl)

            line.setOnClickListener {
                collapse()
                action()
            }
            panel.addView(
                line,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        fun rebuildPanel() {
            panel.removeAllViews()
            if (recState == ST_IDLE) {
                addItem("●", "Gravar") { beginRecording(MODE_RECORD) }
                addItem(
                    if (VoiceService.state != 0) "⏹" else "🎙️",
                    if (VoiceService.state != 0) "Parar áudio" else "Gravar áudio"
                ) { toggleVoice() }
                if (Prefs.showDraw(svc)) addItem("✏️", "Desenhar na tela") { toggleDraw() }
                if (Prefs.showShot(svc)) addItem("📷", "Tirar print") { takeShot() }
                addItem("✕", "Ocultar círculo") { hideOrb() }
            } else {
                if (recKind == MODE_REPLAY) {
                    addItem("💾", "Salvar replay") { saveReplay() }
                    addItem("■", "Parar") { stopRecording() }
                } else {
                    if (recState == ST_PAUSED) {
                        addItem("▶", "Retomar gravação") { togglePause() }
                    } else {
                        addItem("⏸", "Pausar gravação") { togglePause() }
                    }
                    addItem("■", "Parar gravação") { stopRecording() }
                }
                if (Prefs.showDraw(svc)) addItem("✏️", "Desenhar na tela") { toggleDraw() }
                if (Prefs.showShot(svc)) addItem("📷", "Tirar print") { takeShot() }
            }
        }

        fun expand() {
            if (expanded) return
            expanded = true
            rebuildPanel()
            val spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            panel.measure(spec, spec)
            val ph = panel.measuredHeight + dp(8)
            val above = params.y + sizePx / 2 > realMetrics().heightPixels / 2
            if (above) {
                shift = minOf(ph, params.y)
                params.y -= shift
            } else {
                shift = 0
            }
            layoutRoot(above)
            panel.visibility = View.VISIBLE
            try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        }

        // ---- alvo "X" que aparece ao arrastar o botão
        fun hitX(): Boolean {
            val cx = params.x + sizePx / 2
            val cy = params.y + sizePx / 2
            val tx = realMetrics().widthPixels / 2
            val ty = realMetrics().heightPixels - dp(112)
            val dx = (cx - tx).toDouble()
            val dy = (cy - ty).toDouble()
            return Math.sqrt(dx * dx + dy * dy) < dp(80)
        }

        fun showX() {
            if (xView != null) return
            val v = TextView(svc)
            v.text = "✕"
            v.gravity = Gravity.CENTER
            v.textSize = 26f
            v.setTextColor(Color.WHITE)
            v.background = Ui.orbDrawable(0xE6B71C1C.toInt(), 0, dp(64))
            val xp = WindowManager.LayoutParams(
                dp(64), dp(64),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            xp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            xp.y = dp(80)
            try {
                wm.addView(v, xp)
                xView = v
            } catch (_: Exception) { }
        }

        fun hideX() {
            val v = xView
            if (v != null) {
                try { wm.removeView(v) } catch (_: Exception) { }
            }
            xView = null
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12)) {
                        moved = true
                        collapse()
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        showX()
                    } else if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
                        val near = hitX()
                        val xv = xView
                        if (xv != null) {
                            xv.scaleX = if (near) 1.35f else 1f
                            xv.scaleY = if (near) 1.35f else 1f
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val drop = hitX()
                        hideX()
                        if (drop) hideOrb()
                    } else {
                        if (expanded) collapse() else expand()
                    }
                }
                MotionEvent.ACTION_CANCEL -> hideX()
            }
            true
        }

        menuRefresh = { if (expanded) rebuildPanel() }
        layoutRoot(false)
        wm.addView(root, params)
        menuRoot = root
    }

    private fun showWatermark() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = Prefs.wmText(this@RecorderService)
            textSize = 14f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 1f, 1f, Color.BLACK)
            alpha = 0.85f
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val g = when (Prefs.wmPos(this)) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = g; x = dp(12); y = dp(48) }
        try {
            wm.addView(tv, p)
            wmView = tv
        } catch (_: Exception) { }
    }

    private fun showFaceCam() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val rm = realMetrics()
        val shape = Prefs.camShape(this)
        val w = dp(Prefs.camSize(this))
        val h = if (shape == 2) w * 3 / 4 else w
        val bw = if (Prefs.camBorder(this)) dp(3) else 0
        val vw = maxOf(dp(40), w - 2 * bw)
        val vh = maxOf(dp(30), h - 2 * bw)

        val container = FrameLayout(this)
        val bg = GradientDrawable()
        if (shape == 0) {
            bg.shape = GradientDrawable.OVAL
        } else {
            bg.shape = GradientDrawable.RECTANGLE
            bg.cornerRadius = if (shape == 1) w * 0.2f else dp(10).toFloat()
        }
        bg.setColor(Color.TRANSPARENT)
        if (bw > 0) bg.setStroke(bw, Prefs.color(this))
        container.background = bg
        container.alpha = Prefs.camOpacity(this) / 100f

        val tv = TextureView(this)
        tv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                if (shape == 0) {
                    outline.setOval(0, 0, view.width, view.height)
                } else {
                    val r = if (shape == 1) view.width * 0.18f else dp(8).toFloat()
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
        }
        tv.clipToOutline = true
        container.addView(tv, FrameLayout.LayoutParams(vw, vh, Gravity.CENTER))

        val corner = Prefs.camCorner(this)
        val margin = dp(16)
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (corner == 1 || corner == 3) rm.widthPixels - w - margin else margin
        p.y = if (corner == 0 || corner == 1) dp(90) else rm.heightPixels - h - dp(140)

        val front = Prefs.camFacing(this) == 0
        val doMirror = front && Prefs.camMirror(this)
        val land = rm.widthPixels > rm.heightPixels
        val contentAspect = if (land) 4f / 3f else 0.75f
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, sw: Int, sh: Int) {
                // corta a imagem para preencher a janela sem deformar
                val a = vw.toFloat() / vh
                var sx = 1f
                var sy = 1f
                if (a >= contentAspect) {
                    sy = a / contentAspect
                } else {
                    sx = contentAspect / a
                }
                if (doMirror) sx = -sx
                tv.setTransform(Matrix().apply { setScale(sx, sy, vw / 2f, vh / 2f) })
                openCamera(st)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, sw: Int, sh: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        attachDrag(container, container, p, null)
        try {
            wm.addView(container, p)
            faceView = container
        } catch (_: Exception) { }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun openCamera(st: SurfaceTexture) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val want = if (Prefs.camFacing(this) == 0) {
                CameraCharacteristics.LENS_FACING_FRONT
            } else {
                CameraCharacteristics.LENS_FACING_BACK
            }
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val f = cm.getCameraCharacteristics(cid).get(CameraCharacteristics.LENS_FACING)
                if (f != null && f == want) {
                    id = cid
                    break
                }
            }
            if (id == null && cm.cameraIdList.isNotEmpty()) id = cm.cameraIdList[0]
            val camId = id ?: return
            st.setDefaultBufferSize(640, 480)
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    if (faceView == null) {
                        cam.close()
                        return
                    }
                    camDevice = cam
                    try {
                        val surf = Surface(st)
                        cam.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                camSession = s
                                try {
                                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                        .apply { addTarget(surf) }.build()
                                    s.setRepeatingRequest(req, null, null)
                                } catch (_: Exception) { }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) {}
                        }, null)
                    } catch (_: Exception) { }
                }
                override fun onDisconnected(cam: CameraDevice) { cam.close() }
                override fun onError(cam: CameraDevice, error: Int) { cam.close() }
            }, null)
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        releaseRecExtras()
        if (active) {
            active = false
            removeOverlays()
            try { display?.release() } catch (_: Exception) { }
            try { reader?.close() } catch (_: Exception) { }
            try { projection?.stop() } catch (_: Exception) { }
        }
        super.onDestroy()
    }
}
