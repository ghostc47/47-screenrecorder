package com.recorder47

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.Image
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.recorder47.START"
        const val ACTION_STOP = "com.recorder47.STOP"
        const val ACTION_SHOT = "com.recorder47.SHOT"
        const val ACTION_SAVE_REPLAY = "com.recorder47.SAVE_REPLAY"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_MIC = "mic"
        const val EXTRA_MODE = "mode"
        const val MODE_RECORD = 0
        const val MODE_REPLAY = 1
        const val MODE_SHOT = 2
        private const val CHANNEL_ID = "rec47"
        private const val NOTIF_ID = 47
        private const val SAMPLE_RATE = 44_100
    }

    private class Sample(val video: Boolean, val data: ByteArray, val ptsUs: Long, val flags: Int)

    private val main = Handler(Looper.getMainLooper())
    private var mode = MODE_RECORD

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var inputSurface: Surface? = null
    private var reader: ImageReader? = null
    private var pfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null

    @Volatile private var recording = false
    @Volatile private var finishing = false
    @Volatile private var shotBusy = false

    // Overlays
    private var menuRoot: View? = null
    private var faceView: View? = null
    private var wmView: View? = null
    private var camDevice: CameraDevice? = null
    private var camSession: CameraCaptureSession? = null

    // Codecs / captura de áudio / muxer
    private var muxer: MediaMuxer? = null
    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var internalRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val muxLock = Any()
    private val muxReady = CountDownLatch(1)
    private var videoTrack = -1
    private var audioTrack = -1
    private var hasAudio = false
    @Volatile private var muxStarted = false
    private var baseUs = -1L

    // Replay (buffer circular na memória)
    private val ring = ArrayDeque<Sample>()
    private val ringLock = Any()
    @Volatile private var videoFormat: MediaFormat? = null
    @Volatile private var audioFormat: MediaFormat? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                mode = intent.getIntExtra(EXTRA_MODE, MODE_RECORD)
                startAsForeground()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val mic = intent.getBooleanExtra(EXTRA_MIC, false)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    startSession(code, data, mic)
                } catch (e: Exception) {
                    Toast.makeText(this, "Falha ao iniciar: ${e.message}", Toast.LENGTH_LONG).show()
                    recording = false
                    cleanupAfterFailure()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_STOP -> if (recording) stopRecording() else if (!finishing) stopSelf()
            ACTION_SHOT -> if (recording) takeShot()
            ACTION_SAVE_REPLAY -> if (recording) saveReplay()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação", NotificationManager.IMPORTANCE_LOW)
        )
        fun act(action: String, rc: Int) = PendingIntent.getService(
            this, rc,
            Intent(this, RecorderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = when (mode) {
            MODE_REPLAY -> "Replay ativo (gravando só na memória)"
            MODE_SHOT -> "Menu de prints ativo"
            else -> "Gravando a tela…"
        }
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("47 Recorder")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "Parar", act(ACTION_STOP, 0))
            .addAction(0, "Print", act(ACTION_SHOT, 1))
        if (mode == MODE_REPLAY) b.addAction(0, "Salvar replay", act(ACTION_SAVE_REPLAY, 2))
        val notif: Notification = b.build()

        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mode != MODE_SHOT) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (Prefs.facecam(this) &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        ServiceCompat.startForeground(this, NOTIF_ID, notif, types)
    }

    // ---------------------------------------------------------------- início
    private fun startSession(code: Int, data: Intent, useMic: Boolean) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        // Obrigatório no Android 14+ antes de criar o VirtualDisplay
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { if (recording) stopRecording() }
        }, main)

        val metrics = resources.displayMetrics
        val fullW = metrics.widthPixels / 2 * 2
        val fullH = metrics.heightPixels / 2 * 2

        // Modo "só prints": sem codecs, o display espera o print
        if (mode == MODE_SHOT) {
            reader = ImageReader.newInstance(fullW, fullH, PixelFormat.RGBA_8888, 2)
            display = proj.createVirtualDisplay(
                "47Shot", fullW, fullH, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null
            )
            recording = true
            showOverlays()
            return
        }

        // Resolução: lado menor = ajuste escolhido, múltiplos de 16
        val scale = minOf(1f, Prefs.resolution(this).toFloat() / minOf(fullW, fullH))
        val w = ((fullW * scale) / 16).toInt() * 16
        val h = ((fullH * scale) / 16).toInt() * 16

        // Arquivo de saída (só no modo gravação normal)
        if (mode == MODE_RECORD) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "47Recorder_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            videoUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            pfd = contentResolver.openFileDescriptor(videoUri!!, "rw")
            muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        }

        // Encoder de vídeo (entrada por Surface)
        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, Prefs.bitrate(this@RecorderService) * 1_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, Prefs.fps(this@RecorderService))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000)
        }
        val venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = venc.createInputSurface()
        venc.start()
        videoEnc = venc

        // Áudio interno e/ou microfone
        val wantInternal = Prefs.internal(this)
        hasAudio = setupAudio(proj, wantInternal, useMic)
        if (!hasAudio && (wantInternal || useMic)) {
            toast("Áudio indisponível. Gravando só vídeo.")
        }

        // Leitor de imagens para prints durante a gravação
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)

        display = proj.createVirtualDisplay(
            "47Recorder", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null
        )

        recording = true
        videoThread = Thread({ videoLoop() }, "47-video").also { it.start() }
        if (hasAudio) {
            audioThread = Thread({ audioLoop() }, "47-audio").also { it.start() }
        }
        showOverlays()
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio(proj: MediaProjection, useInternal: Boolean, useMic: Boolean): Boolean {
        if (!useInternal && !useMic) return false
        return try {
            if (useInternal) {
                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()
                val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val minStereo = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setBufferSizeInBytes(maxOf(minStereo, 16_384) * 2)
                    .build()
                if (rec.state == AudioRecord.STATE_INITIALIZED) internalRec = rec else rec.release()
            }

            if (useMic) {
                val minMono = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val m = AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minMono, 8_192) * 2
                )
                if (m.state == AudioRecord.STATE_INITIALIZED) micRec = m else m.release()
            }

            if (internalRec == null && micRec == null) return false

            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
            audioEnc = aenc
            true
        } catch (e: Exception) {
            internalRec?.release(); internalRec = null
            micRec?.release(); micRec = null
            audioEnc?.release(); audioEnc = null
            false
        }
    }

    // ------------------------------------------------------------ threads
    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(true, enc.outputFormat)
                    i >= 0 -> {
                        val ob = enc.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            if (mode == MODE_RECORD && !muxStarted &&
                                !muxReady.await(3, TimeUnit.SECONDS)) forceStart()
                            writeSample(true, ob, info)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun audioLoop() {
        val enc = audioEnc ?: return
        val rec = internalRec
        val mic = micRec
        val buf = ShortArray(2048)          // 1024 frames estéreo
        val micBuf = ShortArray(1024)
        val info = MediaCodec.BufferInfo()
        var frames = 0L
        var startUs = -1L
        try {
            rec?.startRecording()
            mic?.startRecording()
            while (recording) {
                var n = 0
                if (rec != null) {
                    n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    if (mic != null) {
                        val want = n / 2
                        var got = 0
                        while (got < want && recording) {
                            val r = mic.read(micBuf, got, want - got)
                            if (r <= 0) break
                            got += r
                        }
                        for (k in 0 until want) {
                            val m = if (k < got) micBuf[k].toInt() else 0
                            buf[2 * k] = (buf[2 * k] + m).coerceIn(-32768, 32767).toShort()
                            buf[2 * k + 1] = (buf[2 * k + 1] + m).coerceIn(-32768, 32767).toShort()
                        }
                    }
                } else if (mic != null) {
                    var got = 0
                    while (got < micBuf.size && recording) {
                        val r = mic.read(micBuf, got, micBuf.size - got)
                        if (r <= 0) break
                        got += r
                    }
                    if (got <= 0) break
                    for (k in 0 until got) {
                        buf[2 * k] = micBuf[k]
                        buf[2 * k + 1] = micBuf[k]
                    }
                    n = got * 2
                } else {
                    break
                }
                if (startUs < 0) startUs = System.nanoTime() / 1000
                val pts = startUs + frames * 1_000_000L / SAMPLE_RATE
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buf, 0, n)
                    enc.queueInputBuffer(idx, 0, n * 2, pts, 0)
                }
                frames += n / 2
                drainAudio(enc, info, false)
            }
            try { rec?.stop() } catch (_: Exception) { }
            try { mic?.stop() } catch (_: Exception) { }

            // Fim de stream
            val pts = (if (startUs < 0) System.nanoTime() / 1000 else startUs) +
                frames * 1_000_000L / SAMPLE_RATE
            var tries = 0
            while (tries++ < 20) {
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
            }
            drainAudio(enc, info, true)
        } catch (_: Exception) { }
    }

    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, untilEos: Boolean) {
        var idleRounds = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(info, if (untilEos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(false, enc.outputFormat)
                i >= 0 -> {
                    val ob = enc.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0) writeSample(false, ob, info)
                    enc.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!untilEos || ++idleRounds > 100) return
                }
            }
        }
    }

    // -------------------------------------------------------------- muxer
    private fun onFormat(video: Boolean, f: MediaFormat) {
        if (mode == MODE_REPLAY) {
            if (video) videoFormat = f else audioFormat = f
            return
        }
        synchronized(muxLock) {
            val m = muxer ?: return
            if (video) videoTrack = m.addTrack(f) else audioTrack = m.addTrack(f)
            if (!muxStarted && videoTrack >= 0 && (!hasAudio || audioTrack >= 0)) {
                m.start(); muxStarted = true; muxReady.countDown()
            }
        }
    }

    /** Áudio não chegou a tempo: começa só com vídeo. */
    private fun forceStart() {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (!muxStarted && videoTrack >= 0) {
                hasAudio = false
                m.start(); muxStarted = true; muxReady.countDown()
            }
        }
    }

    private fun writeSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (mode == MODE_REPLAY) { bufferSample(video, buf, info); return }
        synchronized(muxLock) {
            if (!muxStarted) return
            if (baseUs < 0) baseUs = info.presentationTimeUs
            info.presentationTimeUs = maxOf(0L, info.presentationTimeUs - baseUs)
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            val track = if (video) videoTrack else audioTrack
            if (track < 0) return
            try { muxer?.writeSampleData(track, buf, info) } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------- replay
    private fun bufferSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        val arr = ByteArray(info.size)
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        buf.get(arr)
        val keepUs = (Prefs.replaySec(this) + 3) * 1_000_000L
        synchronized(ringLock) {
            ring.addLast(Sample(video, arr, info.presentationTimeUs, info.flags))
            while (true) {
                val first = ring.peekFirst() ?: break
                if (info.presentationTimeUs - first.ptsUs > keepUs) ring.removeFirst() else break
            }
        }
    }

    private fun saveReplay() {
        if (mode != MODE_REPLAY || !recording) return
        val vf = videoFormat
        if (vf == null) { toast("O replay ainda não tem dados. Aguarde um instante."); return }
        val af = audioFormat
        val snapshot: List<Sample> = synchronized(ringLock) { ring.toList() }
        val windowSec = Prefs.replaySec(this)
        Thread({
            var uri: Uri? = null
            var fd: ParcelFileDescriptor? = null
            var mux: MediaMuxer? = null
            try {
                val latest = snapshot.maxOfOrNull { it.ptsUs } ?: 0L
                val windowStart = latest - windowSec * 1_000_000L
                val keyFlag = MediaCodec.BUFFER_FLAG_KEY_FRAME
                val start = snapshot.firstOrNull {
                    it.video && (it.flags and keyFlag) != 0 && it.ptsUs >= windowStart
                }?.ptsUs ?: snapshot.firstOrNull {
                    it.video && (it.flags and keyFlag) != 0
                }?.ptsUs

                if (start == null) {
                    toast("O replay ainda não tem dados. Aguarde um instante.")
                } else {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "47Replay_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Recorder")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    fd = contentResolver.openFileDescriptor(uri!!, "rw")
                    mux = MediaMuxer(fd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    val vt = mux!!.addTrack(vf)
                    val at = if (af != null) mux!!.addTrack(af) else -1
                    mux!!.start()
                    val bi = MediaCodec.BufferInfo()
                    for (s in snapshot) {
                        if (s.ptsUs < start) continue
                        val track = if (s.video) vt else at
                        if (track < 0) continue
                        bi.set(0, s.data.size, s.ptsUs - start, s.flags)
                        mux!!.writeSampleData(track, ByteBuffer.wrap(s.data), bi)
                    }
                    mux!!.stop()
                    toast("Replay salvo em Movies/47 Recorder")
                }
            } catch (e: Exception) {
                toast("Falha ao salvar o replay")
            } finally {
                try { mux?.release() } catch (_: Exception) { }
                try { fd?.close() } catch (_: Exception) { }
                uri?.let {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    try { contentResolver.update(it, v, null, null) } catch (_: Exception) { }
                }
            }
        }, "47-replay-save").start()
    }

    // -------------------------------------------------------------- print
    private fun takeShot() {
        val rd = reader ?: return
        val disp = display ?: return
        if (shotBusy) return
        shotBusy = true
        val target: Surface? = inputSurface   // null no modo "só prints"
        main.post { menuRoot?.visibility = View.INVISIBLE }

        Thread({
            val box = arrayOfNulls<Image>(1)
            val latch = CountDownLatch(1)
            try {
                Thread.sleep(350)   // dá tempo do botão sumir da tela
                rd.setOnImageAvailableListener({ r ->
                    val img = r.acquireLatestImage()
                    if (img != null) {
                        if (box[0] == null) { box[0] = img; latch.countDown() } else img.close()
                    }
                }, main)
                disp.setSurface(rd.surface)
                latch.await(2, TimeUnit.SECONDS)
                disp.setSurface(target)
                rd.setOnImageAvailableListener(null, null)
                val img = box[0]
                if (img == null) toast("Não foi possível capturar a tela") else saveShot(img)
            } catch (e: Exception) {
                try { disp.setSurface(target) } catch (_: Exception) { }
                toast("Falha ao capturar a tela")
            } finally {
                shotBusy = false
                main.post { menuRoot?.visibility = View.VISIBLE }
            }
        }, "47-shot").start()
    }

    private fun saveShot(img: Image) {
        val w = img.width
        val h = img.height
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val padded = Bitmap.createBitmap(
            w + (rowStride - pixelStride * w) / pixelStride, h, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        img.close()
        val bmp = Bitmap.createBitmap(padded, 0, 0, w, h)

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "47Print_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/47 Recorder")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Não foi possível salvar o print"); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        toast("Print salvo em Pictures/47 Recorder")
    }

    // ------------------------------------------------------------ overlays
    private fun showOverlays() {
        if (Prefs.watermark(this)) showWatermark()
        if (Prefs.facecam(this) &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) showFaceCam()
        if (!(Prefs.clean(this) && mode != MODE_SHOT)) showMenu()
    }

    private fun attachDrag(
        target: View, windowView: View, params: WindowManager.LayoutParams, onClick: (() -> Unit)?
    ) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        target.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    try { wm.updateViewLayout(windowView, params) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    private fun showMenu() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val svc = this
        val metrics = resources.displayMetrics
        val sizePx = dp(Prefs.size(svc))
        val btnColor = Prefs.color(svc)
        val alphaV = Prefs.opacity(svc) / 100f
        val panelBg = Prefs.menuBg(svc)
        val panelTxt = Prefs.contrast(panelBg)
        val orbLabel = Prefs.orbText(svc)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(12)
        params.y = dp(200)

        val root = LinearLayout(svc)
        root.orientation = LinearLayout.VERTICAL

        val panel = LinearLayout(svc)
        panel.orientation = LinearLayout.VERTICAL
        panel.visibility = View.GONE
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        val panelShape = GradientDrawable()
        panelShape.cornerRadius = dp(22).toFloat()
        panelShape.setColor(panelBg)
        panel.background = panelShape

        val btn = TextView(svc)
        btn.text = orbLabel
        btn.gravity = Gravity.CENTER
        btn.textSize = Prefs.size(svc) / (if (orbLabel.length >= 3) 4.2f else 3.2f)
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.setTextColor(Prefs.contrast(btnColor))
        btn.background = Ui.orbDrawable(btnColor, Prefs.orbShape(svc), sizePx)
        btn.alpha = alphaV

        var expanded = false
        var shift = 0
        var xView: View? = null

        fun layoutRoot(panelFirst: Boolean) {
            root.removeAllViews()
            val bl = LinearLayout.LayoutParams(sizePx, sizePx)
            val pl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (panelFirst) {
                pl.bottomMargin = dp(8)
                root.addView(panel, pl)
                root.addView(btn, bl)
            } else {
                pl.topMargin = dp(8)
                root.addView(btn, bl)
                root.addView(panel, pl)
            }
        }

        fun collapse() {
            if (!expanded) return
            expanded = false
            panel.visibility = View.GONE
            layoutRoot(false)
            params.y += shift
            shift = 0
            try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        }

        fun expand() {
            if (expanded) return
            expanded = true
            val spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            panel.measure(spec, spec)
            val ph = panel.measuredHeight + dp(8)
            val above = params.y + sizePx / 2 > metrics.heightPixels / 2
            if (above) {
                shift = minOf(ph, params.y)
                params.y -= shift
            } else {
                shift = 0
            }
            layoutRoot(above)
            panel.visibility = View.VISIBLE
            try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        }

        fun closeAll() {
            try { stopService(Intent(svc, DrawService::class.java)) } catch (_: Exception) { }
            stopRecording()
        }

        fun addItem(iconStr: String, labelStr: String, action: () -> Unit) {
            val line = LinearLayout(svc)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(4), dp(4), dp(16), dp(4))

            val ic = TextView(svc)
            ic.text = iconStr
            ic.gravity = Gravity.CENTER
            ic.textSize = 17f
            ic.setTextColor(Prefs.contrast(btnColor))
            ic.background = Ui.orbDrawable(btnColor, 0, dp(44))
            line.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))

            val tv = TextView(svc)
            tv.text = labelStr
            tv.textSize = 15f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(panelTxt)
            val tl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            tl.leftMargin = dp(12)
            line.addView(tv, tl)

            line.setOnClickListener {
                collapse()
                action()
            }
            panel.addView(
                line,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        if (mode == MODE_REPLAY) addItem("💾", "Salvar replay") { saveReplay() }
        if (Prefs.showShot(svc)) addItem("📷", "Capturar") { takeShot() }
        if (Prefs.showDraw(svc)) {
            addItem("✏️", "Desenhar") {
                try {
                    svc.startForegroundService(
                        Intent(svc, DrawService::class.java).setAction(DrawService.ACTION_TOGGLE)
                    )
                } catch (_: Exception) {
                    toast("Não foi possível abrir o desenho agora")
                }
            }
        }
        addItem("■", "Parar") { stopRecording() }

        // ---- alvo "X" que aparece ao arrastar o botão
        fun hitX(): Boolean {
            val cx = params.x + sizePx / 2
            val cy = params.y + sizePx / 2
            val tx = metrics.widthPixels / 2
            val ty = metrics.heightPixels - dp(112)
            val dx = (cx - tx).toDouble()
            val dy = (cy - ty).toDouble()
            return Math.sqrt(dx * dx + dy * dy) < dp(80)
        }

        fun showX() {
            if (xView != null) return
            val v = TextView(svc)
            v.text = "✕"
            v.gravity = Gravity.CENTER
            v.textSize = 26f
            v.setTextColor(Color.WHITE)
            v.background = Ui.orbDrawable(0xE6B71C1C.toInt(), 0, dp(64))
            val xp = WindowManager.LayoutParams(
                dp(64), dp(64),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            xp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            xp.y = dp(80)
            try {
                wm.addView(v, xp)
                xView = v
            } catch (_: Exception) { }
        }

        fun hideX() {
            val v = xView
            if (v != null) {
                try { wm.removeView(v) } catch (_: Exception) { }
            }
            xView = null
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12)) {
                        moved = true
                        collapse()
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        showX()
                    } else if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
                        val near = hitX()
                        val xv = xView
                        if (xv != null) {
                            xv.scaleX = if (near) 1.35f else 1f
                            xv.scaleY = if (near) 1.35f else 1f
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val drop = hitX()
                        hideX()
                        if (drop) closeAll()
                    } else {
                        if (expanded) collapse() else expand()
                    }
                }
                MotionEvent.ACTION_CANCEL -> hideX()
            }
            true
        }

        layoutRoot(false)
        wm.addView(root, params)
        menuRoot = root
    }

    private fun showWatermark() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = Prefs.wmText(this@RecorderService)
            textSize = 14f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 1f, 1f, Color.BLACK)
            alpha = 0.85f
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val g = when (Prefs.wmPos(this)) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = g; x = dp(12); y = dp(48) }
        wm.addView(tv, p)
        wmView = tv
    }

    private fun showFaceCam() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = dp(120)
        val tv = TextureView(this).apply {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
        }
        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - dp(16)
            y = dp(120)
        }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                // espelha (selfie) e corrige a proporção 3:4 -> quadrado
                tv.setTransform(Matrix().apply { setScale(-1f, 4f / 3f, size / 2f, size / 2f) })
                openCamera(st)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        attachDrag(tv, tv, p, null)
        wm.addView(tv, p)
        faceView = tv
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun openCamera(st: SurfaceTexture) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_FRONT
            } ?: return
            st.setDefaultBufferSize(640, 480)
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    if (faceView == null) { cam.close(); return }
                    camDevice = cam
                    try {
                        val surf = Surface(st)
                        cam.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                camSession = s
                                try {
                                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                        .apply { addTarget(surf) }.build()
                                    s.setRepeatingRequest(req, null, null)
                                } catch (_: Exception) { }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) {}
                        }, null)
                    } catch (_: Exception) { }
                }
                override fun onDisconnected(cam: CameraDevice) { cam.close() }
                override fun onError(cam: CameraDevice, error: Int) { cam.close() }
            }, null)
        } catch (_: Exception) { }
    }

    private fun removeOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (v in listOf(menuRoot, faceView, wmView)) {
            if (v != null) { try { wm.removeView(v) } catch (_: Exception) { } }
        }
        menuRoot = null; faceView = null; wmView = null
        try { camSession?.close() } catch (_: Exception) { }
        try { camDevice?.close() } catch (_: Exception) { }
        camSession = null; camDevice = null
    }

    // --------------------------------------------------------------- parar
    private fun stopRecording() {
        if (!recording) return
        recording = false
        finishing = true
        removeOverlays()
        Thread({ finalizeRecording() }, "47-finalize").start()
    }

    private fun finalizeRecording() {
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { videoEnc?.signalEndOfInputStream() } catch (_: Exception) { }
        try { videoThread?.join(5000) } catch (_: Exception) { }
        try { audioThread?.join(5000) } catch (_: Exception) { }

        try { videoEnc?.stop() } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.stop() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { inputSurface?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        videoEnc = null; audioEnc = null; inputSurface = null; reader = null
        internalRec = null; micRec = null

        synchronized(muxLock) {
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            muxer = null
        }
        synchronized(ringLock) { ring.clear() }
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        try { pfd?.close() } catch (_: Exception) { }
        pfd = null

        videoUri?.let {
            val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(it, v, null, null)
        }

        val msg = when (mode) {
            MODE_REPLAY -> "Replay encerrado"
            MODE_SHOT -> "Menu de prints fechado"
            else -> "Vídeo salvo em Movies/47 Recorder"
        }
        main.post {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cleanupAfterFailure() {
        removeOverlays()
        try { display?.release() } catch (_: Exception) { }
        try { videoEnc?.release() } catch (_: Exception) { }
        try { audioEnc?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { internalRec?.release() } catch (_: Exception) { }
        try { micRec?.release() } catch (_: Exception) { }
        try { muxer?.release() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        try { pfd?.close() } catch (_: Exception) { }
        videoUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) { } }
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        super.onDestroy()
    }
}
