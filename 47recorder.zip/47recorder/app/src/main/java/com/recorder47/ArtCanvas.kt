package com.recorder47

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Tela de desenho do 47 Art Mode.
 *
 * Gestos: um dedo desenha; dois dedos dão zoom, movem e giram a tela (o traço em andamento é
 * descartado, então nunca sobra um risco por engano); toque rápido com dois dedos desfaz e com
 * três dedos refaz. Na ferramenta Transformar, dois dedos movem, giram e escalam a camada.
 */
class ArtCanvas(ctx: Context) : View(ctx) {

    class Layer(var bmp: Bitmap, var visible: Boolean, var name: String, val uid: Int) {
        var opacity = 255
        var blend = 0
        var alphaLock = false
        var clipping = false   // Clipping Mask (corta pela camada de baixo)
        var locked = false
        var dirty = true
    }

    class SaveLayer(
        val uid: Int, val name: String, val visible: Boolean,
        val opacity: Int, val blend: Int, val alphaLock: Boolean,
        val clipping: Boolean, val locked: Boolean, val bmpCopy: Bitmap?
    )

    private class Snap(val layer: Layer, val bmp: Bitmap)

    companion object {
        const val T_PENCIL = 0
        const val T_PEN = 1
        const val T_BRUSH = 2
        const val T_AIR = 3
        const val T_MARKER = 4
        const val T_ERASER = 5
        const val T_FILL = 6
        const val T_PICK = 7
        const val T_LINE = 8
        const val T_RECT = 9
        const val T_OVAL = 10
        const val T_TRANSFORM = 11
        const val T_HAND = 12
        const val T_SPRAY = 13
        const val T_CHALK = 14
        const val T_WATER = 15
        const val T_SMUDGE = 16
        const val T_GRADIENT = 17
        const val T_TEXT = 18
        const val T_SEL_RECT = 19
        const val T_SEL_LASSO = 20
        const val T_BLUR = 21
        const val T_MAGIC = 22
        const val T_LIQUIFY = 23

        val BLEND_NAMES = arrayOf(
            "Normal", "Multiplicar", "Tela", "Sobrepor", "Escurecer", "Clarear", "Somar",
            "Soft Light", "Hard Light", "Diferença", "Exclusão", "Cor Dodge", "Cor Burn"
        )
        private val BLEND_MODES: Array<PorterDuff.Mode?> = arrayOf(
            null, PorterDuff.Mode.MULTIPLY, PorterDuff.Mode.SCREEN, PorterDuff.Mode.OVERLAY,
            PorterDuff.Mode.DARKEN, PorterDuff.Mode.LIGHTEN, PorterDuff.Mode.ADD,
            PorterDuff.Mode.OVERLAY, // Soft Light approx
            PorterDuff.Mode.OVERLAY, // Hard Light approx
            PorterDuff.Mode.XOR,     // Diferença approx
            PorterDuff.Mode.XOR,     // Exclusão approx
            PorterDuff.Mode.SCREEN,  // Color Dodge approx
            PorterDuff.Mode.MULTIPLY // Color Burn approx
        )
        const val MAX_LAYERS = 32
    }

    val layers = ArrayList<Layer>()
    var current = 0
    var docW = 1080
    var docH = 1350
    var bgColor: Int = Color.WHITE
    var color: Int = Color.BLACK
    var brushSize = 12f
    var opacity = 255
    var stabilizer = 0
    /** 0 = borda bem suave, 100 = borda dura (sem blur). */
    var hardness = 70
    /** Fluxo do traço 1–100 (alpha por passagem). */
    var flow = 100
    /** Espaçamento dos pontos do spray/giz em % do tamanho do pincel. */
    var spacing = 25
    /** Usa pressão da stylus quando disponível. */
    var pressureOn = true
    var symmetry = 0          // 0 off, 1 espelho esquerda/direita, 2 cima/baixo, 3 os dois
    var rotateGesture = true
    var padLeft = 0f
    var padTop = 0f
    var padRight = 0f
    var padBottom = 0f

    /** 0 off, 1 grade, 2 terços, 3 perspectiva, 4 isométrica */
    var guideMode: Int = 0
        set(v) {
            field = v
            invalidate()
        }

    var tool: Int = T_PENCIL
        set(v) {
            if (field == T_TRANSFORM && v != T_TRANSFORM && transforming) applyTransform()
            field = v
        }

    var transforming: Boolean = false
        private set

    var onPick: ((Int) -> Unit)? = null
    var onHistoryChanged: (() -> Unit)? = null
    var onCommit: (() -> Unit)? = null
    var onTransformChanged: (() -> Unit)? = null
    var onSelectionChanged: (() -> Unit)? = null
    var onViewChanged: (() -> Unit)? = null
    var onTextRequest: ((Float, Float) -> Unit)? = null

    private val m = Matrix()
    private val inv = Matrix()
    private val tMatrix = Matrix()
    private val vals = FloatArray(9)
    private var fitted = false
    private var layerCounter = 1
    private var uidCounter = 0

    private var strokeBmp: Bitmap? = null
    private var strokeCanvas: Canvas? = null
    private var flatBmp: Bitmap? = null

    private val undoList = ArrayList<Snap>()
    private val redoList = ArrayList<Snap>()
    private var maxUndo = 8
    private var pendingSnap: Snap? = null

    private val xfers: Array<PorterDuffXfermode?> = Array(BLEND_NAMES.size) { i ->
        val md = BLEND_MODES[i]
        if (md == null) null else PorterDuffXfermode(md)
    }
    private val lockXfer = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)

    private val layerPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val previewPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val checkerPaint = Paint()
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val smudgePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val docRect = RectF()
    private val rnd = java.util.Random()

    // seleção
    private var selPath: Path? = null
    private var selecting = false
    private val selDraft = Path()
    private var selStartX = 0f
    private var selStartY = 0f
    private var selEndX = 0f
    private var selEndY = 0f

    // estado do toque
    private var gesture = false
    private var stroking = false
    private var erasing = false
    private var smudging = false
    private var blurring = false
    private var liquifying = false
    private var shaping = false
    private var filling = false
    private var gradienting = false
    private var textPending = false
    private var stylus = false
    private var smX = 0f
    private var smY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var curW = 12f
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var fillX = 0f
    private var fillY = 0f
    private var handX = 0f
    private var handY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f
    private var lastAngle = 0f
    private var tapT0 = 0L
    private var maxPtr = 1
    private var gestMoved = false
    private var gestTravel = 0f
    private var smudgeBmp: Bitmap? = null

    // transformar camada
    private val tp = FloatArray(4)
    private val tcur = FloatArray(4)
    private var tCount = 0

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val cur = currentScale()
            val target = (cur * detector.scaleFactor).coerceIn(0.1f, 16f)
            val f = target / cur
            if (Math.abs(detector.scaleFactor - 1f) > 0.015f) gestMoved = true
            m.postScale(f, f, detector.focusX, detector.focusY)
            invalidate()
            onViewChanged?.invoke()
            return true
        }
    })

    init {
        scaleDet.isQuickScaleEnabled = false
        val cb = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        val cc = Canvas(cb)
        cc.drawColor(0xFFFFFFFF.toInt())
        val p = Paint()
        p.color = 0xFFD0D0D0.toInt()
        cc.drawRect(0f, 0f, 16f, 16f, p)
        cc.drawRect(16f, 16f, 32f, 32f, p)
        checkerPaint.shader = BitmapShader(cb, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        borderPaint.style = Paint.Style.STROKE
        borderPaint.color = 0xFF555555.toInt()
        borderPaint.strokeWidth = 2f
        gridPaint.style = Paint.Style.STROKE
    }

    // ------------------------------------------------------------ documento
    fun newDoc(w: Int, h: Int, bg: Int) {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.eraseColor(bg)
        val list = ArrayList<Layer>()
        list.add(Layer(b, true, "Fundo", 1))
        setDoc(w, h, bg, list, 0)
    }

    /** Redimensiona o documento mantendo o conteúdo (centralizado ou esticado). */
    fun resizeCanvas(newW: Int, newH: Int, stretch: Boolean = false): Boolean {
        val nw = newW.coerceIn(64, 4096)
        val nh = newH.coerceIn(64, 4096)
        if (nw == docW && nh == docH) return true
        try {
            val list = ArrayList<Layer>()
            for (l in layers) {
                val nb = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
                val c = Canvas(nb)
                if (stretch) {
                    c.drawBitmap(l.bmp, null, RectF(0f, 0f, nw.toFloat(), nh.toFloat()), null)
                } else {
                    val ox = (nw - l.bmp.width) / 2f
                    val oy = (nh - l.bmp.height) / 2f
                    c.drawBitmap(l.bmp, ox, oy, null)
                }
                val nl = Layer(nb, l.visible, l.name, l.uid)
                nl.opacity = l.opacity
                nl.blend = l.blend
                nl.alphaLock = l.alphaLock
                nl.clipping = l.clipping
                nl.locked = l.locked
                list.add(nl)
            }
            val cur = current
            setDoc(nw, nh, bgColor, list, cur)
            return true
        } catch (_: OutOfMemoryError) {
            return false
        }
    }

    fun setDoc(w: Int, h: Int, bg: Int, list: List<Layer>, cur: Int) {
        for (l in layers) l.bmp.recycle()
        layers.clear()
        for (s in undoList) s.bmp.recycle()
        for (s in redoList) s.bmp.recycle()
        undoList.clear()
        redoList.clear()
        pendingSnap = null
        transforming = false
        selPath = null
        selecting = false
        tMatrix.reset()
        strokeBmp?.recycle()
        flatBmp?.recycle()
        flatBmp = null
        smudgeBmp?.recycle()
        smudgeBmp = null
        docW = w
        docH = h
        bgColor = bg
        layers.addAll(list)
        current = cur.coerceIn(0, maxOf(0, layers.size - 1))
        var maxUid = 0
        for (l in layers) if (l.uid > maxUid) maxUid = l.uid
        uidCounter = maxUid
        layerCounter = layers.size
        val sb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        strokeBmp = sb
        strokeCanvas = Canvas(sb)
        maxUndo = (50_000_000L / (w.toLong() * h * 4L)).toInt().coerceIn(3, 10)
        fitted = false
        if (width > 0) fit()
        invalidate()
        onHistoryChanged?.invoke()
        onSelectionChanged?.invoke()
    }

    private fun nextUid(): Int {
        uidCounter++
        return uidCounter
    }

    // ------------------------------------------------------------------ vista
    private fun currentScale(): Float {
        m.getValues(vals)
        return Math.hypot(vals[Matrix.MSCALE_X].toDouble(), vals[Matrix.MSKEW_Y].toDouble()).toFloat()
    }

    fun zoomPercent(): Int = (currentScale() * 100f).toInt()

    fun isFlipped(): Boolean {
        m.getValues(vals)
        val det = vals[Matrix.MSCALE_X] * vals[Matrix.MSCALE_Y] - vals[Matrix.MSKEW_X] * vals[Matrix.MSKEW_Y]
        return det < 0f
    }

    fun viewAngle(): Int {
        if (isFlipped()) return 0
        m.getValues(vals)
        return Math.round(Math.toDegrees(Math.atan2(vals[Matrix.MSKEW_Y].toDouble(), vals[Matrix.MSCALE_X].toDouble())).toFloat())
    }

    fun setPads(l: Float, t: Float, r: Float, b: Float) {
        padLeft = l
        padTop = t
        padRight = r
        padBottom = b
        fitted = false
        if (width > 0) fit()
        invalidate()
    }

    private fun fit() {
        if (width == 0 || height == 0) return
        val availW = width - padLeft - padRight
        val availH = height - padTop - padBottom
        val scale = minOf(availW * 0.94f / docW, availH * 0.94f / docH)
        m.reset()
        m.postScale(scale, scale)
        m.postTranslate(padLeft + (availW - docW * scale) / 2f, padTop + (availH - docH * scale) / 2f)
        fitted = true
        onViewChanged?.invoke()
    }

    fun resetView() {
        fit()
        invalidate()
    }

    fun flipView() {
        m.postScale(-1f, 1f, width / 2f, height / 2f)
        invalidate()
        onViewChanged?.invoke()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fitted = false
        fit()          // girou a tela do aparelho: reajusta o desenho ao novo tamanho
    }

    private fun toDoc(x: Float, y: Float): FloatArray {
        m.invert(inv)
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return p
    }

    private fun applyLayerPaint(l: Layer, p: Paint) {
        p.alpha = l.opacity.coerceIn(0, 255)
        p.xfermode = xfers[l.blend.coerceIn(0, BLEND_NAMES.size - 1)]
    }

    private fun applyClip(c: Canvas) {
        val sp = selPath
        if (sp != null) c.clipPath(sp)
    }

    // ---------------------------------------------------------------- toque
    private fun midX(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getX(i)
        return s / e.pointerCount
    }

    private fun midY(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getY(i)
        return s / e.pointerCount
    }

    private fun angleOf(e: MotionEvent): Float {
        if (e.pointerCount < 2) return lastAngle
        val dx = (e.getX(1) - e.getX(0)).toDouble()
        val dy = (e.getY(1) - e.getY(0)).toDouble()
        return Math.toDegrees(Math.atan2(dy, dx)).toFloat()
    }

    private fun updateMid(e: MotionEvent, skip: Int) {
        var sumX = 0f
        var sumY = 0f
        var n = 0
        var first = -1
        var second = -1
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            sumX += e.getX(i)
            sumY += e.getY(i)
            n++
            if (first < 0) first = i else if (second < 0) second = i
        }
        if (n > 0) {
            lastMidX = sumX / n
            lastMidY = sumY / n
        }
        if (first >= 0 && second >= 0) {
            val dx = (e.getX(second) - e.getX(first)).toDouble()
            val dy = (e.getY(second) - e.getY(first)).toDouble()
            lastAngle = Math.toDegrees(Math.atan2(dy, dx)).toFloat()
        }
    }

    /** Se a tela ficou quase reta depois do gesto, encaixa em 0 grau. */
    private fun snapRotation() {
        if (isFlipped()) return
        val a = viewAngle()
        if (a != 0 && Math.abs(a) <= 3) {
            m.postRotate(-a.toFloat(), width / 2f, height / 2f)
            invalidate()
            onViewChanged?.invoke()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (layers.isEmpty()) return true
        if (tool == T_TRANSFORM) return transformTouch(e)
        scaleDet.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gesture = false
                gestMoved = false
                gestTravel = 0f
                maxPtr = 1
                tapT0 = e.eventTime
                stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                beginTouch(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!gesture) {
                    cancelTouch()
                    gesture = true
                }
                if (e.pointerCount > maxPtr) maxPtr = e.pointerCount
                updateMid(e, -1)
            }
            MotionEvent.ACTION_MOVE -> {
                if (gesture) {
                    if (e.pointerCount >= 2) {
                        val mx = midX(e)
                        val my = midY(e)
                        val ddx = mx - lastMidX
                        val ddy = my - lastMidY
                        gestTravel += Math.abs(ddx) + Math.abs(ddy)
                        if (gestTravel > 40f) gestMoved = true
                        m.postTranslate(ddx, ddy)
                        lastMidX = mx
                        lastMidY = my
                        if (rotateGesture) {
                            val ang = angleOf(e)
                            var d = ang - lastAngle
                            if (d > 180f) d -= 360f
                            if (d < -180f) d += 360f
                            if (Math.abs(d) < 45f) {
                                m.postRotate(d, mx, my)
                                if (Math.abs(d) > 1.5f) gestMoved = true
                            }
                            lastAngle = ang
                        }
                        invalidate()
                        onViewChanged?.invoke()
                    }
                } else {
                    moveTouch(e.x, e.y, e.pressure)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                updateMid(e, e.actionIndex)
            }
            MotionEvent.ACTION_UP -> {
                if (gesture) {
                    if (!gestMoved && e.eventTime - tapT0 < 350L) {
                        if (maxPtr == 2) undo() else if (maxPtr >= 3) redo()
                    }
                    snapRotation()
                } else {
                    endTouch(e.x, e.y)
                }
                gesture = false
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelTouch()
                gesture = false
            }
        }
        return true
    }

    private fun beginTouch(x: Float, y: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER, T_SPRAY, T_CHALK, T_WATER -> startStroke(p[0], p[1])
            T_ERASER -> startErase(p[0], p[1])
            T_SMUDGE -> startSmudge(p[0], p[1])
            T_BLUR -> startBlur(p[0], p[1])
            T_LIQUIFY -> startLiquify(p[0], p[1])
            T_MAGIC -> {
                magicSelect(p[0], p[1])
            }
            T_FILL -> {
                fillX = p[0]
                fillY = p[1]
                filling = true
            }
            T_PICK -> pick(p[0], p[1])
            T_LINE, T_RECT, T_OVAL -> {
                sx = p[0]
                sy = p[1]
                ex = sx
                ey = sy
                shaping = true
            }
            T_GRADIENT -> {
                sx = p[0]
                sy = p[1]
                ex = sx
                ey = sy
                gradienting = true
            }
            T_TEXT -> textPending = true
            T_SEL_RECT -> {
                selecting = true
                selStartX = p[0]
                selStartY = p[1]
                selEndX = p[0]
                selEndY = p[1]
            }
            T_SEL_LASSO -> {
                selecting = true
                selDraft.reset()
                selDraft.moveTo(p[0], p[1])
            }
            T_HAND -> {
                handX = x
                handY = y
            }
        }
    }

    private fun moveTouch(x: Float, y: Float, pressure: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER, T_SPRAY, T_CHALK, T_WATER ->
                if (stroking) continueStroke(p[0], p[1], pressure)
            T_ERASER -> if (erasing) continueErase(p[0], p[1])
            T_SMUDGE -> if (smudging) continueSmudge(p[0], p[1])
            T_BLUR -> if (blurring) continueBlur(p[0], p[1])
            T_LIQUIFY -> if (liquifying) continueLiquify(p[0], p[1])
            T_FILL -> {
                fillX = p[0]
                fillY = p[1]
            }
            T_PICK -> pick(p[0], p[1])
            T_LINE, T_RECT, T_OVAL -> if (shaping) {
                ex = p[0]
                ey = p[1]
                invalidate()
            }
            T_GRADIENT -> if (gradienting) {
                ex = p[0]
                ey = p[1]
                invalidate()
            }
            T_TEXT -> {
                textPending = false
            }
            T_SEL_RECT -> if (selecting) {
                selEndX = p[0]
                selEndY = p[1]
                invalidate()
            }
            T_SEL_LASSO -> if (selecting) {
                selDraft.lineTo(p[0], p[1])
                invalidate()
            }
            T_HAND -> {
                m.postTranslate(x - handX, y - handY)
                handX = x
                handY = y
                invalidate()
                onViewChanged?.invoke()
            }
        }
    }

    private fun endTouch(x: Float, y: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER, T_SPRAY, T_CHALK, T_WATER -> if (stroking) {
                flushStroke(p[0], p[1])
                finishStroke()
            }
            T_ERASER -> if (erasing) {
                flushErase(p[0], p[1])
                finishErase()
            }
            T_SMUDGE -> if (smudging) finishSmudge()
            T_BLUR -> if (blurring) finishBlur()
            T_LIQUIFY -> if (liquifying) finishLiquify()
            T_FILL -> if (filling) {
                filling = false
                fillAt(p[0], p[1])
            }
            T_LINE, T_RECT, T_OVAL -> if (shaping) {
                ex = p[0]
                ey = p[1]
                commitShape()
            }
            T_GRADIENT -> if (gradienting) {
                ex = p[0]
                ey = p[1]
                commitGradient()
            }
            T_TEXT -> if (textPending) {
                textPending = false
                onTextRequest?.invoke(p[0], p[1])
            }
            T_SEL_RECT -> if (selecting) {
                selEndX = p[0]
                selEndY = p[1]
                finishRectSelection()
            }
            T_SEL_LASSO -> if (selecting) {
                selDraft.close()
                finishLassoSelection()
            }
        }
    }

    /** Um segundo dedo apareceu: descarta o que estava em andamento sem sujar o desenho. */
    private fun cancelTouch() {
        if (stroking) {
            stroking = false
            strokeCanvas?.drawColor(0, PorterDuff.Mode.CLEAR)
        }
        if (erasing || smudging || blurring || liquifying) {
            erasing = false
            smudging = false
            blurring = false
            liquifying = false
            val s = pendingSnap
            if (s != null) {
                val old = s.layer.bmp
                s.layer.bmp = s.bmp
                old.recycle()
            }
            pendingSnap = null
            smudgeBmp?.recycle()
            smudgeBmp = null
        }
        shaping = false
        filling = false
        gradienting = false
        textPending = false
        selecting = false
        invalidate()
    }

    // ------------------------------------------------- transformar camada
    private fun tCollect(e: MotionEvent, skip: Int, out: FloatArray): Int {
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            if (n >= 2) break
            val d = toDoc(e.getX(i), e.getY(i))
            out[n * 2] = d[0]
            out[n * 2 + 1] = d[1]
            n++
        }
        return n
    }

    private fun transformTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                tCount = tCollect(e, -1, tp)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                tCount = tCollect(e, e.actionIndex, tp)
            }
            MotionEvent.ACTION_MOVE -> tMove(e)
        }
        return true
    }

    private fun tMove(e: MotionEvent) {
        val n = tCollect(e, -1, tcur)
        if (n == 0 || n != tCount) {
            tCount = tCollect(e, -1, tp)
            return
        }
        if (n == 1) {
            tMatrix.postTranslate(tcur[0] - tp[0], tcur[1] - tp[1])
        } else {
            val pdx = tp[2] - tp[0]
            val pdy = tp[3] - tp[1]
            val cdx = tcur[2] - tcur[0]
            val cdy = tcur[3] - tcur[1]
            val pd = Math.hypot(pdx.toDouble(), pdy.toDouble()).toFloat()
            val cd = Math.hypot(cdx.toDouble(), cdy.toDouble()).toFloat()
            if (pd > 1f && cd > 1f) {
                val s = cd / pd
                var deg = Math.toDegrees(
                    Math.atan2(cdy.toDouble(), cdx.toDouble()) - Math.atan2(pdy.toDouble(), pdx.toDouble())
                ).toFloat()
                if (deg > 180f) deg -= 360f
                if (deg < -180f) deg += 360f
                val pmx = (tp[0] + tp[2]) / 2f
                val pmy = (tp[1] + tp[3]) / 2f
                val cmx = (tcur[0] + tcur[2]) / 2f
                val cmy = (tcur[1] + tcur[3]) / 2f
                val t = Matrix()
                t.postTranslate(-pmx, -pmy)
                t.postScale(s, s)
                t.postRotate(deg)
                t.postTranslate(cmx, cmy)
                tMatrix.postConcat(t)
            }
        }
        for (i in 0 until 4) tp[i] = tcur[i]
        if (!transforming) {
            transforming = true
            onTransformChanged?.invoke()
        }
        invalidate()
    }

    fun applyTransform() {
        if (!transforming) return
        transforming = false
        if (current >= 0 && current < layers.size) {
            pushUndo()
            val l = layers[current]
            val nb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(l.bmp, tMatrix, Paint(Paint.FILTER_BITMAP_FLAG))
            l.bmp.recycle()
            l.bmp = nb
            l.dirty = true
        }
        tMatrix.reset()
        invalidate()
        onTransformChanged?.invoke()
        onCommit?.invoke()
    }

    fun cancelTransform() {
        if (!transforming) return
        transforming = false
        tMatrix.reset()
        invalidate()
        onTransformChanged?.invoke()
    }

    // ---------------------------------------------------------------- pincéis
    private fun brushPaint(width: Float): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = if (tool == T_MARKER) Paint.Cap.SQUARE else Paint.Cap.ROUND
        p.color = color or 0xFF000000.toInt()
        p.strokeWidth = width
        // Dureza: 100 = sem blur; 0 = bem suave
        val soft = (100 - hardness).coerceIn(0, 100) / 100f
        when (tool) {
            T_BRUSH -> {
                if (soft > 0.02f) p.maskFilter = BlurMaskFilter(maxOf(0.5f, width * 0.12f * soft * 2f), BlurMaskFilter.Blur.NORMAL)
            }
            T_AIR -> {
                p.strokeWidth = width * 1.6f
                p.maskFilter = BlurMaskFilter(maxOf(1f, width * (0.35f + soft * 0.55f)), BlurMaskFilter.Blur.NORMAL)
            }
            T_WATER -> {
                p.strokeWidth = width * 1.3f
                p.maskFilter = BlurMaskFilter(maxOf(1f, width * (0.25f + soft * 0.45f)), BlurMaskFilter.Blur.NORMAL)
            }
            T_PENCIL, T_PEN -> {
                if (soft > 0.35f) p.maskFilter = BlurMaskFilter(maxOf(0.4f, width * 0.08f * soft), BlurMaskFilter.Blur.NORMAL)
            }
            else -> {
                if (soft > 0.5f) p.maskFilter = BlurMaskFilter(maxOf(0.5f, width * 0.1f * soft), BlurMaskFilter.Blur.NORMAL)
            }
        }
        return p
    }

    private fun erasePaint(width: Float): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = width
        if (current == 0 && Color.alpha(bgColor) != 0) {
            p.color = bgColor
        } else {
            p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        return p
    }

    private fun commitAlpha(): Int {
        val f = (flow.coerceIn(1, 100) / 100f)
        val base = when (tool) {
            T_MARKER -> opacity * 0.55f
            T_WATER -> opacity * 0.45f
            T_AIR -> opacity * 0.7f
            else -> opacity.toFloat()
        }
        return (base * f).toInt().coerceIn(1, 255)
    }

    private fun mirrored(
        c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float,
        op: (Canvas, Float, Float, Float, Float) -> Unit
    ) {
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        op(c, x0, y0, x1, y1)
        if (symmetry == 1 || symmetry == 3) op(c, fw - x0, y0, fw - x1, y1)
        if (symmetry == 2 || symmetry == 3) op(c, x0, fh - y0, x1, fh - y1)
        if (symmetry == 3) op(c, fw - x0, fh - y0, fw - x1, fh - y1)
    }

    /** Desenha o segmento e os espelhos (simetria). */
    private fun drawSegment(c: Canvas, p: Paint, x0: Float, y0: Float, x1: Float, y1: Float) {
        c.drawLine(x0, y0, x1, y1, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawLine(fw - x0, y0, fw - x1, y1, p)
        if (symmetry == 2 || symmetry == 3) c.drawLine(x0, fh - y0, x1, fh - y1, p)
        if (symmetry == 3) c.drawLine(fw - x0, fh - y0, fw - x1, fh - y1, p)
    }

    private fun drawDot(c: Canvas, p: Paint, x: Float, y: Float) {
        c.drawPoint(x, y, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawPoint(fw - x, y, p)
        if (symmetry == 2 || symmetry == 3) c.drawPoint(x, fh - y, p)
        if (symmetry == 3) c.drawPoint(fw - x, fh - y, p)
    }

    private fun sprayOne(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = color or 0xFF000000.toInt()
        val r = maxOf(2f, brushSize / 2f)
        val dx = x1 - x0
        val dy = y1 - y0
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        val stepFactor = (spacing.coerceIn(5, 80) / 100f)
        val steps = maxOf(1, (dist / maxOf(2f, r * stepFactor)).toInt())
        val n = maxOf(4, (r * 0.9f).toInt())
        for (s in 0..steps) {
            val t = s.toFloat() / steps
            val cx = x0 + dx * t
            val cy = y0 + dy * t
            for (i in 0 until n) {
                val a = rnd.nextFloat() * 6.2831855f
                val rr = r * Math.sqrt(rnd.nextDouble()).toFloat()
                val px = cx + Math.cos(a.toDouble()).toFloat() * rr
                val py = cy + Math.sin(a.toDouble()).toFloat() * rr
                c.drawCircle(px, py, 1.2f, p)
            }
        }
    }

    private fun chalkOne(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = color or 0xFF000000.toInt()
        for (i in 0 until 7) {
            val ox = (rnd.nextFloat() - 0.5f) * brushSize
            val oy = (rnd.nextFloat() - 0.5f) * brushSize
            p.strokeWidth = 1f + rnd.nextFloat() * 2.5f
            p.alpha = 90 + rnd.nextInt(166)
            c.drawLine(x0 + ox, y0 + oy, x1 + ox, y1 + oy, p)
        }
    }

    private fun strokeSeg(c: Canvas, w: Float, x0: Float, y0: Float, x1: Float, y1: Float) {
        when (tool) {
            T_SPRAY -> mirrored(c, x0, y0, x1, y1) { cc, a, b, d, f -> sprayOne(cc, a, b, d, f) }
            T_CHALK -> mirrored(c, x0, y0, x1, y1) { cc, a, b, d, f -> chalkOne(cc, a, b, d, f) }
            else -> drawSegment(c, brushPaint(w), x0, y0, x1, y1)
        }
    }

    private fun smoothK(): Float = 1f / (1f + stabilizer * 1.2f)

    private fun startStroke(x: Float, y: Float) {
        val c = strokeCanvas ?: return
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        stroking = true
        smX = x
        smY = y
        lastX = x
        lastY = y
        curW = if (tool == T_PEN) brushSize * 0.6f else brushSize
        if (tool == T_SPRAY || tool == T_CHALK) {
            strokeSeg(c, curW, x, y, x + 0.01f, y)
        } else {
            drawDot(c, brushPaint(curW), x, y)
        }
        invalidate()
    }

    private fun continueStroke(x: Float, y: Float, pressure: Float) {
        val c = strokeCanvas ?: return
        val k = smoothK()
        smX += (x - smX) * k
        smY += (y - smY) * k
        val dx = smX - lastX
        val dy = smY - lastY
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (dist < 0.8f) return
        var w = brushSize
        if (tool == T_PEN || (pressureOn && stylus)) {
            val target = if (stylus && pressureOn) {
                brushSize * (0.25f + 0.9f * pressure.coerceIn(0f, 1f))
            } else if (tool == T_PEN) {
                brushSize * (1.15f - minOf(dist / 40f, 0.75f))
            }
            curW += (target - curW) * 0.3f
            w = curW
        }
        strokeSeg(c, w, lastX, lastY, smX, smY)
        lastX = smX
        lastY = smY
        invalidate()
    }

    private fun flushStroke(x: Float, y: Float) {
        val c = strokeCanvas ?: return
        val w = if (tool == T_PEN) curW else brushSize
        strokeSeg(c, w, lastX, lastY, x, y)
        lastX = x
        lastY = y
    }

    private fun finishStroke() {
        stroking = false
        val sb = strokeBmp ?: return
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        previewPaint.alpha = commitAlpha()
        previewPaint.xfermode = if (l.alphaLock) lockXfer else null
        val c = Canvas(l.bmp)
        applyClip(c)
        c.drawBitmap(sb, 0f, 0f, previewPaint)
        previewPaint.xfermode = null
        l.dirty = true
        strokeCanvas?.drawColor(0, PorterDuff.Mode.CLEAR)
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- borracha
    private fun startErase(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        pendingSnap = Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true))
        erasing = true
        smX = x
        smY = y
        lastX = x
        lastY = y
        val c = Canvas(l.bmp)
        applyClip(c)
        val p = erasePaint(brushSize)
        c.drawPoint(x, y, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawPoint(fw - x, y, p)
        if (symmetry == 2 || symmetry == 3) c.drawPoint(x, fh - y, p)
        if (symmetry == 3) c.drawPoint(fw - x, fh - y, p)
        invalidate()
    }

    private fun continueErase(x: Float, y: Float) {
        val l = layers[current]
        val k = smoothK()
        smX += (x - smX) * k
        smY += (y - smY) * k
        val dx = smX - lastX
        val dy = smY - lastY
        if (dx * dx + dy * dy < 0.6f) return
        val c = Canvas(l.bmp)
        applyClip(c)
        drawSegment(c, erasePaint(brushSize), lastX, lastY, smX, smY)
        lastX = smX
        lastY = smY
        invalidate()
    }

    private fun flushErase(x: Float, y: Float) {
        val l = layers[current]
        val c = Canvas(l.bmp)
        applyClip(c)
        drawSegment(c, erasePaint(brushSize), lastX, lastY, x, y)
    }

    private fun finishErase() {
        erasing = false
        val s = pendingSnap
        pendingSnap = null
        if (s != null) {
            s.layer.dirty = true
            addUndo(s)
        }
        invalidate()
        onCommit?.invoke()
    }

    // ----------------------------------------------------------------- borrar
    private fun grabPatch(l: Layer, x: Float, y: Float): Bitmap {
        val r = maxOf(4, (brushSize / 2f).toInt())
        val size = r * 2
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawBitmap(l.bmp, -(x - r), -(y - r), null)
        return b
    }

    private fun startSmudge(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        pendingSnap = Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true))
        smudging = true
        lastX = x
        lastY = y
        smudgeBmp?.recycle()
        smudgeBmp = grabPatch(l, x, y)
    }

    private fun continueSmudge(x: Float, y: Float) {
        val l = layers[current]
        val patch = smudgeBmp ?: return
        val r = patch.width / 2f
        val dx = x - lastX
        val dy = y - lastY
        if (Math.sqrt((dx * dx + dy * dy).toDouble()) < r * 0.25) return
        val c = Canvas(l.bmp)
        applyClip(c)
        val circle = Path()
        circle.addCircle(x, y, r, Path.Direction.CW)
        c.save()
        c.clipPath(circle)
        smudgePaint.alpha = 150
        c.drawBitmap(patch, x - r, y - r, smudgePaint)
        c.restore()
        patch.recycle()
        smudgeBmp = grabPatch(l, x, y)
        lastX = x
        lastY = y
        invalidate()
    }

    private fun finishSmudge() {
        smudging = false
        smudgeBmp?.recycle()
        smudgeBmp = null
        val s = pendingSnap
        pendingSnap = null
        if (s != null) {
            s.layer.dirty = true
            addUndo(s)
        }
        invalidate()
        onCommit?.invoke()
    }

    // ----------------------------------------------------------------- blur (estilo ibis)
    private fun startBlur(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        pendingSnap = Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true))
        blurring = true
        lastX = x
        lastY = y
        applyBlurAt(l, x, y)
    }

    private fun continueBlur(x: Float, y: Float) {
        val l = layers[current]
        val dx = x - lastX
        val dy = y - lastY
        if (Math.sqrt((dx * dx + dy * dy).toDouble()) < brushSize * 0.3) return
        applyBlurAt(l, x, y)
        lastX = x
        lastY = y
        invalidate()
    }

    private fun finishBlur() {
        blurring = false
        val s = pendingSnap
        pendingSnap = null
        if (s != null) {
            s.layer.dirty = true
            addUndo(s)
        }
        invalidate()
        onCommit?.invoke()
    }

    private fun applyBlurAt(l: Layer, x: Float, y: Float) {
        val r = (brushSize / 2f).toInt().coerceAtLeast(2)
        val cx = x.toInt()
        val cy = y.toInt()
        val left = (cx - r).coerceAtLeast(0)
        val top = (cy - r).coerceAtLeast(0)
        val right = (cx + r).coerceAtMost(l.bmp.width - 1)
        val bottom = (cy + r).coerceAtMost(l.bmp.height - 1)
        if (right <= left || bottom <= top) return
        val w = right - left + 1
        val h = bottom - top + 1
        val pixels = IntArray(w * h)
        l.bmp.getPixels(pixels, 0, w, left, top, w, h)
        val out = IntArray(w * h)
        val radius = 2
        for (py in 0 until h) {
            for (px in 0 until w) {
                var a = 0; var rSum = 0; var g = 0; var b = 0; var n = 0
                for (dy in -radius..radius) {
                    for (dx in -radius..radius) {
                        val nx = px + dx
                        val ny = py + dy
                        if (nx in 0 until w && ny in 0 until h) {
                            val c = pixels[ny * w + nx]
                            a += (c ushr 24) and 0xFF
                            rSum += (c ushr 16) and 0xFF
                            g += (c ushr 8) and 0xFF
                            b += c and 0xFF
                            n++
                        }
                    }
                }
                if (n > 0) {
                    out[py * w + px] = ((a / n) shl 24) or ((rSum / n) shl 16) or ((g / n) shl 8) or (b / n)
                }
            }
        }
        l.bmp.setPixels(out, 0, w, left, top, w, h)
    }

    // ----------------------------------------------------------------- liquify (empurra pixels)
    private fun startLiquify(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        pendingSnap = Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true))
        liquifying = true
        lastX = x
        lastY = y
    }

    private fun continueLiquify(x: Float, y: Float) {
        val l = layers[current]
        val dx = x - lastX
        val dy = y - lastY
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (dist < 2f) return
        val r = brushSize / 2f
        val strength = 0.35f
        val left = ((x - r).toInt()).coerceAtLeast(0)
        val top = ((y - r).toInt()).coerceAtLeast(0)
        val right = ((x + r).toInt()).coerceAtMost(l.bmp.width - 1)
        val bottom = ((y + r).toInt()).coerceAtMost(l.bmp.height - 1)
        if (right <= left || bottom <= top) return
        val w = right - left + 1
        val h = bottom - top + 1
        val src = IntArray(w * h)
        l.bmp.getPixels(src, 0, w, left, top, w, h)
        val dst = src.copyOf()
        val cx = x - left
        val cy = y - top
        for (py in 0 until h) {
            for (px in 0 until w) {
                val ddx = px - cx
                val ddy = py - cy
                val d = Math.sqrt((ddx * ddx + ddy * ddy).toDouble()).toFloat()
                if (d < r && d > 0.5f) {
                    val f = (1f - d / r) * strength
                    val sx = (px - dx * f).toInt().coerceIn(0, w - 1)
                    val sy = (py - dy * f).toInt().coerceIn(0, h - 1)
                    dst[py * w + px] = src[sy * w + sx]
                }
            }
        }
        l.bmp.setPixels(dst, 0, w, left, top, w, h)
        lastX = x
        lastY = y
        invalidate()
    }

    private fun finishLiquify() {
        liquifying = false
        val s = pendingSnap
        pendingSnap = null
        if (s != null) {
            s.layer.dirty = true
            addUndo(s)
        }
        invalidate()
        onCommit?.invoke()
    }

    // ----------------------------------------------------------------- magic wand (seleção por cor)
    private fun magicSelect(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        val ix = x.toInt().coerceIn(0, l.bmp.width - 1)
        val iy = y.toInt().coerceIn(0, l.bmp.height - 1)
        val target = l.bmp.getPixel(ix, iy)
        val tol = 32
        val path = Path()
        val visited = BooleanArray(l.bmp.width * l.bmp.height)
        val queue = java.util.ArrayDeque<Int>()
        val start = iy * l.bmp.width + ix
        queue.add(start)
        visited[start] = true
        var minX = ix; var maxX = ix; var minY = iy; var maxY = iy
        val w = l.bmp.width
        val h = l.bmp.height
        while (queue.isNotEmpty()) {
            val idx = queue.removeFirst()
            val px = idx % w
            val py = idx / w
            if (px < minX) minX = px
            if (px > maxX) maxX = px
            if (py < minY) minY = py
            if (py > maxY) maxY = py
            for (d in intArrayOf(-1, 1, -w, w)) {
                val n = idx + d
                if (n < 0 || n >= visited.size) continue
                if (d == -1 && px == 0) continue
                if (d == 1 && px == w - 1) continue
                if (visited[n]) continue
                val c = l.bmp.getPixel(n % w, n / w)
                if (colorDist(c, target) <= tol) {
                    visited[n] = true
                    queue.add(n)
                }
            }
        }
        // cria path simples pelo bounding box (rápido) ou por pontos
        path.addRect(minX.toFloat(), minY.toFloat(), (maxX + 1).toFloat(), (maxY + 1).toFloat(), Path.Direction.CW)
        selDraft.reset()
        selDraft.set(path)
        selecting = false
        finishLassoSelection()
        invalidate()
        onSelectionChanged?.invoke()
    }

    private fun colorDist(a: Int, b: Int): Int {
        val dr = ((a ushr 16) and 0xFF) - ((b ushr 16) and 0xFF)
        val dg = ((a ushr 8) and 0xFF) - ((b ushr 8) and 0xFF)
        val db = (a and 0xFF) - (b and 0xFF)
        return Math.abs(dr) + Math.abs(dg) + Math.abs(db)
    }

    // ----------------------------------------------------------------- formas
    private fun shapePaint(): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color or 0xFF000000.toInt()
        p.strokeWidth = brushSize
        p.alpha = opacity
        return p
    }

    private fun drawShape(c: Canvas, p: Paint) {
        val l = minOf(sx, ex)
        val t = minOf(sy, ey)
        val r = maxOf(sx, ex)
        val b = maxOf(sy, ey)
        when (tool) {
            T_LINE -> c.drawLine(sx, sy, ex, ey, p)
            T_RECT -> c.drawRect(l, t, r, b, p)
            else -> c.drawOval(RectF(l, t, r, b), p)
        }
    }

    private fun commitShape() {
        shaping = false
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        val c = Canvas(l.bmp)
        applyClip(c)
        drawShape(c, shapePaint())
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- gradiente
    private fun gradientPaint(): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.shader = LinearGradient(
            sx, sy, ex, ey,
            color or 0xFF000000.toInt(), color and 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        p.alpha = opacity
        return p
    }

    private fun commitGradient() {
        gradienting = false
        if (current < 0 || current >= layers.size) return
        val dx = ex - sx
        val dy = ey - sy
        if (dx * dx + dy * dy < 16f) {
            invalidate()
            return
        }
        pushUndo()
        val l = layers[current]
        val c = Canvas(l.bmp)
        applyClip(c)
        c.drawRect(0f, 0f, docW.toFloat(), docH.toFloat(), gradientPaint())
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    // ------------------------------------------------------------------ texto
    fun drawText(x: Float, y: Float, text: String, size: Float, bold: Boolean, italic: Boolean) {
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        val c = Canvas(l.bmp)
        applyClip(c)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color or 0xFF000000.toInt()
        p.alpha = opacity
        p.textSize = size
        val style = if (bold && italic) {
            Typeface.BOLD_ITALIC
        } else if (bold) {
            Typeface.BOLD
        } else if (italic) {
            Typeface.ITALIC
        } else {
            Typeface.NORMAL
        }
        p.typeface = Typeface.create(Typeface.DEFAULT, style)
        var yy = y
        for (line in text.split("\n")) {
            c.drawText(line, x, yy, p)
            yy += size * 1.2f
        }
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- seleção
    fun hasSelection(): Boolean = selPath != null

    fun clearSelection() {
        selPath = null
        selecting = false
        invalidate()
        onSelectionChanged?.invoke()
    }

    private fun finishRectSelection() {
        selecting = false
        val l = minOf(selStartX, selEndX)
        val t = minOf(selStartY, selEndY)
        val r = maxOf(selStartX, selEndX)
        val b = maxOf(selStartY, selEndY)
        if (r - l < 6f || b - t < 6f) {
            selPath = null          // toque sem arrastar: solta a seleção
        } else {
            val p = Path()
            p.addRect(l, t, r, b, Path.Direction.CW)
            selPath = p
        }
        invalidate()
        onSelectionChanged?.invoke()
    }

    private fun finishLassoSelection() {
        selecting = false
        val rf = RectF()
        selDraft.computeBounds(rf, true)
        if (rf.width() < 6f || rf.height() < 6f) {
            selPath = null
        } else {
            selPath = Path(selDraft)
        }
        invalidate()
        onSelectionChanged?.invoke()
    }

    private fun eraseSelection(idx: Int) {
        val sp = selPath ?: return
        val l = layers[idx]
        val c = Canvas(l.bmp)
        c.clipPath(sp)
        if (idx == 0 && Color.alpha(bgColor) != 0) {
            c.drawColor(bgColor)
        } else {
            c.drawColor(0, PorterDuff.Mode.CLEAR)
        }
        l.dirty = true
    }

    /** Copia (ou recorta) o que está dentro da seleção para uma camada nova. */
    fun selCopyToLayer(cut: Boolean): Boolean {
        if (transforming) applyTransform()
        val sp = selPath ?: return false
        if (layers.size >= MAX_LAYERS || current < 0 || current >= layers.size) return false
        val src = layers[current]
        val nb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        val c = Canvas(nb)
        c.clipPath(sp)
        c.drawBitmap(src.bmp, 0f, 0f, null)
        if (cut) {
            pushUndo()
            eraseSelection(current)
        }
        layerCounter++
        val at = current + 1
        layers.add(at, Layer(nb, true, (if (cut) "Recorte " else "Cópia ") + layerCounter, nextUid()))
        current = at
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun selErase(): Boolean {
        if (transforming) applyTransform()
        if (selPath == null || current < 0 || current >= layers.size) return false
        pushUndo()
        eraseSelection(current)
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun selFill(): Boolean {
        if (transforming) applyTransform()
        val sp = selPath ?: return false
        if (current < 0 || current >= layers.size) return false
        pushUndo()
        val l = layers[current]
        val c = Canvas(l.bmp)
        c.clipPath(sp)
        c.drawColor(Color.argb(opacity, Color.red(color), Color.green(color), Color.blue(color)))
        l.dirty = true
        invalidate()
        onCommit?.invoke()
        return true
    }

    // ------------------------------------------------------------------ balde
    private fun fillAt(x: Float, y: Float) {
        val xi = x.toInt()
        val yi = y.toInt()
        if (xi < 0 || yi < 0 || xi >= docW || yi >= docH) return
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        val fc = Color.argb(opacity, Color.red(color), Color.green(color), Color.blue(color))
        floodFill(l.bmp, xi, yi, fc, 40)
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    private fun floodFill(bmp: Bitmap, startX: Int, startY: Int, fillColor: Int, tol: Int) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[startY * w + startX]
        val tA = Color.alpha(target)
        val tR = Color.red(target)
        val tG = Color.green(target)
        val tB = Color.blue(target)
        val visited = BooleanArray(w * h)

        fun close(c: Int): Boolean {
            return Math.abs(Color.alpha(c) - tA) <= tol &&
                Math.abs(Color.red(c) - tR) <= tol &&
                Math.abs(Color.green(c) - tG) <= tol &&
                Math.abs(Color.blue(c) - tB) <= tol
        }

        val stack = java.util.ArrayDeque<Int>()
        stack.push(startY * w + startX)
        while (stack.isNotEmpty()) {
            val pos = stack.pop()
            val y = pos / w
            val x0 = pos % w
            if (visited[pos] || !close(px[pos])) continue
            var xl = x0
            while (xl > 0 && !visited[y * w + xl - 1] && close(px[y * w + xl - 1])) xl--
            var xr = x0
            while (xr < w - 1 && !visited[y * w + xr + 1] && close(px[y * w + xr + 1])) xr++
            var up = false
            var down = false
            for (x in xl..xr) {
                val i = y * w + x
                visited[i] = true
                px[i] = fillColor
                if (y > 0) {
                    val j = i - w
                    val okUp = !visited[j] && close(px[j])
                    if (okUp && !up) {
                        stack.push(j)
                        up = true
                    } else if (!okUp) {
                        up = false
                    }
                }
                if (y < h - 1) {
                    val j = i + w
                    val okDown = !visited[j] && close(px[j])
                    if (okDown && !down) {
                        stack.push(j)
                        down = true
                    } else if (!okDown) {
                        down = false
                    }
                }
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    // ----------------------------------------------------------- conta-gotas
    private fun renderFlat(target: Bitmap) {
        target.eraseColor(Color.TRANSPARENT)
        val c = Canvas(target)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        for (l in layers) {
            if (!l.visible) continue
            applyLayerPaint(l, p)
            c.drawBitmap(l.bmp, 0f, 0f, p)
        }
    }

    private fun pick(x: Float, y: Float) {
        val xi = x.toInt()
        val yi = y.toInt()
        if (xi < 0 || yi < 0 || xi >= docW || yi >= docH) return
        var fb = flatBmp
        if (fb == null) {
            fb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
            flatBmp = fb
        }
        renderFlat(fb)
        val c = fb.getPixel(xi, yi)
        val result = if (Color.alpha(c) == 0) Color.WHITE else (c or 0xFF000000.toInt())
        onPick?.invoke(result)
    }

    /** Todas as camadas visíveis num único bitmap (PNG com transparência). */
    fun flatten(): Bitmap {
        val b = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        renderFlat(b)
        return b
    }

    /** Versão reduzida sobre fundo branco (miniaturas e quadros do timelapse). */
    fun renderSmall(w: Int, h: Int): Bitmap? {
        return try {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.drawColor(Color.WHITE)
            c.scale(w.toFloat() / docW, h.toFloat() / docH)
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            for (l in layers) {
                if (!l.visible) continue
                applyLayerPaint(l, p)
                c.drawBitmap(l.bmp, 0f, 0f, p)
            }
            b
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Cópia das camadas alteradas, para gravar em segundo plano sem travar o desenho. */
    fun snapshot(): List<SaveLayer> {
        val out = ArrayList<SaveLayer>()
        for (l in layers) {
            val copy = if (l.dirty) l.bmp.copy(Bitmap.Config.ARGB_8888, false) else null
            out.add(SaveLayer(l.uid, l.name, l.visible, l.opacity, l.blend, l.alphaLock, l.clipping, l.locked, copy))
            l.dirty = false
        }
        return out
    }

    // ---------------------------------------------------------------- histórico
    private fun pushUndo() {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        addUndo(Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true)))
    }

    private fun addUndo(s: Snap) {
        undoList.add(s)
        while (undoList.size > maxUndo) {
            val old = undoList.removeAt(0)
            old.bmp.recycle()
        }
        for (r in redoList) r.bmp.recycle()
        redoList.clear()
        onHistoryChanged?.invoke()
    }

    fun canUndo(): Boolean = undoList.isNotEmpty()
    fun canRedo(): Boolean = redoList.isNotEmpty()

    fun undo() {
        if (transforming) cancelTransform()
        while (undoList.isNotEmpty()) {
            val s = undoList.removeAt(undoList.size - 1)
            if (!layers.contains(s.layer)) {
                s.bmp.recycle()
                continue
            }
            redoList.add(Snap(s.layer, s.layer.bmp))
            s.layer.bmp = s.bmp
            s.layer.dirty = true
            break
        }
        invalidate()
        onHistoryChanged?.invoke()
        onCommit?.invoke()
    }

    fun redo() {
        if (transforming) cancelTransform()
        while (redoList.isNotEmpty()) {
            val s = redoList.removeAt(redoList.size - 1)
            if (!layers.contains(s.layer)) {
                s.bmp.recycle()
                continue
            }
            undoList.add(Snap(s.layer, s.layer.bmp))
            s.layer.bmp = s.bmp
            s.layer.dirty = true
            break
        }
        invalidate()
        onHistoryChanged?.invoke()
        onCommit?.invoke()
    }

    // ------------------------------------------------------------------ camadas
    fun selectLayer(i: Int) {
        if (transforming) applyTransform()
        current = i.coerceIn(0, maxOf(0, layers.size - 1))
        invalidate()
    }

    fun addLayer(): Boolean {
        if (transforming) applyTransform()
        if (layers.size >= MAX_LAYERS) return false
        val b = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        layerCounter++
        val at = minOf(current + 1, layers.size)
        layers.add(at, Layer(b, true, "Camada $layerCounter", nextUid()))
        current = at
        invalidate()
        onCommit?.invoke()
        return true
    }

    /** Imagem de referência (ou qualquer foto) vira uma camada, centralizada e ajustada à tela. */
    fun addImageLayer(src: Bitmap, name: String): Boolean {
        if (transforming) applyTransform()
        if (layers.size >= MAX_LAYERS) return false
        val nb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        val c = Canvas(nb)
        val s = minOf(docW.toFloat() / src.width, docH.toFloat() / src.height)
        val dw = src.width * s
        val dh = src.height * s
        val dst = RectF((docW - dw) / 2f, (docH - dh) / 2f, (docW + dw) / 2f, (docH + dh) / 2f)
        c.drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        val at = minOf(current + 1, layers.size)
        layers.add(at, Layer(nb, true, name, nextUid()))
        current = at
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun duplicateCurrent(): Boolean {
        if (transforming) applyTransform()
        if (layers.size >= MAX_LAYERS || current < 0 || current >= layers.size) return false
        val src = layers[current]
        val copy = Layer(src.bmp.copy(Bitmap.Config.ARGB_8888, true), src.visible, src.name + " cópia", nextUid())
        copy.opacity = src.opacity
        copy.blend = src.blend
        copy.alphaLock = src.alphaLock
        copy.clipping = src.clipping
        copy.locked = src.locked
        layers.add(current + 1, copy)
        current += 1
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun removeCurrent(): Boolean {
        if (transforming) cancelTransform()
        if (layers.size <= 1) return false
        val l = layers.removeAt(current)
        l.bmp.recycle()
        current = maxOf(0, current - 1)
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun clearCurrent() {
        if (transforming) cancelTransform()
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        if (current == 0) l.bmp.eraseColor(bgColor) else l.bmp.eraseColor(Color.TRANSPARENT)
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    fun mergeDown(): Boolean {
        if (transforming) applyTransform()
        if (current <= 0 || current >= layers.size) return false
        val top = layers[current]
        val below = layers[current - 1]
        if (top.visible) {
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            applyLayerPaint(top, p)
            Canvas(below.bmp).drawBitmap(top.bmp, 0f, 0f, p)
            below.dirty = true
        }
        layers.removeAt(current)
        top.bmp.recycle()
        current -= 1
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun moveCurrent(up: Boolean) {
        if (transforming) applyTransform()
        val j = if (up) current + 1 else current - 1
        if (j < 0 || j >= layers.size) return
        val tmp = layers[current]
        layers[current] = layers[j]
        layers[j] = tmp
        current = j
        invalidate()
        onCommit?.invoke()
    }

    /** Chamada depois de mudar opacidade, mistura, nome, bloqueio ou visibilidade de uma camada. */
    fun layerChanged() {
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- filtros (estilo ibis)
    private fun withCurrentLayer(op: (Bitmap) -> Unit) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        if (l.locked) return
        pushUndo()
        op(l.bmp)
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    fun applyFilterInvert() = withCurrentLayer { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        for (i in px.indices) {
            val a = px[i] ushr 24
            val r = 255 - ((px[i] ushr 16) and 0xFF)
            val g = 255 - ((px[i] ushr 8) and 0xFF)
            val b = 255 - (px[i] and 0xFF)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    }

    fun applyFilterGrayscale() = withCurrentLayer { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        for (i in px.indices) {
            val a = px[i] ushr 24
            val r = (px[i] ushr 16) and 0xFF
            val g = (px[i] ushr 8) and 0xFF
            val b = px[i] and 0xFF
            val y = (r * 30 + g * 59 + b * 11) / 100
            px[i] = (a shl 24) or (y shl 16) or (y shl 8) or y
        }
        bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    }

    fun applyFilterBrightnessContrast(bright: Int, contrast: Int) = withCurrentLayer { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val cf = (259 * (contrast + 255)) / (255 * (259 - contrast)).toFloat()
        for (i in px.indices) {
            val a = px[i] ushr 24
            var r = ((px[i] ushr 16) and 0xFF) + bright
            var g = ((px[i] ushr 8) and 0xFF) + bright
            var b = (px[i] and 0xFF) + bright
            r = (cf * (r - 128) + 128).toInt().coerceIn(0, 255)
            g = (cf * (g - 128) + 128).toInt().coerceIn(0, 255)
            b = (cf * (b - 128) + 128).toInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    }

    fun applyFilterHueSat(hueShift: Int, satShift: Int) = withCurrentLayer { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val hsv = FloatArray(3)
        for (i in px.indices) {
            val a = px[i] ushr 24
            if (a == 0) continue
            Color.colorToHSV(px[i], hsv)
            hsv[0] = (hsv[0] + hueShift + 360) % 360
            hsv[1] = (hsv[1] + satShift / 100f).coerceIn(0f, 1f)
            px[i] = (a shl 24) or (Color.HSVToColor(hsv) and 0x00FFFFFF)
        }
        bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    }

    fun applyFilterScreentone() = withCurrentLayer { bmp ->
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val step = 6
        for (y in 0 until bmp.height) {
            for (x in 0 until bmp.width) {
                val i = y * bmp.width + x
                val a = px[i] ushr 24
                if (a < 20) continue
                val r = (px[i] ushr 16) and 0xFF
                val g = (px[i] ushr 8) and 0xFF
                val b = px[i] and 0xFF
                val lum = (r * 30 + g * 59 + b * 11) / 100
                val on = ((x / step) + (y / step)) % 2 == 0
                val v = if (on && lum < 180) 30 else if (!on && lum > 80) 220 else lum
                px[i] = (a shl 24) or (v shl 16) or (v shl 8) or v
            }
        }
        bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    }

    fun applyFilterEmboss() = withCurrentLayer { bmp ->
        val w = bmp.width
        val h = bmp.height
        val src = IntArray(w * h)
        bmp.getPixels(src, 0, w, 0, 0, w, h)
        val dst = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val a = src[i] ushr 24
                val tl = src[(y - 1) * w + (x - 1)]
                val br = src[(y + 1) * w + (x + 1)]
                val tr = ((tl ushr 16) and 0xFF)
                val tg = ((tl ushr 8) and 0xFF)
                val tb = (tl and 0xFF)
                val brR = ((br ushr 16) and 0xFF)
                val brG = ((br ushr 8) and 0xFF)
                val brB = (br and 0xFF)
                val r = (tr - brR + 128).coerceIn(0, 255)
                val g = (tg - brG + 128).coerceIn(0, 255)
                val b = (tb - brB + 128).coerceIn(0, 255)
                dst[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bmp.setPixels(dst, 0, w, 0, 0, w, h)
    }

    fun applyFilterBlurLight() = withCurrentLayer { bmp ->
        // reutiliza blur simples 3x3
        val w = bmp.width
        val h = bmp.height
        val src = IntArray(w * h)
        bmp.getPixels(src, 0, w, 0, 0, w, h)
        val dst = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var a = 0; var r = 0; var g = 0; var b = 0; var n = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val c = src[(y + dy) * w + (x + dx)]
                    a += c ushr 24
                    r += (c ushr 16) and 0xFF
                    g += (c ushr 8) and 0xFF
                    b += c and 0xFF
                    n++
                }
                dst[y * w + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        bmp.setPixels(dst, 0, w, 0, 0, w, h)
    }

    // --------------------------------------------------------------- desenho
    private fun drawGuides(c: Canvas) {
        val s = currentScale()
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        c.save()
        c.clipRect(docRect)
        gridPaint.style = Paint.Style.STROKE
        when (guideMode) {
            1 -> {
                gridPaint.strokeWidth = 1f / s
                gridPaint.color = 0x66888888
                val step = fw / 12f
                var x = step
                while (x < fw) {
                    c.drawLine(x, 0f, x, fh, gridPaint)
                    x += step
                }
                var y = step
                while (y < fh) {
                    c.drawLine(0f, y, fw, y, gridPaint)
                    y += step
                }
                gridPaint.color = 0xAAE53935.toInt()
                gridPaint.strokeWidth = 2f / s
                c.drawLine(fw / 2f, 0f, fw / 2f, fh, gridPaint)
                c.drawLine(0f, fh / 2f, fw, fh / 2f, gridPaint)
            }
            2 -> {
                gridPaint.strokeWidth = 2f / s
                gridPaint.color = 0xAAFFC107.toInt()
                c.drawLine(fw / 3f, 0f, fw / 3f, fh, gridPaint)
                c.drawLine(fw * 2f / 3f, 0f, fw * 2f / 3f, fh, gridPaint)
                c.drawLine(0f, fh / 3f, fw, fh / 3f, gridPaint)
                c.drawLine(0f, fh * 2f / 3f, fw, fh * 2f / 3f, gridPaint)
            }
            3 -> {
                gridPaint.strokeWidth = 1.5f / s
                gridPaint.color = 0x9900E5FF.toInt()
                val cx = fw / 2f
                val cy = fh / 2f
                val len = fw + fh
                var a = 0
                while (a < 360) {
                    val r = Math.toRadians(a.toDouble())
                    c.drawLine(
                        cx, cy,
                        cx + (Math.cos(r) * len).toFloat(), cy + (Math.sin(r) * len).toFloat(),
                        gridPaint
                    )
                    a += 15
                }
                gridPaint.color = 0xFFE53935.toInt()
                gridPaint.strokeWidth = 4f / s
                c.drawPoint(cx, cy, gridPaint)
            }
            4 -> {
                gridPaint.strokeWidth = 1f / s
                gridPaint.color = 0x9900E5FF.toInt()
                val t = Math.tan(Math.toRadians(30.0)).toFloat()
                val step = fw / 12f
                var b = -fw * t
                while (b < fh + fw * t) {
                    c.drawLine(0f, b, fw, b + fw * t, gridPaint)
                    c.drawLine(0f, b + fw * t, fw, b, gridPaint)
                    b += step
                }
                var x = step
                while (x < fw) {
                    c.drawLine(x, 0f, x, fh, gridPaint)
                    x += step
                }
            }
        }
        c.restore()
    }

    private fun drawSymmetryAxes(c: Canvas) {
        val s = currentScale()
        gridPaint.style = Paint.Style.STROKE
        gridPaint.strokeWidth = 2f / s
        gridPaint.color = 0xCC00E5FF.toInt()
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawLine(fw / 2f, 0f, fw / 2f, fh, gridPaint)
        if (symmetry == 2 || symmetry == 3) c.drawLine(0f, fh / 2f, fw, fh / 2f, gridPaint)
    }

    private fun draftPath(): Path? {
        if (tool == T_SEL_RECT) {
            val p = Path()
            p.addRect(
                minOf(selStartX, selEndX), minOf(selStartY, selEndY),
                maxOf(selStartX, selEndX), maxOf(selStartY, selEndY), Path.Direction.CW
            )
            return p
        }
        return selDraft
    }

    private fun drawSelection(c: Canvas) {
        val sp = if (selecting) draftPath() else selPath
        if (sp == null) return
        val s = currentScale()
        selPaint.style = Paint.Style.STROKE
        selPaint.pathEffect = null
        selPaint.strokeWidth = 3f / s
        selPaint.color = 0xFFFFFFFF.toInt()
        c.drawPath(sp, selPaint)
        selPaint.strokeWidth = 1.5f / s
        selPaint.color = 0xFF000000.toInt()
        selPaint.pathEffect = DashPathEffect(floatArrayOf(10f / s, 10f / s), 0f)
        c.drawPath(sp, selPaint)
        selPaint.pathEffect = null
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF1B1B1B.toInt())
        if (layers.isEmpty()) return
        canvas.save()
        canvas.concat(m)
        docRect.set(0f, 0f, docW.toFloat(), docH.toFloat())
        canvas.drawRect(docRect, checkerPaint)

        val sc = canvas.saveLayer(docRect, null)
        for (i in layers.indices) {
            val l = layers[i]
            if (!l.visible) continue
            applyLayerPaint(l, layerPaint)
            val useClip = l.clipping && i > 0
            if (useClip) {
                // Clipping Mask: desenha só onde a camada de baixo tem pixels
                val clipSc = canvas.saveLayer(docRect, null)
                if (transforming && i == current) {
                    canvas.save()
                    canvas.concat(tMatrix)
                    canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
                    canvas.restore()
                } else {
                    canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
                }
                if (stroking && i == current) {
                    val sb = strokeBmp
                    if (sb != null) {
                        previewPaint.alpha = commitAlpha()
                        previewPaint.xfermode = null
                        canvas.drawBitmap(sb, 0f, 0f, previewPaint)
                    }
                }
                val below = layers[i - 1]
                val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG)
                maskPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                canvas.drawBitmap(below.bmp, 0f, 0f, maskPaint)
                canvas.restoreToCount(clipSc)
            } else {
                if (transforming && i == current) {
                    canvas.save()
                    canvas.concat(tMatrix)
                    canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
                    canvas.restore()
                } else {
                    canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
                }
                if (stroking && i == current) {
                    val sb = strokeBmp
                    if (sb != null) {
                        previewPaint.alpha = commitAlpha()
                        previewPaint.xfermode = null
                        canvas.drawBitmap(sb, 0f, 0f, previewPaint)
                    }
                }
            }
        }
        canvas.restoreToCount(sc)

        if (shaping) drawShape(canvas, shapePaint())
        if (gradienting) canvas.drawRect(docRect, gradientPaint())
        if (guideMode != 0) drawGuides(canvas)
        if (symmetry != 0) drawSymmetryAxes(canvas)
        drawSelection(canvas)
        canvas.drawRect(docRect, borderPaint)
        canvas.restore()
    }
}
