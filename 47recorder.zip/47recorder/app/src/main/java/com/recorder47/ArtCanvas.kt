package com.recorder47

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Tela de desenho do 47 Art Mode.
 * Um dedo desenha; dois dedos dão zoom e movem a tela (o traço em andamento é cancelado,
 * então nunca sobra um risco por engano). Na ferramenta Transformar, dois dedos movem,
 * giram e escalam a camada.
 */
class ArtCanvas(ctx: Context) : View(ctx) {

    class Layer(var bmp: Bitmap, var visible: Boolean, var name: String, val uid: Int) {
        var opacity = 255
        var blend = 0
        var dirty = true
    }

    class SaveLayer(
        val uid: Int, val name: String, val visible: Boolean,
        val opacity: Int, val blend: Int, val bmpCopy: Bitmap?
    )

    private class Snap(val layer: Layer, val bmp: Bitmap)

    companion object {
        const val T_PENCIL = 0
        const val T_PEN = 1
        const val T_BRUSH = 2
        const val T_AIR = 3
        const val T_MARKER = 4
        const val T_ERASER = 5
        const val T_FILL = 6
        const val T_PICK = 7
        const val T_LINE = 8
        const val T_RECT = 9
        const val T_OVAL = 10
        const val T_TRANSFORM = 11
        const val T_HAND = 12

        val BLEND_NAMES = arrayOf("Normal", "Multiplicar", "Tela", "Sobrepor", "Escurecer", "Clarear", "Somar")
        private val BLEND_MODES: Array<PorterDuff.Mode?> = arrayOf<PorterDuff.Mode?>(
            null, PorterDuff.Mode.MULTIPLY, PorterDuff.Mode.SCREEN, PorterDuff.Mode.OVERLAY,
            PorterDuff.Mode.DARKEN, PorterDuff.Mode.LIGHTEN, PorterDuff.Mode.ADD
        )
        const val MAX_LAYERS = 8
    }

    val layers = ArrayList<Layer>()
    var current = 0
    var docW = 1080
    var docH = 1350
    var bgColor: Int = Color.WHITE
    var color: Int = Color.BLACK
    var brushSize = 12f
    var opacity = 255
    var stabilizer = 0
    var symmetry = 0          // 0 off, 1 espelho esquerda/direita, 2 cima/baixo, 3 os dois
    var padTop = 0f
    var padBottom = 0f
    var showGrid: Boolean = false
        set(v) {
            field = v
            invalidate()
        }
    var tool: Int = T_PENCIL
        set(v) {
            if (field == T_TRANSFORM && v != T_TRANSFORM && transforming) applyTransform()
            field = v
        }
    var transforming: Boolean = false
        private set

    var onPick: ((Int) -> Unit)? = null
    var onHistoryChanged: (() -> Unit)? = null
    var onCommit: (() -> Unit)? = null
    var onTransformChanged: (() -> Unit)? = null

    private val m = Matrix()
    private val inv = Matrix()
    private val tMatrix = Matrix()
    private val vals = FloatArray(9)
    private var fitted = false
    private var layerCounter = 1
    private var uidCounter = 0

    private var strokeBmp: Bitmap? = null
    private var strokeCanvas: Canvas? = null
    private var flatBmp: Bitmap? = null

    private val undoList = ArrayList<Snap>()
    private val redoList = ArrayList<Snap>()
    private var maxUndo = 8
    private var pendingSnap: Snap? = null

    private val xfers: Array<PorterDuffXfermode?> = Array(7) { i ->
        val md = BLEND_MODES[i]
        if (md == null) null else PorterDuffXfermode(md)
    }

    private val layerPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val previewPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val checkerPaint = Paint()
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val docRect = RectF()

    // estado do toque
    private var gesture = false
    private var stroking = false
    private var erasing = false
    private var shaping = false
    private var filling = false
    private var stylus = false
    private var smX = 0f
    private var smY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var curW = 12f
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var fillX = 0f
    private var fillY = 0f
    private var handX = 0f
    private var handY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f

    // transformar camada
    private val tp = FloatArray(4)
    private val tcur = FloatArray(4)
    private var tCount = 0

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val cur = currentScale()
            val target = (cur * detector.scaleFactor).coerceIn(0.1f, 16f)
            val f = target / cur
            m.postScale(f, f, detector.focusX, detector.focusY)
            invalidate()
            return true
        }
    })

    init {
        scaleDet.isQuickScaleEnabled = false
        val cb = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        val cc = Canvas(cb)
        cc.drawColor(0xFFFFFFFF.toInt())
        val p = Paint()
        p.color = 0xFFD0D0D0.toInt()
        cc.drawRect(0f, 0f, 16f, 16f, p)
        cc.drawRect(16f, 16f, 32f, 32f, p)
        checkerPaint.shader = BitmapShader(cb, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        borderPaint.style = Paint.Style.STROKE
        borderPaint.color = 0xFF555555.toInt()
        borderPaint.strokeWidth = 2f
        gridPaint.style = Paint.Style.STROKE
    }

    // ------------------------------------------------------------ documento
    fun newDoc(w: Int, h: Int, bg: Int) {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.eraseColor(bg)
        val list = ArrayList<Layer>()
        list.add(Layer(b, true, "Fundo", 1))
        setDoc(w, h, bg, list, 0)
    }

    fun setDoc(w: Int, h: Int, bg: Int, list: List<Layer>, cur: Int) {
        for (l in layers) l.bmp.recycle()
        layers.clear()
        for (s in undoList) s.bmp.recycle()
        for (s in redoList) s.bmp.recycle()
        undoList.clear()
        redoList.clear()
        pendingSnap = null
        transforming = false
        tMatrix.reset()
        strokeBmp?.recycle()
        flatBmp?.recycle()
        flatBmp = null
        docW = w
        docH = h
        bgColor = bg
        layers.addAll(list)
        current = cur.coerceIn(0, maxOf(0, layers.size - 1))
        var maxUid = 0
        for (l in layers) if (l.uid > maxUid) maxUid = l.uid
        uidCounter = maxUid
        layerCounter = layers.size
        val sb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        strokeBmp = sb
        strokeCanvas = Canvas(sb)
        maxUndo = (50_000_000L / (w.toLong() * h * 4L)).toInt().coerceIn(3, 10)
        fitted = false
        if (width > 0) fit()
        invalidate()
        onHistoryChanged?.invoke()
    }

    private fun nextUid(): Int {
        uidCounter++
        return uidCounter
    }

    private fun currentScale(): Float {
        m.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun fit() {
        if (width == 0 || height == 0) return
        val availH = height - padTop - padBottom
        val scale = minOf(width * 0.94f / docW, availH * 0.94f / docH)
        m.reset()
        m.postScale(scale, scale)
        m.postTranslate((width - docW * scale) / 2f, padTop + (availH - docH * scale) / 2f)
        fitted = true
    }

    fun resetView() {
        fit()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted) fit()
    }

    private fun toDoc(x: Float, y: Float): FloatArray {
        m.invert(inv)
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return p
    }

    private fun applyLayerPaint(l: Layer, p: Paint) {
        p.alpha = l.opacity.coerceIn(0, 255)
        p.xfermode = xfers[l.blend.coerceIn(0, 6)]
    }

    // ---------------------------------------------------------------- toque
    private fun midX(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getX(i)
        return s / e.pointerCount
    }

    private fun midY(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getY(i)
        return s / e.pointerCount
    }

    private fun updateMid(e: MotionEvent, skip: Int) {
        var sumX = 0f
        var sumY = 0f
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            sumX += e.getX(i)
            sumY += e.getY(i)
            n++
        }
        if (n > 0) {
            lastMidX = sumX / n
            lastMidY = sumY / n
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (layers.isEmpty()) return true
        if (tool == T_TRANSFORM) return transformTouch(e)
        scaleDet.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gesture = false
                stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                beginTouch(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!gesture) {
                    cancelTouch()
                    gesture = true
                }
                updateMid(e, -1)
            }
            MotionEvent.ACTION_MOVE -> {
                if (gesture) {
                    if (e.pointerCount >= 2) {
                        val mx = midX(e)
                        val my = midY(e)
                        m.postTranslate(mx - lastMidX, my - lastMidY)
                        lastMidX = mx
                        lastMidY = my
                        invalidate()
                    }
                } else {
                    moveTouch(e.x, e.y, e.pressure)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                updateMid(e, e.actionIndex)
            }
            MotionEvent.ACTION_UP -> {
                if (!gesture) endTouch(e.x, e.y)
                gesture = false
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelTouch()
                gesture = false
            }
        }
        return true
    }

    private fun beginTouch(x: Float, y: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER -> startStroke(p[0], p[1])
            T_ERASER -> startErase(p[0], p[1])
            T_FILL -> {
                fillX = p[0]
                fillY = p[1]
                filling = true
            }
            T_PICK -> pick(p[0], p[1])
            T_LINE, T_RECT, T_OVAL -> {
                sx = p[0]
                sy = p[1]
                ex = sx
                ey = sy
                shaping = true
            }
            T_HAND -> {
                handX = x
                handY = y
            }
        }
    }

    private fun moveTouch(x: Float, y: Float, pressure: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER -> if (stroking) continueStroke(p[0], p[1], pressure)
            T_ERASER -> if (erasing) continueErase(p[0], p[1])
            T_FILL -> {
                fillX = p[0]
                fillY = p[1]
            }
            T_PICK -> pick(p[0], p[1])
            T_LINE, T_RECT, T_OVAL -> if (shaping) {
                ex = p[0]
                ey = p[1]
                invalidate()
            }
            T_HAND -> {
                m.postTranslate(x - handX, y - handY)
                handX = x
                handY = y
                invalidate()
            }
        }
    }

    private fun endTouch(x: Float, y: Float) {
        val p = toDoc(x, y)
        when (tool) {
            T_PENCIL, T_PEN, T_BRUSH, T_AIR, T_MARKER -> if (stroking) {
                flushStroke(p[0], p[1])
                finishStroke()
            }
            T_ERASER -> if (erasing) {
                flushErase(p[0], p[1])
                finishErase()
            }
            T_FILL -> if (filling) {
                filling = false
                fillAt(p[0], p[1])
            }
            T_LINE, T_RECT, T_OVAL -> if (shaping) {
                ex = p[0]
                ey = p[1]
                commitShape()
            }
        }
    }

    /** Um segundo dedo apareceu: descarta o traço em andamento sem sujar o desenho. */
    private fun cancelTouch() {
        if (stroking) {
            stroking = false
            strokeCanvas?.drawColor(0, PorterDuff.Mode.CLEAR)
        }
        if (erasing) {
            erasing = false
            val s = pendingSnap
            if (s != null) {
                val old = s.layer.bmp
                s.layer.bmp = s.bmp
                old.recycle()
            }
            pendingSnap = null
        }
        shaping = false
        filling = false
        invalidate()
    }

    // ------------------------------------------------- transformar camada
    private fun tCollect(e: MotionEvent, skip: Int, out: FloatArray): Int {
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            if (n >= 2) break
            val d = toDoc(e.getX(i), e.getY(i))
            out[n * 2] = d[0]
            out[n * 2 + 1] = d[1]
            n++
        }
        return n
    }

    private fun transformTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                tCount = tCollect(e, -1, tp)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                tCount = tCollect(e, e.actionIndex, tp)
            }
            MotionEvent.ACTION_MOVE -> tMove(e)
        }
        return true
    }

    private fun tMove(e: MotionEvent) {
        val n = tCollect(e, -1, tcur)
        if (n == 0 || n != tCount) {
            tCount = tCollect(e, -1, tp)
            return
        }
        if (n == 1) {
            tMatrix.postTranslate(tcur[0] - tp[0], tcur[1] - tp[1])
        } else {
            val pdx = tp[2] - tp[0]
            val pdy = tp[3] - tp[1]
            val cdx = tcur[2] - tcur[0]
            val cdy = tcur[3] - tcur[1]
            val pd = Math.hypot(pdx.toDouble(), pdy.toDouble()).toFloat()
            val cd = Math.hypot(cdx.toDouble(), cdy.toDouble()).toFloat()
            if (pd > 1f && cd > 1f) {
                val s = cd / pd
                var deg = Math.toDegrees(
                    Math.atan2(cdy.toDouble(), cdx.toDouble()) - Math.atan2(pdy.toDouble(), pdx.toDouble())
                ).toFloat()
                if (deg > 180f) deg -= 360f
                if (deg < -180f) deg += 360f
                val pmx = (tp[0] + tp[2]) / 2f
                val pmy = (tp[1] + tp[3]) / 2f
                val cmx = (tcur[0] + tcur[2]) / 2f
                val cmy = (tcur[1] + tcur[3]) / 2f
                val t = Matrix()
                t.postTranslate(-pmx, -pmy)
                t.postScale(s, s)
                t.postRotate(deg)
                t.postTranslate(cmx, cmy)
                tMatrix.postConcat(t)
            }
        }
        for (i in 0 until 4) tp[i] = tcur[i]
        if (!transforming) {
            transforming = true
            onTransformChanged?.invoke()
        }
        invalidate()
    }

    fun applyTransform() {
        if (!transforming) return
        transforming = false
        if (current >= 0 && current < layers.size) {
            pushUndo()
            val l = layers[current]
            val nb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(l.bmp, tMatrix, Paint(Paint.FILTER_BITMAP_FLAG))
            l.bmp.recycle()
            l.bmp = nb
            l.dirty = true
        }
        tMatrix.reset()
        invalidate()
        onTransformChanged?.invoke()
        onCommit?.invoke()
    }

    fun cancelTransform() {
        if (!transforming) return
        transforming = false
        tMatrix.reset()
        invalidate()
        onTransformChanged?.invoke()
    }

    // ---------------------------------------------------------------- pincéis
    private fun brushPaint(width: Float): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = if (tool == T_MARKER) Paint.Cap.SQUARE else Paint.Cap.ROUND
        p.color = color or 0xFF000000.toInt()
        p.strokeWidth = width
        if (tool == T_BRUSH) {
            p.maskFilter = BlurMaskFilter(maxOf(1f, width * 0.18f), BlurMaskFilter.Blur.NORMAL)
        } else if (tool == T_AIR) {
            p.strokeWidth = width * 1.6f
            p.maskFilter = BlurMaskFilter(maxOf(1f, width * 0.7f), BlurMaskFilter.Blur.NORMAL)
        }
        return p
    }

    private fun erasePaint(width: Float): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = width
        if (current == 0 && Color.alpha(bgColor) != 0) {
            p.color = bgColor
        } else {
            p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        return p
    }

    private fun commitAlpha(): Int {
        return if (tool == T_MARKER) (opacity * 0.55f).toInt() else opacity
    }

    /** Desenha o segmento e os espelhos (simetria). */
    private fun drawSegment(c: Canvas, p: Paint, x0: Float, y0: Float, x1: Float, y1: Float) {
        c.drawLine(x0, y0, x1, y1, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawLine(fw - x0, y0, fw - x1, y1, p)
        if (symmetry == 2 || symmetry == 3) c.drawLine(x0, fh - y0, x1, fh - y1, p)
        if (symmetry == 3) c.drawLine(fw - x0, fh - y0, fw - x1, fh - y1, p)
    }

    private fun drawDot(c: Canvas, p: Paint, x: Float, y: Float) {
        c.drawPoint(x, y, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawPoint(fw - x, y, p)
        if (symmetry == 2 || symmetry == 3) c.drawPoint(x, fh - y, p)
        if (symmetry == 3) c.drawPoint(fw - x, fh - y, p)
    }

    private fun smoothK(): Float = 1f / (1f + stabilizer * 1.2f)

    private fun startStroke(x: Float, y: Float) {
        val c = strokeCanvas ?: return
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        stroking = true
        smX = x
        smY = y
        lastX = x
        lastY = y
        curW = if (tool == T_PEN) brushSize * 0.6f else brushSize
        drawDot(c, brushPaint(curW), x, y)
        invalidate()
    }

    private fun continueStroke(x: Float, y: Float, pressure: Float) {
        val c = strokeCanvas ?: return
        val k = smoothK()
        smX += (x - smX) * k
        smY += (y - smY) * k
        val dx = smX - lastX
        val dy = smY - lastY
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (dist < 0.8f) return
        var w = brushSize
        if (tool == T_PEN) {
            val target = if (stylus) {
                brushSize * (0.25f + 0.9f * pressure.coerceIn(0f, 1f))
            } else {
                brushSize * (1.15f - minOf(dist / 40f, 0.75f))
            }
            curW += (target - curW) * 0.3f
            w = curW
        }
        drawSegment(c, brushPaint(w), lastX, lastY, smX, smY)
        lastX = smX
        lastY = smY
        invalidate()
    }

    private fun flushStroke(x: Float, y: Float) {
        val c = strokeCanvas ?: return
        val w = if (tool == T_PEN) curW else brushSize
        drawSegment(c, brushPaint(w), lastX, lastY, x, y)
        lastX = x
        lastY = y
    }

    private fun finishStroke() {
        stroking = false
        val sb = strokeBmp ?: return
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        previewPaint.alpha = commitAlpha()
        Canvas(l.bmp).drawBitmap(sb, 0f, 0f, previewPaint)
        l.dirty = true
        strokeCanvas?.drawColor(0, PorterDuff.Mode.CLEAR)
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- borracha
    private fun startErase(x: Float, y: Float) {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        pendingSnap = Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true))
        erasing = true
        smX = x
        smY = y
        lastX = x
        lastY = y
        val c = Canvas(l.bmp)
        val p = erasePaint(brushSize)
        c.drawPoint(x, y, p)
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawPoint(fw - x, y, p)
        if (symmetry == 2 || symmetry == 3) c.drawPoint(x, fh - y, p)
        if (symmetry == 3) c.drawPoint(fw - x, fh - y, p)
        invalidate()
    }

    private fun continueErase(x: Float, y: Float) {
        val l = layers[current]
        val k = smoothK()
        smX += (x - smX) * k
        smY += (y - smY) * k
        val dx = smX - lastX
        val dy = smY - lastY
        if (dx * dx + dy * dy < 0.6f) return
        drawSegment(Canvas(l.bmp), erasePaint(brushSize), lastX, lastY, smX, smY)
        lastX = smX
        lastY = smY
        invalidate()
    }

    private fun flushErase(x: Float, y: Float) {
        val l = layers[current]
        drawSegment(Canvas(l.bmp), erasePaint(brushSize), lastX, lastY, x, y)
    }

    private fun finishErase() {
        erasing = false
        val s = pendingSnap
        pendingSnap = null
        if (s != null) {
            s.layer.dirty = true
            addUndo(s)
        }
        invalidate()
        onCommit?.invoke()
    }

    // ----------------------------------------------------------------- formas
    private fun shapePaint(): Paint {
        val p = strokePaint
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color or 0xFF000000.toInt()
        p.strokeWidth = brushSize
        p.alpha = opacity
        return p
    }

    private fun drawShape(c: Canvas, p: Paint) {
        val l = minOf(sx, ex)
        val t = minOf(sy, ey)
        val r = maxOf(sx, ex)
        val b = maxOf(sy, ey)
        when (tool) {
            T_LINE -> c.drawLine(sx, sy, ex, ey, p)
            T_RECT -> c.drawRect(l, t, r, b, p)
            else -> c.drawOval(RectF(l, t, r, b), p)
        }
    }

    private fun commitShape() {
        shaping = false
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        drawShape(Canvas(l.bmp), shapePaint())
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    // ------------------------------------------------------------------ balde
    private fun fillAt(x: Float, y: Float) {
        val xi = x.toInt()
        val yi = y.toInt()
        if (xi < 0 || yi < 0 || xi >= docW || yi >= docH) return
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        val fc = Color.argb(opacity, Color.red(color), Color.green(color), Color.blue(color))
        floodFill(l.bmp, xi, yi, fc, 40)
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    private fun floodFill(bmp: Bitmap, startX: Int, startY: Int, fillColor: Int, tol: Int) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[startY * w + startX]
        val tA = Color.alpha(target)
        val tR = Color.red(target)
        val tG = Color.green(target)
        val tB = Color.blue(target)
        val visited = BooleanArray(w * h)

        fun close(c: Int): Boolean {
            return Math.abs(Color.alpha(c) - tA) <= tol &&
                Math.abs(Color.red(c) - tR) <= tol &&
                Math.abs(Color.green(c) - tG) <= tol &&
                Math.abs(Color.blue(c) - tB) <= tol
        }

        val stack = java.util.ArrayDeque<Int>()
        stack.push(startY * w + startX)
        while (stack.isNotEmpty()) {
            val pos = stack.pop()
            val y = pos / w
            val x0 = pos % w
            if (visited[pos] || !close(px[pos])) continue
            var xl = x0
            while (xl > 0 && !visited[y * w + xl - 1] && close(px[y * w + xl - 1])) xl--
            var xr = x0
            while (xr < w - 1 && !visited[y * w + xr + 1] && close(px[y * w + xr + 1])) xr++
            var up = false
            var down = false
            for (x in xl..xr) {
                val i = y * w + x
                visited[i] = true
                px[i] = fillColor
                if (y > 0) {
                    val j = i - w
                    val okUp = !visited[j] && close(px[j])
                    if (okUp && !up) {
                        stack.push(j)
                        up = true
                    } else if (!okUp) {
                        up = false
                    }
                }
                if (y < h - 1) {
                    val j = i + w
                    val okDown = !visited[j] && close(px[j])
                    if (okDown && !down) {
                        stack.push(j)
                        down = true
                    } else if (!okDown) {
                        down = false
                    }
                }
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    // ----------------------------------------------------------- conta-gotas
    private fun renderFlat(target: Bitmap) {
        target.eraseColor(Color.TRANSPARENT)
        val c = Canvas(target)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        for (l in layers) {
            if (!l.visible) continue
            applyLayerPaint(l, p)
            c.drawBitmap(l.bmp, 0f, 0f, p)
        }
    }

    private fun pick(x: Float, y: Float) {
        val xi = x.toInt()
        val yi = y.toInt()
        if (xi < 0 || yi < 0 || xi >= docW || yi >= docH) return
        var fb = flatBmp
        if (fb == null) {
            fb = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
            flatBmp = fb
        }
        renderFlat(fb)
        val c = fb.getPixel(xi, yi)
        val result = if (Color.alpha(c) == 0) Color.WHITE else (c or 0xFF000000.toInt())
        onPick?.invoke(result)
    }

    /** Todas as camadas visíveis num único bitmap (PNG com transparência). */
    fun flatten(): Bitmap {
        val b = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        renderFlat(b)
        return b
    }

    /** Versão reduzida sobre fundo branco (miniaturas e quadros do timelapse). */
    fun renderSmall(w: Int, h: Int): Bitmap? {
        return try {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.drawColor(Color.WHITE)
            c.scale(w.toFloat() / docW, h.toFloat() / docH)
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            for (l in layers) {
                if (!l.visible) continue
                applyLayerPaint(l, p)
                c.drawBitmap(l.bmp, 0f, 0f, p)
            }
            b
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Cópia das camadas alteradas, para gravar em segundo plano sem travar o desenho. */
    fun snapshot(): List<SaveLayer> {
        val out = ArrayList<SaveLayer>()
        for (l in layers) {
            val copy = if (l.dirty) l.bmp.copy(Bitmap.Config.ARGB_8888, false) else null
            out.add(SaveLayer(l.uid, l.name, l.visible, l.opacity, l.blend, copy))
            l.dirty = false
        }
        return out
    }

    // ---------------------------------------------------------------- histórico
    private fun pushUndo() {
        if (current < 0 || current >= layers.size) return
        val l = layers[current]
        addUndo(Snap(l, l.bmp.copy(Bitmap.Config.ARGB_8888, true)))
    }

    private fun addUndo(s: Snap) {
        undoList.add(s)
        while (undoList.size > maxUndo) {
            val old = undoList.removeAt(0)
            old.bmp.recycle()
        }
        for (r in redoList) r.bmp.recycle()
        redoList.clear()
        onHistoryChanged?.invoke()
    }

    fun canUndo(): Boolean = undoList.isNotEmpty()
    fun canRedo(): Boolean = redoList.isNotEmpty()

    fun undo() {
        if (transforming) cancelTransform()
        while (undoList.isNotEmpty()) {
            val s = undoList.removeAt(undoList.size - 1)
            if (!layers.contains(s.layer)) {
                s.bmp.recycle()
                continue
            }
            redoList.add(Snap(s.layer, s.layer.bmp))
            s.layer.bmp = s.bmp
            s.layer.dirty = true
            break
        }
        invalidate()
        onHistoryChanged?.invoke()
        onCommit?.invoke()
    }

    fun redo() {
        if (transforming) cancelTransform()
        while (redoList.isNotEmpty()) {
            val s = redoList.removeAt(redoList.size - 1)
            if (!layers.contains(s.layer)) {
                s.bmp.recycle()
                continue
            }
            undoList.add(Snap(s.layer, s.layer.bmp))
            s.layer.bmp = s.bmp
            s.layer.dirty = true
            break
        }
        invalidate()
        onHistoryChanged?.invoke()
        onCommit?.invoke()
    }

    // ------------------------------------------------------------------ camadas
    fun selectLayer(i: Int) {
        if (transforming) applyTransform()
        current = i.coerceIn(0, maxOf(0, layers.size - 1))
        invalidate()
    }

    fun addLayer(): Boolean {
        if (transforming) applyTransform()
        if (layers.size >= MAX_LAYERS) return false
        val b = Bitmap.createBitmap(docW, docH, Bitmap.Config.ARGB_8888)
        layerCounter++
        val at = minOf(current + 1, layers.size)
        layers.add(at, Layer(b, true, "Camada $layerCounter", nextUid()))
        current = at
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun duplicateCurrent(): Boolean {
        if (transforming) applyTransform()
        if (layers.size >= MAX_LAYERS || current < 0 || current >= layers.size) return false
        val src = layers[current]
        val copy = Layer(src.bmp.copy(Bitmap.Config.ARGB_8888, true), src.visible, src.name + " cópia", nextUid())
        copy.opacity = src.opacity
        copy.blend = src.blend
        layers.add(current + 1, copy)
        current += 1
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun removeCurrent(): Boolean {
        if (transforming) cancelTransform()
        if (layers.size <= 1) return false
        val l = layers.removeAt(current)
        l.bmp.recycle()
        current = maxOf(0, current - 1)
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun clearCurrent() {
        if (transforming) cancelTransform()
        if (current < 0 || current >= layers.size) return
        pushUndo()
        val l = layers[current]
        if (current == 0) l.bmp.eraseColor(bgColor) else l.bmp.eraseColor(Color.TRANSPARENT)
        l.dirty = true
        invalidate()
        onCommit?.invoke()
    }

    fun mergeDown(): Boolean {
        if (transforming) applyTransform()
        if (current <= 0 || current >= layers.size) return false
        val top = layers[current]
        val below = layers[current - 1]
        if (top.visible) {
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            applyLayerPaint(top, p)
            Canvas(below.bmp).drawBitmap(top.bmp, 0f, 0f, p)
            below.dirty = true
        }
        layers.removeAt(current)
        top.bmp.recycle()
        current -= 1
        invalidate()
        onCommit?.invoke()
        return true
    }

    fun moveCurrent(up: Boolean) {
        if (transforming) applyTransform()
        val j = if (up) current + 1 else current - 1
        if (j < 0 || j >= layers.size) return
        val tmp = layers[current]
        layers[current] = layers[j]
        layers[j] = tmp
        current = j
        invalidate()
        onCommit?.invoke()
    }

    /** Chamada depois de mudar opacidade, mistura, nome ou visibilidade de uma camada. */
    fun layerChanged() {
        invalidate()
        onCommit?.invoke()
    }

    // --------------------------------------------------------------- desenho
    private fun drawGrid(c: Canvas) {
        val s = currentScale()
        gridPaint.strokeWidth = 1f / s
        gridPaint.color = 0x55888888
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        val step = fw / 12f
        var x = step
        while (x < fw) {
            c.drawLine(x, 0f, x, fh, gridPaint)
            x += step
        }
        var y = step
        while (y < fh) {
            c.drawLine(0f, y, fw, y, gridPaint)
            y += step
        }
        gridPaint.color = 0xAAE53935.toInt()
        gridPaint.strokeWidth = 2f / s
        c.drawLine(fw / 2f, 0f, fw / 2f, fh, gridPaint)
        c.drawLine(0f, fh / 2f, fw, fh / 2f, gridPaint)
    }

    private fun drawSymmetryAxes(c: Canvas) {
        val s = currentScale()
        gridPaint.strokeWidth = 2f / s
        gridPaint.color = 0xCC00E5FF.toInt()
        val fw = docW.toFloat()
        val fh = docH.toFloat()
        if (symmetry == 1 || symmetry == 3) c.drawLine(fw / 2f, 0f, fw / 2f, fh, gridPaint)
        if (symmetry == 2 || symmetry == 3) c.drawLine(0f, fh / 2f, fw, fh / 2f, gridPaint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF1B1B1B.toInt())
        if (layers.isEmpty()) return
        canvas.save()
        canvas.concat(m)
        docRect.set(0f, 0f, docW.toFloat(), docH.toFloat())
        canvas.drawRect(docRect, checkerPaint)

        val sc = canvas.saveLayer(docRect, null)
        for (i in layers.indices) {
            val l = layers[i]
            if (!l.visible) continue
            applyLayerPaint(l, layerPaint)
            if (transforming && i == current) {
                canvas.save()
                canvas.concat(tMatrix)
                canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
                canvas.restore()
            } else {
                canvas.drawBitmap(l.bmp, 0f, 0f, layerPaint)
            }
            if (stroking && i == current) {
                val sb = strokeBmp
                if (sb != null) {
                    previewPaint.alpha = commitAlpha()
                    canvas.drawBitmap(sb, 0f, 0f, previewPaint)
                }
            }
        }
        canvas.restoreToCount(sc)

        if (shaping) drawShape(canvas, shapePaint())
        if (showGrid) drawGrid(canvas)
        if (symmetry != 0) drawSymmetryAxes(canvas)
        canvas.drawRect(docRect, borderPaint)
        canvas.restore()
    }
}
