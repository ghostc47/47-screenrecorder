package com.recorder47

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** 47 Voice Rec Mode: gravador de voz que continua com a tela desligada. */
class VoiceService : Service() {

    companion object {
        const val ACTION_START = "com.recorder47.VOICE_START"
        const val ACTION_PAUSE = "com.recorder47.VOICE_PAUSE"
        const val ACTION_STOP = "com.recorder47.VOICE_STOP"
        private const val CHANNEL_ID = "rec47"
        private const val NOTIF_ID = 48
        private const val WAV_RATE = 44100

        /** 0 parado, 1 gravando, 2 pausado */
        @Volatile var state = 0
        @Volatile var amp = 0
        @Volatile private var accumMs = 0L
        @Volatile private var segStart = 0L

        fun elapsedMs(): Long {
            return if (state == 1) accumMs + (SystemClock.elapsedRealtime() - segStart) else accumMs
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var fmt = 0
    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null

    // WAV
    private var wavRec: AudioRecord? = null
    private var wavOut: FileOutputStream? = null
    private var wavThread: Thread? = null
    @Volatile private var wavRunning = false
    @Volatile private var wavPaused = false
    @Volatile private var wavBytes = 0L

    private val ampTick = object : Runnable {
        override fun run() {
            if (state == 0) return
            if (state == 1 && fmt != 3) {
                try {
                    amp = recorder?.maxAmplitude ?: 0
                } catch (_: Exception) { }
            }
            handler.postDelayed(this, 80)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startAsForeground()
                if (state == 0) startRec(-1)
            }
            ACTION_PAUSE -> togglePause()
            ACTION_STOP -> stopRec()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação", NotificationManager.IMPORTANCE_LOW)
        )
        val pause = PendingIntent.getService(
            this, 11,
            Intent(this, VoiceService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 12,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("47 Voice Rec Mode")
            .setContentText("Gravando voz…")
            .setOngoing(true)
            .addAction(0, "Pausar/Retomar", pause)
            .addAction(0, "Parar", stop)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun startRec(forceFmt: Int) {
        fmt = if (forceFmt >= 0) forceFmt else Prefs.voiceFmt(this)
        val ts = System.currentTimeMillis()
        val ext = when (fmt) {
            0 -> "m4a"
            1 -> "ogg"
            2 -> "3gp"
            else -> "wav"
        }
        val mime = when (fmt) {
            0 -> "audio/mp4"
            1 -> "audio/ogg"
            2 -> "audio/3gpp"
            else -> "audio/x-wav"
        }
        try {
            val values = ContentValues()
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, "47Voice_$ts.$ext")
            values.put(MediaStore.Audio.Media.MIME_TYPE, mime)
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/47 Voice")
            values.put(MediaStore.Audio.Media.IS_PENDING, 1)
            uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            val u = uri ?: throw IllegalStateException("sem uri")
            pfd = contentResolver.openFileDescriptor(u, "rw")

            if (fmt == 3) startWav() else startMediaRecorder()

            accumMs = 0L
            segStart = SystemClock.elapsedRealtime()
            amp = 0
            state = 1
            handler.post(ampTick)
        } catch (e: Exception) {
            releaseAll(true)
            state = 0
            if (fmt != 0) {
                Toast.makeText(this, "Formato indisponível neste aparelho. Usando M4A.", Toast.LENGTH_LONG).show()
                startRec(0)
            } else {
                Toast.makeText(this, "Não foi possível gravar a voz.", Toast.LENGTH_LONG).show()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startMediaRecorder() {
        val r: MediaRecorder = if (Build.VERSION.SDK_INT >= 31) {
            MediaRecorder(this)
        } else {
            MediaRecorder()
        }
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        when (fmt) {
            0 -> {
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(Prefs.voiceKbps(this) * 1000)
                r.setAudioSamplingRate(44100)
            }
            1 -> {
                r.setOutputFormat(MediaRecorder.OutputFormat.OGG)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
                r.setAudioEncodingBitRate(Prefs.voiceKbps(this) * 1000)
                r.setAudioSamplingRate(48000)
            }
            else -> {
                r.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_WB)
                r.setAudioEncodingBitRate(23850)
                r.setAudioSamplingRate(16000)
            }
        }
        r.setAudioChannels(1)
        r.setOutputFile(pfd!!.fileDescriptor)
        recorder = r
        r.prepare()
        r.start()
    }

    @SuppressLint("MissingPermission")
    private fun startWav() {
        val minBuf = AudioRecord.getMinBufferSize(
            WAV_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, WAV_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, 8192) * 2
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("microfone indisponível")
        }
        val out = FileOutputStream(pfd!!.fileDescriptor)
        out.write(ByteArray(44))          // cabeçalho provisório
        wavRec = rec
        wavOut = out
        wavBytes = 0L
        wavPaused = false
        wavRunning = true
        rec.startRecording()
        val t = Thread({
            val buf = ShortArray(2048)
            val bytes = ByteArray(4096)
            while (wavRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                var mx = 0
                for (i in 0 until n) {
                    val v = buf[i].toInt()
                    val a = if (v < 0) -v else v
                    if (a > mx) mx = a
                }
                amp = mx
                if (wavPaused) continue
                for (i in 0 until n) {
                    val v = buf[i].toInt()
                    bytes[2 * i] = (v and 0xFF).toByte()
                    bytes[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
                }
                try {
                    out.write(bytes, 0, n * 2)
                    wavBytes += (n * 2).toLong()
                } catch (e: Exception) {
                    break
                }
            }
        }, "47-wav")
        wavThread = t
        t.start()
    }

    private fun wavHeader(dataLen: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray())
        b.putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray())
        b.putInt(16)
        b.putShort(1.toShort())                 // PCM
        b.putShort(1.toShort())                 // mono
        b.putInt(WAV_RATE)
        b.putInt(WAV_RATE * 2)
        b.putShort(2.toShort())
        b.putShort(16.toShort())
        b.put("data".toByteArray())
        b.putInt(dataLen.toInt())
        return b.array()
    }

    private fun finishWav() {
        wavRunning = false
        try { wavThread?.join(2000) } catch (_: Exception) { }
        try { wavRec?.stop() } catch (_: Exception) { }
        try { wavRec?.release() } catch (_: Exception) { }
        wavRec = null
        val out = wavOut
        if (out != null) {
            try {
                out.flush()
                val ch = out.channel
                ch.position(0)
                ch.write(ByteBuffer.wrap(wavHeader(wavBytes)))
            } catch (_: Exception) { }
        }
        wavOut = null    // o descritor é fechado junto com o pfd
    }

    private fun togglePause() {
        if (state == 1) {
            accumMs += SystemClock.elapsedRealtime() - segStart
            if (fmt == 3) {
                wavPaused = true
            } else {
                try { recorder?.pause() } catch (_: Exception) { }
            }
            amp = 0
            state = 2
        } else if (state == 2) {
            segStart = SystemClock.elapsedRealtime()
            if (fmt == 3) {
                wavPaused = false
            } else {
                try { recorder?.resume() } catch (_: Exception) { }
            }
            state = 1
        }
    }

    private fun stopRec() {
        if (state == 0) {
            stopSelf()
            return
        }
        state = 0
        handler.removeCallbacks(ampTick)
        if (fmt == 3) {
            finishWav()
        } else {
            try { recorder?.stop() } catch (_: Exception) { }
            try { recorder?.release() } catch (_: Exception) { }
            recorder = null
        }
        try { pfd?.close() } catch (_: Exception) { }
        pfd = null
        val u = uri
        if (u != null) {
            val v = ContentValues()
            v.put(MediaStore.Audio.Media.IS_PENDING, 0)
            try { contentResolver.update(u, v, null, null) } catch (_: Exception) { }
        }
        uri = null
        accumMs = 0L
        amp = 0
        Toast.makeText(this, "Voz salva em Music/47 Voice", Toast.LENGTH_LONG).show()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseAll(deleteFile: Boolean) {
        handler.removeCallbacks(ampTick)
        wavRunning = false
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
        try { wavRec?.release() } catch (_: Exception) { }
        wavRec = null
        wavOut = null
        try { pfd?.close() } catch (_: Exception) { }
        pfd = null
        val u = uri
        if (deleteFile && u != null) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
        }
        uri = null
    }

    override fun onDestroy() {
        if (state != 0) stopRec()
        super.onDestroy()
    }
}
