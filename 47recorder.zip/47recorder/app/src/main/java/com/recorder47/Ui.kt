package com.recorder47

import android.content.Context
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

object Ui {
    // Paleta moderna padrão: preto profundo + vermelho elétrico
    var accent = 0xFFFF2D55.toInt()
    var bg = 0xFF0A0A0C.toInt()
    var card = 0xFF16161A.toInt()
    var chip = 0xFF24242A.toInt()
    var div = 0xFF2A2A32.toInt()
    var gap = 0xFF050506.toInt()
    var barDark = 0xFFB71C1C.toInt()
    val txt = 0xFFF5F5F7.toInt()
    val sub = 0xFF8E8E96.toInt()
    var radius = 18
    var scale = 1f

    fun load(c: Context) {
        accent = Prefs.uiAccent(c)
        bg = Prefs.uiBg(c)
        val white = 0xFFFFFFFF.toInt()
        val black = 0xFF000000.toInt()
        val cardMode = Prefs.uiCard(c)
        val cardBlend = when (cardMode) {
            1 -> 0.14f
            2 -> 0.04f
            else -> 0.08f
        }
        card = ColorUtils.blendARGB(bg, white, cardBlend)
        chip = ColorUtils.blendARGB(bg, white, if (cardMode == 1) 0.22f else 0.16f)
        div = ColorUtils.blendARGB(bg, white, 0.10f)
        gap = ColorUtils.blendARGB(bg, black, 0.55f)
        barDark = when (Prefs.uiBarStyle(c)) {
            1 -> ColorUtils.blendARGB(bg, black, 0.35f)
            2 -> bg
            else -> ColorUtils.blendARGB(accent, black, 0.25f)
        }
        radius = Prefs.uiRadius(c)
        scale = when (Prefs.uiScale(c)) {
            0 -> 0.9f
            2 -> 1.15f
            else -> 1f
        }
    }

    /** Fundo do botão 47: kind 0 = círculo, 1 = quadrado arredondado. */
    fun orbDrawable(color: Int, kind: Int, sizePx: Int): GradientDrawable {
        val d = GradientDrawable()
        if (kind == 1) {
            d.shape = GradientDrawable.RECTANGLE
            d.cornerRadius = sizePx * 0.28f
        } else {
            d.shape = GradientDrawable.OVAL
        }
        d.setColor(color)
        return d
    }

    /** Card arredondado moderno. */
    fun cardDrawable(color: Int = card, r: Int = radius): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r.toFloat()
            setColor(color)
        }
    }

    /** Botão/pill com cantos bem arredondados. */
    fun pillDrawable(color: Int, r: Float = 28f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
            setColor(color)
        }
    }

    /** Gradiente vertical sutil para FABs e CTAs. */
    fun gradientButton(top: Int, bottom: Int, r: Float): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(top, bottom)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
        }
    }

    /** Círculo com leve gradiente. */
    fun ovalGradient(top: Int, bottom: Int): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(top, bottom)
        ).apply {
            shape = GradientDrawable.OVAL
        }
    }

    fun lighten(color: Int, amount: Float = 0.12f): Int =
        ColorUtils.blendARGB(color, 0xFFFFFFFF.toInt(), amount)

    fun darken(color: Int, amount: Float = 0.2f): Int =
        ColorUtils.blendARGB(color, 0xFF000000.toInt(), amount)
}
