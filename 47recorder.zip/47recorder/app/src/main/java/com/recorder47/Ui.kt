package com.recorder47

import android.content.Context
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

object Ui {
    var accent = 0xFFE53935.toInt()
    var bg = 0xFF0E0E0E.toInt()
    var card = 0xFF1A1A1A.toInt()
    var chip = 0xFF2A2A2A.toInt()
    var div = 0xFF2B2B2B.toInt()
    var gap = 0xFF050505.toInt()
    var barDark = 0xFFB71C1C.toInt()
    val txt = 0xFFFFFFFF.toInt()
    val sub = 0xFF9A9A9A.toInt()
    var radius = 16
    var scale = 1f

    fun load(c: Context) {
        accent = Prefs.uiAccent(c)
        bg = Prefs.uiBg(c)
        val white = 0xFFFFFFFF.toInt()
        val black = 0xFF000000.toInt()
        card = ColorUtils.blendARGB(bg, white, 0.06f)
        chip = ColorUtils.blendARGB(bg, white, 0.14f)
        div = ColorUtils.blendARGB(bg, white, 0.12f)
        gap = ColorUtils.blendARGB(bg, black, 0.5f)
        barDark = ColorUtils.blendARGB(accent, black, 0.3f)
        radius = Prefs.uiRadius(c)
        scale = when (Prefs.uiScale(c)) {
            0 -> 0.9f
            2 -> 1.15f
            else -> 1f
        }
    }

    /** Fundo do botão 47: kind 0 = círculo, 1 = quadrado arredondado. */
    fun orbDrawable(color: Int, kind: Int, sizePx: Int): GradientDrawable {
        val d = GradientDrawable()
        if (kind == 1) {
            d.shape = GradientDrawable.RECTANGLE
            d.cornerRadius = sizePx * 0.28f
        } else {
            d.shape = GradientDrawable.OVAL
        }
        d.setColor(color)
        return d
    }
}
