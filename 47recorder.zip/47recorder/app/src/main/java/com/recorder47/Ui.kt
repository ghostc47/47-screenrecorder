package com.recorder47

import android.content.Context
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

/**
 * Tema global do 47 Recorder — alinhado ao visual do Art Mode (AU).
 * Fundo profundo, surfaces discretas, accent compartilhado.
 */
object Ui {
    // Defaults alinhados ao Art Mode (AU.bg / surface / text)
    var accent = 0xFFFF2D55.toInt()
    var bg = 0xFF0E0E12.toInt()
    var card = 0xFF18181E.toInt()       // ~ AU.sheet
    var chip = 0xFF23232B.toInt()       // ~ AU.surface
    var div = 0xFF2D2D37.toInt()        // ~ AU.surface2
    var gap = 0xFF08080A.toInt()
    var barDark = 0xFF18181E.toInt()
    val txt = 0xFFF4F4F7.toInt()        // AU.text
    val sub = 0xFF9A9AA8.toInt()        // AU.sub
    var radius = 18
    var scale = 1f

    // Glass do Art Mode (para docks / painéis flutuantes)
    val glass = 0xEB17171D.toInt()
    val glassLine = 0x2EFFFFFF

    fun load(c: Context) {
        accent = Prefs.uiAccent(c)
        bg = Prefs.uiBg(c)
        val white = 0xFFFFFFFF.toInt()
        val black = 0xFF000000.toInt()
        val cardMode = Prefs.uiCard(c)
        // Blends pensados para ficar perto de AU.sheet / surface
        val cardBlend = when (cardMode) {
            1 -> 0.12f   // mais claro
            2 -> 0.03f   // mais escuro
            else -> 0.06f
        }
        card = ColorUtils.blendARGB(bg, white, cardBlend)
        chip = ColorUtils.blendARGB(bg, white, if (cardMode == 1) 0.18f else 0.12f)
        div = ColorUtils.blendARGB(bg, white, 0.16f)
        gap = ColorUtils.blendARGB(bg, black, 0.45f)
        barDark = when (Prefs.uiBarStyle(c)) {
            1 -> ColorUtils.blendARGB(bg, black, 0.28f)
            2 -> bg
            else -> ColorUtils.blendARGB(card, black, 0.08f) // barra superior dark (estilo Art Mode)
        }
        radius = Prefs.uiRadius(c)
        scale = when (Prefs.uiScale(c)) {
            0 -> 0.9f
            2 -> 1.15f
            else -> 1f
        }
    }

    /** Fundo do botão 47: kind 0 = círculo, 1 = quadrado arredondado. */
    fun orbDrawable(color: Int, kind: Int, sizePx: Int): GradientDrawable {
        val d = GradientDrawable()
        if (kind == 1) {
            d.shape = GradientDrawable.RECTANGLE
            d.cornerRadius = sizePx * 0.28f
        } else {
            d.shape = GradientDrawable.OVAL
        }
        d.setColor(color)
        return d
    }

    /** Card arredondado (surface do Art Mode). */
    fun cardDrawable(color: Int = card, r: Int = radius): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r.toFloat()
            setColor(color)
        }
    }

    /** Card com borda sutil (estilo glass do Art Mode). */
    fun glassCard(r: Int = radius, fill: Int = glass): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r.toFloat()
            setColor(fill)
            setStroke(1, glassLine)
        }
    }

    /** Botão/pill com cantos bem arredondados. */
    fun pillDrawable(color: Int, r: Float = 28f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
            setColor(color)
        }
    }

    /** Gradiente vertical sutil para FABs e CTAs. */
    fun gradientButton(top: Int, bottom: Int, r: Float): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(top, bottom)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
        }
    }

    /** Círculo com leve gradiente. */
    fun ovalGradient(top: Int, bottom: Int): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(top, bottom)
        ).apply {
            shape = GradientDrawable.OVAL
        }
    }

    fun lighten(color: Int, amount: Float = 0.12f): Int =
        ColorUtils.blendARGB(color, 0xFFFFFFFF.toInt(), amount)

    fun darken(color: Int, amount: Float = 0.2f): Int =
        ColorUtils.blendARGB(color, 0xFF000000.toInt(), amount)

    /** Accent com alpha (para highlights suaves). */
    fun accentSoft(alpha: Int = 0x2E): Int =
        (accent and 0x00FFFFFF) or (alpha shl 24)
}
