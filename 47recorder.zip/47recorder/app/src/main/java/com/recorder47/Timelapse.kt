package com.recorder47

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Guarda "fotos" do desenho a cada edição e, depois, monta um vídeo em time-lapse.
 * No máximo 400 quadros ficam guardados (os mais antigos são afinados automaticamente).
 */
class Timelapse(private val dir: File) {

    private val files = ArrayList<File>()
    private var stride = 1
    private var counter = 0
    private var seq = 0
    private val exec: ExecutorService = Executors.newSingleThreadExecutor()

    init {
        dir.mkdirs()
        val found = dir.listFiles()
        if (found != null) {
            val sorted = found
                .filter { it.name.startsWith("f_") && it.name.endsWith(".jpg") }
                .sortedBy { numOf(it) }
            files.addAll(sorted)
            if (sorted.isNotEmpty()) seq = numOf(sorted[sorted.size - 1]) + 1
        }
    }

    private fun numOf(f: File): Int = f.name.removePrefix("f_").removeSuffix(".jpg").toIntOrNull() ?: 0

    fun frameCount(): Int = files.size

    fun capture(art: ArtCanvas) {
        counter++
        if (counter % stride != 0) return
        val w = 540
        val h = maxOf(1, (540f * art.docH / art.docW).toInt())
        val bmp = art.renderSmall(w, h) ?: return
        val f = File(dir, "f_${seq++}.jpg")
        files.add(f)
        if (files.size >= 400) thin()
        exec.execute {
            try {
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            } catch (_: Exception) { }
            bmp.recycle()
        }
    }

    /** Mantém só um quadro a cada dois e passa a guardar com metade da frequência. */
    private fun thin() {
        val keep = ArrayList<File>()
        for (i in files.indices) {
            val f = files[i]
            if (i % 2 == 0) {
                keep.add(f)
            } else {
                exec.execute { f.delete() }
            }
        }
        files.clear()
        files.addAll(keep)
        stride *= 2
    }

    fun filesSnapshot(): List<File> = ArrayList(files)

    /** Espera todas as gravações pendentes terminarem. */
    fun flush() {
        try {
            exec.submit(Runnable { }).get()
        } catch (_: Exception) { }
    }

    companion object {
        /** Gera o vídeo. Deve rodar fora da thread principal (leva o tempo do próprio vídeo). */
        fun exportVideo(
            ctx: Context, frames: List<File>, finalFrame: Bitmap, docW: Int, docH: Int,
            onProgress: (Int) -> Unit, isCancelled: () -> Boolean
        ): Boolean {
            var uri: Uri? = null
            var pfd: ParcelFileDescriptor? = null
            var enc: MediaCodec? = null
            var mux: MediaMuxer? = null
            var surfRef: Surface? = null
            var ok = false
            try {
                val vw = 720
                var vh = Math.round(720f * docH / docW / 16f) * 16
                if (vh < 160) vh = 160
                if (vh > 1440) vh = 1440
                val fps = 12
                val maxFrames = 150
                val picked = ArrayList<File>()
                if (frames.size <= maxFrames) {
                    picked.addAll(frames)
                } else {
                    val step = frames.size.toFloat() / maxFrames
                    for (i in 0 until maxFrames) picked.add(frames[(i * step).toInt()])
                }

                val values = ContentValues()
                values.put(MediaStore.Video.Media.DISPLAY_NAME, "47Timelapse_${System.currentTimeMillis()}.mp4")
                values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/47 Art")
                values.put(MediaStore.Video.Media.IS_PENDING, 1)
                uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                val u = uri ?: throw IllegalStateException("sem uri")
                pfd = ctx.contentResolver.openFileDescriptor(u, "rw")
                val fd = pfd ?: throw IllegalStateException("sem descritor")

                val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh)
                format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                format.setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
                format.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                enc = e
                e.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surf = e.createInputSurface()
                surfRef = surf
                e.start()
                val m = MediaMuxer(fd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                mux = m
                val info = MediaCodec.BufferInfo()
                var track = -1
                var started = false

                fun drain(end: Boolean) {
                    var idle = 0
                    while (true) {
                        val i = e.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                        if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                            if (!end) break
                            idle++
                            if (idle > 300) break
                        } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            track = m.addTrack(e.outputFormat)
                            m.start()
                            started = true
                        } else if (i >= 0) {
                            val ob = e.getOutputBuffer(i)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && started) {
                                ob.position(info.offset)
                                ob.limit(info.offset + info.size)
                                m.writeSampleData(track, ob, info)
                            }
                            e.releaseOutputBuffer(i, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                        }
                    }
                }

                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                val dst = RectF(0f, 0f, vw.toFloat(), vh.toFloat())
                fun post(b: Bitmap) {
                    val c = surf.lockCanvas(null)
                    try {
                        c.drawColor(Color.WHITE)
                        c.drawBitmap(b, null, dst, paint)
                    } finally {
                        surf.unlockCanvasAndPost(c)
                    }
                    drain(false)
                    Thread.sleep(1000L / fps)
                }

                val holdFrames = 18
                val total = picked.size + holdFrames
                var n = 0
                for (f in picked) {
                    if (isCancelled()) throw IllegalStateException("cancelado")
                    val b = BitmapFactory.decodeFile(f.path)
                    if (b != null) {
                        post(b)
                        b.recycle()
                    }
                    n++
                    onProgress(n * 100 / total)
                }
                for (i in 0 until holdFrames) {
                    if (isCancelled()) throw IllegalStateException("cancelado")
                    post(finalFrame)
                    n++
                    onProgress(n * 100 / total)
                }
                e.signalEndOfInputStream()
                drain(true)
                ok = started
            } catch (ex: Exception) {
                ok = false
            } finally {
                try { enc?.stop() } catch (_: Exception) { }
                try { enc?.release() } catch (_: Exception) { }
                try { surfRef?.release() } catch (_: Exception) { }
                try { if (ok) mux?.stop() } catch (_: Exception) { ok = false }
                try { mux?.release() } catch (_: Exception) { }
                try { pfd?.close() } catch (_: Exception) { }
            }
            val u2 = uri
            if (u2 != null) {
                if (ok) {
                    val v = ContentValues()
                    v.put(MediaStore.Video.Media.IS_PENDING, 0)
                    try { ctx.contentResolver.update(u2, v, null, null) } catch (_: Exception) { }
                } else {
                    try { ctx.contentResolver.delete(u2, null, null) } catch (_: Exception) { }
                }
            }
            return ok
        }
    }
}
