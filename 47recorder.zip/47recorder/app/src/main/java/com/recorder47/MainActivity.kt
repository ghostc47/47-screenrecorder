package com.recorder47

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var micCheck: CheckBox
    private var useMic = false

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, RecorderService::class.java).apply {
                    action = RecorderService.ACTION_START
                    putExtra(RecorderService.EXTRA_CODE, result.resultCode)
                    putExtra(RecorderService.EXTRA_DATA, result.data)
                    putExtra(RecorderService.EXTRA_MIC, useMic)
                }
                startForegroundService(intent)
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Permissão de gravação negada", Toast.LENGTH_SHORT).show()
            }
        }

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it[Manifest.permission.RECORD_AUDIO] == true) askProjection()
            else Toast.makeText(this, "Permita o áudio para gravar", Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "47 Recorder"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "Grava a tela com o áudio interno do aparelho.\n" +
                "Um botão flutuante aparecerá para parar.\n" +
                "Vídeos ficam em Movies/47 Recorder."
            gravity = Gravity.CENTER
            setPadding(48, 24, 48, 24)
        }
        micCheck = CheckBox(this).apply { text = "Gravar também o microfone" }
        val start = Button(this).apply {
            text = "Iniciar gravação"
            setOnClickListener { begin() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(title)
            addView(hint)
            addView(micCheck)
            addView(start)
        })
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Ative a sobreposição e volte", Toast.LENGTH_LONG).show()
            return
        }
        useMic = micCheck.isChecked
        permissionsLauncher.launch(
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        )
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
