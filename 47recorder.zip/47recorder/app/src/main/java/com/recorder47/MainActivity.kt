package com.recorder47

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputFilter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val TAB_SET = 4
private const val MODE_VOICE = 10
private val WHITE = 0xFFFFFFFF.toInt()

class MainActivity : ComponentActivity() {

    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var tabIcons: List<TextView>
    private lateinit var tabInds: List<View>

    private var current = 0     // 0 Gravações, 1 Capturas, 2 Voz, 3 Ajustes
    private var page = 0        // 0 lista, 1 qualidade, 2 botão 47, 3 assinatura, 4 voltar no tempo, 5 voz, 6 aparência
    private var pendingMode = RecorderService.MODE_RECORD

    // Aba de voz
    private var voiceTime: TextView? = null
    private var voiceWave: WaveView? = null
    private var voiceMain: TextView? = null
    private var voiceStop: TextView? = null
    private var voiceStatus: TextView? = null
    private var lastVoiceState = 0
    private val tickHandler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateVoiceUi()
            tickHandler.postDelayed(this, 100)
        }
    }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(this, "Sem a permissão da câmera a webcam não aparece", Toast.LENGTH_LONG).show()
            }
        }

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            page = 0
            select(TAB_SET)
        }
    }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, RecorderService::class.java).apply {
                    action = RecorderService.ACTION_START
                    putExtra(RecorderService.EXTRA_CODE, result.resultCode)
                    putExtra(RecorderService.EXTRA_DATA, result.data)
                    putExtra(RecorderService.EXTRA_MIC, Prefs.mic(this@MainActivity))
                    putExtra(RecorderService.EXTRA_MODE, pendingMode)
                }
                startForegroundService(intent)
                finishAndRemoveTask()
            } else {
                Toast.makeText(this, "Permissão de captura negada", Toast.LENGTH_SHORT).show()
            }
        }

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val audioOk = res[Manifest.permission.RECORD_AUDIO] == true
            if (pendingMode == MODE_VOICE) {
                if (audioOk) {
                    startForegroundService(
                        Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_START)
                    )
                } else {
                    Toast.makeText(this, "Permita o microfone para gravar a voz", Toast.LENGTH_SHORT).show()
                }
            } else if (pendingMode == RecorderService.MODE_MENU || audioOk) {
                askProjection()
            } else {
                Toast.makeText(this, "Permita o áudio para gravar", Toast.LENGTH_SHORT).show()
            }
        }

    // ------------------------------------------------------------ helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, r: Int = Ui.radius) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size * Ui.scale
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top; bottomMargin = bottom }

    private fun LinearLayout.addRow(v: View) {
        addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(View(context).apply { setBackgroundColor(Ui.div) }, LinearLayout.LayoutParams(MATCH, 1))
    }

    private fun LinearLayout.addGap() {
        addView(View(context).apply { setBackgroundColor(Ui.gap) },
            LinearLayout.LayoutParams(MATCH, dp(12)))
    }

    private fun row(
        icon: String, title: String, value: String? = null,
        trailing: View? = null, onClick: (() -> Unit)? = null
    ): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setBackgroundColor(Ui.bg)
        }
        r.addView(label(icon, 18f, Ui.txt), LinearLayout.LayoutParams(dp(36), WRAP))
        r.addView(label(title, 15f, Ui.txt), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (value != null) r.addView(label(value, 15f, Ui.accent))
        if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(dp(28), dp(28)))
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    private fun header(title: String): View =
        label("‹  $title", 17f, Ui.txt, true).apply {
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setOnClickListener { page = 0; select(TAB_SET) }
        }

    private fun sectionTitle(t: String) =
        label(t, 14f, Ui.sub).apply { setPadding(dp(20), dp(16), dp(20), dp(8)) }

    private fun note(t: String) =
        label(t, 12f, Ui.sub).apply { setPadding(dp(20), dp(12), dp(20), dp(24)) }

    /** commitOnly = só aplica quando o dedo solta (evita recriar a tela durante o arraste). */
    private fun slider(max: Int, value: Int, commitOnly: Boolean = false, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            progress = value
            progressTintList = ColorStateList.valueOf(Ui.accent)
            thumbTintList = ColorStateList.valueOf(Ui.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!commitOnly) onChange(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    if (commitOnly) onChange(s?.progress ?: 0)
                }
            })
        }

    private fun chips(options: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(16), dp(16))
        }
        options.forEachIndexed { i, o ->
            val sel = i == selected
            val t = label(o, 14f, WHITE, sel).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                background = round(if (sel) Ui.accent else Ui.chip, 20)
                setOnClickListener { onPick(i) }
            }
            r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
        return r
    }

    private fun pill(text: String, onClick: () -> Unit) =
        label(text, 13f, WHITE, true).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = round(Ui.chip, 22)
            elevation = dp(4).toFloat()
            setOnClickListener { onClick() }
        }

    private fun onOff(b: Boolean) = if (b) "Ativado" else "Desativado"

    private fun colorPicker(initial: Int, commitOnly: Boolean, onPick: (Int) -> Unit): View {
        val ctx = this
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val presets = intArrayOf(
            0xFFE53935.toInt(), 0xFFB71C1C.toInt(), 0xFFFB8C00.toInt(), 0xFFFDD835.toInt(),
            0xFF43A047.toInt(), 0xFF00ACC1.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(),
            0xFFEC407A.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt()
        )
        val prow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (pc in presets) {
            val d = View(ctx).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(pc)
                    setStroke(dp(2), 0xFF666666.toInt())
                }
                setOnClickListener { onPick(pc) }
            }
            prow.addView(d, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        }
        box.addView(HorizontalScrollView(ctx).apply { addView(prow) }, lp(MATCH, WRAP, dp(8), dp(12)))

        val strip = View(ctx).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                    0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
                )
            ).apply { cornerRadius = dp(4).toFloat() }
        }
        box.addView(strip, lp(MATCH, dp(8)))
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        box.addView(slider(360, hsv[0].toInt(), commitOnly) { p ->
            onPick(Color.HSVToColor(floatArrayOf(p.toFloat(), 0.85f, 0.95f)))
        }, lp(MATCH, WRAP, 0, dp(8)))
        return box
    }

    // ------------------------------------------------------------- ciclo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.load(this)
        onBackPressedDispatcher.addCallback(this, backCb)

        content = FrameLayout(this)
        topBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val icons = mutableListOf<TextView>()
        val inds = mutableListOf<View>()
        listOf("🎬", "🖼️", "🎙️", "🎨", "⚙️").forEachIndexed { i, s ->
            val t = TextView(this).apply {
                text = s
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(WHITE)
                setPadding(0, dp(14), 0, dp(10))
            }
            val u = View(this)
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setOnClickListener { page = 0; select(i) }
            }
            cell.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            cell.addView(u, LinearLayout.LayoutParams(dp(28), dp(3)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            })
            topBar.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            icons.add(t)
            inds.add(u)
        }
        tabIcons = icons
        tabInds = inds

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(topBar, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        setContentView(rootLayout)
        applyChrome()
        select(0)
        handleAuto(intent)
    }

    /** Aberto pela notificação (ou pelo início automático): liga o círculo flutuante. */
    private fun handleAuto(i: Intent?) {
        if (i == null) return
        val auto = i.getStringExtra("auto")
        if (auto == "circle") {
            i.removeExtra("auto")
            try {
                getSystemService(NotificationManager::class.java).cancel(78)
            } catch (_: Exception) { }
            content.post { startMode(RecorderService.MODE_MENU) }
        }
    }

    private fun applyChrome() {
        Ui.load(this)
        window.statusBarColor = Ui.barDark
        window.navigationBarColor = Ui.bg
        topBar.setBackgroundColor(Ui.accent)
        rootLayout.setBackgroundColor(Ui.bg)
    }

    private fun restyle() {
        applyChrome()
        select(current)
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) select(current)
        tickHandler.removeCallbacks(tick)
        tickHandler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        tickHandler.removeCallbacks(tick)
    }

    private fun select(i: Int) {
        voiceTime = null
        voiceWave = null
        voiceMain = null
        voiceStop = null
        voiceStatus = null
        current = i
        backCb.isEnabled = (i == TAB_SET && page != 0)
        tabInds.forEachIndexed { k, v ->
            v.setBackgroundColor(if (k == i) WHITE else 0x00000000)
            tabIcons[k].alpha = if (k == i) 1f else 0.6f
        }
        content.removeAllViews()
        content.addView(
            when (i) {
                0 -> mediaView(0)
                1 -> mediaView(1)
                2 -> voiceView()
                3 -> artView()
                else -> when (page) {
                    1 -> qualityView()
                    2 -> orbView()
                    3 -> watermarkView()
                    4 -> replayView()
                    5 -> voiceFormatView()
                    6 -> appearanceView()
                    7 -> extrasView()
                    8 -> cameraView()
                    else -> settingsView()
                }
            }
        )
    }

    // ------------------------------------- Gravações, Capturas e lista de voz
    /** kind: 0 vídeos, 1 imagens, 2 áudios de voz. Retorna quantos itens foram listados. */
    private fun fillMedia(col: LinearLayout, kind: Int): Int {
        val collection: Uri = when (kind) {
            0 -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            1 -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val withDuration = kind != 1
        val cols = if (withDuration) arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION, MediaStore.MediaColumns.SIZE
        ) else arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE
        )
        val prefix = when (kind) {
            0 -> "Movies/47 Recorder%"
            1 -> "Pictures/47 Recorder%"
            else -> "Music/47 Voice%"
        }
        var count = 0
        try {
            contentResolver.query(
                collection, cols,
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf(prefix),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: "arquivo"
                    val dur = if (withDuration) c.getLong(2) else 0L
                    val size = c.getLong(if (withDuration) 3 else 2)
                    col.addRow(mediaRow(kind, id, name, dur, size))
                    count++
                }
            }
        } catch (_: Exception) { }
        return count
    }

    private fun mediaView(kind: Int): View {
        val root = FrameLayout(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(280))
        }
        val count = fillMedia(col, kind)
        if (count == 0) {
            val msg = if (kind == 0) "Nenhuma gravação ainda.\nToque em REC para gravar."
            else "Nenhuma captura ainda.\nAbra o círculo flutuante e toque em 📷 Tirar print."
            col.addView(label(msg, 14f, Ui.sub).apply {
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(80), dp(24), 0)
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        root.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(MATCH, MATCH))

        if (kind == 0) {
            val cluster = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            cluster.addView(pill("✏️ Desenhar") { startDraw() }, lp(WRAP, WRAP, 0, dp(10)))
            cluster.addView(pill("⏪ Voltar no tempo") { startMode(RecorderService.MODE_REPLAY) }, lp(WRAP, WRAP, 0, dp(14)))
            val fab = label("REC", 13f, WHITE, true).apply {
                gravity = Gravity.CENTER
                background = oval(Ui.accent)
                elevation = dp(8).toFloat()
                setOnClickListener { showRecChoice() }
            }
            cluster.addView(fab, LinearLayout.LayoutParams(dp(68), dp(68)))
            root.addView(cluster, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
                rightMargin = dp(20); bottomMargin = dp(24)
            })
        }
        return root
    }

    private fun mediaRow(kind: Int, id: Long, name: String, durMs: Long, size: Long): View {
        val base: Uri = when (kind) {
            0 -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            1 -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val uri = ContentUris.withAppendedId(base, id)
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Ui.bg)
        }
        if (kind == 2) {
            val icon = label("🎵", 24f, WHITE).apply {
                gravity = Gravity.CENTER
                background = round(Ui.chip, 14)
            }
            r.addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))
        } else {
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Ui.chip)
            }
            r.addView(thumb, LinearLayout.LayoutParams(dp(120), dp(72)))
            Thread {
                try {
                    val bmp = contentResolver.loadThumbnail(uri, Size(dp(240), dp(144)), null)
                    runOnUiThread { thumb.setImageBitmap(bmp) }
                } catch (_: Exception) { }
            }.start()
        }

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(name, 14f, Ui.txt, true))
        val mb = size / 1048576.0
        val line = if (kind == 1) {
            String.format("%.1f MB", mb)
        } else {
            val secs = durMs / 1000
            String.format("%d:%02d  •  %.1f MB", secs / 60, secs % 60, mb)
        }
        info.addView(label(line, 12f, Ui.sub), lp(WRAP, WRAP, dp(4)))
        r.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        val mimeType = when (kind) {
            0 -> "video/*"
            1 -> "image/*"
            else -> "audio/*"
        }
        r.setOnClickListener {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, mimeType)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Nenhum app encontrado para abrir", Toast.LENGTH_SHORT).show()
            }
        }
        r.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Excluir?")
                .setMessage(name)
                .setPositiveButton("Excluir") { _, _ ->
                    try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
                    select(current)
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
        return r
    }

    // ----------------------------------------------- 47 Voice Rec Mode
    private fun fmtTime(ms: Long): String {
        val t = ms / 100
        val tenth = t % 10
        val s = (t / 10) % 60
        val m = t / 600
        return String.format("%02d:%02d.%d", m, s, tenth)
    }

    private fun voiceView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        col.addView(label("47 Voice Rec Mode", 20f, Ui.txt, true).apply {
            setPadding(dp(20), dp(20), dp(20), dp(2))
        })
        col.addView(label("Gravador de voz — continua com a tela desligada", 12f, Ui.sub).apply {
            setPadding(dp(20), 0, dp(20), dp(8))
        })

        val time = label("00:00.0", 44f, Ui.txt, true).apply { gravity = Gravity.CENTER }
        col.addView(time, lp(MATCH, WRAP, dp(8), dp(8)))

        val wave = WaveView(ctx).apply { barColor = Ui.accent }
        col.addView(wave, lp(MATCH, dp(110), 0, dp(12)).apply { leftMargin = dp(16); rightMargin = dp(16) })

        val btns = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val stop = label("■", 22f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = oval(Ui.chip)
            setOnClickListener {
                startService(Intent(ctx, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            }
        }
        val main = label("●", 30f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = oval(Ui.accent)
            setOnClickListener { voiceMainCmd() }
        }
        btns.addView(stop, LinearLayout.LayoutParams(dp(60), dp(60)).apply { rightMargin = dp(24) })
        btns.addView(main, LinearLayout.LayoutParams(dp(84), dp(84)))
        btns.addView(View(ctx), LinearLayout.LayoutParams(dp(60), dp(60)).apply { leftMargin = dp(24) })
        col.addView(btns, lp(MATCH, WRAP))

        val status = label("Toque em ● para gravar", 13f, Ui.sub).apply { gravity = Gravity.CENTER }
        col.addView(status, lp(MATCH, WRAP, dp(12), dp(4)))
        val fmtNames = listOf("M4A", "OGG", "3GP", "WAV")
        col.addView(
            label("Formato: ${fmtNames[Prefs.voiceFmt(ctx).coerceIn(0, 3)]}  (muda em Ajustes)", 12f, Ui.sub)
                .apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP, 0, dp(16))
        )

        col.addGap()
        col.addView(label("Minhas gravações de voz", 15f, Ui.txt, true).apply {
            setPadding(dp(20), dp(16), dp(20), dp(8))
        })
        val n = fillMedia(col, 2)
        if (n == 0) {
            col.addView(label("Nenhuma gravação de voz ainda.", 13f, Ui.sub).apply {
                setPadding(dp(20), dp(8), dp(20), dp(8))
            })
        }

        voiceTime = time
        voiceWave = wave
        voiceMain = main
        voiceStop = stop
        voiceStatus = status
        lastVoiceState = VoiceService.state
        updateVoiceUi()
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun voiceMainCmd() {
        if (VoiceService.state == 0) {
            pendingMode = MODE_VOICE
            permissionsLauncher.launch(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO)
            )
        } else {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_PAUSE))
        }
    }

    private fun updateVoiceUi() {
        val st = VoiceService.state
        if (lastVoiceState != 0 && st == 0 && current == 2) {
            lastVoiceState = st
            select(2)        // recarrega a lista com o arquivo novo
            return
        }
        lastVoiceState = st
        val tv = voiceTime ?: return
        tv.text = fmtTime(VoiceService.elapsedMs())
        if (st == 1) voiceWave?.push(VoiceService.amp)
        voiceMain?.text = if (st == 1) "⏸" else if (st == 2) "▶" else "●"
        voiceStop?.visibility = if (st == 0) View.INVISIBLE else View.VISIBLE
        voiceStatus?.text = when (st) {
            1 -> "Gravando…"
            2 -> "Pausado"
            else -> "Toque em ● para gravar"
        }
    }

    // -------------------------------------------------------------- 47 Art Mode
    private fun artView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        col.addView(label("47 Art Mode", 20f, Ui.txt, true).apply {
            setPadding(dp(20), dp(20), dp(20), dp(2))
        })
        col.addView(label("Camadas, pincéis, simetria, timelapse e salvamento automático", 12f, Ui.sub).apply {
            setPadding(dp(20), 0, dp(20), dp(8))
        })
        val newBtn = label("🎨  Novo desenho", 16f, WHITE, true).apply {
            gravity = Gravity.CENTER
            background = round(Ui.accent, 24)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { startActivity(Intent(ctx, ArtActivity::class.java)) }
        }
        col.addView(newBtn, lp(MATCH, WRAP, dp(8), dp(16)).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
        })
        col.addGap()
        col.addView(label("Meus desenhos", 15f, Ui.txt, true).apply {
            setPadding(dp(20), dp(16), dp(20), dp(8))
        })
        val projects = ArtStore.list(ctx)
        if (projects.isEmpty()) {
            col.addView(label("Nenhum desenho ainda. Toque em \"Novo desenho\".", 13f, Ui.sub).apply {
                setPadding(dp(20), dp(8), dp(20), dp(8))
            })
        } else {
            for (pr in projects) col.addRow(projectRow(pr))
        }
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun projectRow(pr: ArtStore.Info): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Ui.bg)
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Ui.chip)
        }
        try {
            if (pr.thumb.exists()) {
                val bmp = android.graphics.BitmapFactory.decodeFile(pr.thumb.path)
                if (bmp != null) thumb.setImageBitmap(bmp)
            }
        } catch (_: Exception) { }
        r.addView(thumb, LinearLayout.LayoutParams(dp(72), dp(72)))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(pr.name, 14f, Ui.txt, true))
        val date = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date(pr.updated))
        info.addView(label("${pr.w}×${pr.h} • ${pr.layers} camadas • $date", 12f, Ui.sub), lp(WRAP, WRAP, dp(4)))
        r.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        r.setOnClickListener {
            startActivity(Intent(this, ArtActivity::class.java).putExtra("pid", pr.id))
        }
        r.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Excluir desenho?")
                .setMessage(pr.name)
                .setPositiveButton("Excluir") { _, _ ->
                    ArtStore.delete(this, pr.id)
                    select(current)
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
        return r
    }

    // -------------------------------------------------------------- Ajustes
    private fun settingsView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        col.addRow(row("🎬", "Qualidade da gravação",
            "${Prefs.resolution(ctx)}P/${Prefs.bitrate(ctx)}M/${Prefs.fps(ctx)}") {
            page = 1; select(TAB_SET)
        })
        col.addRow(row("👻", "Tela limpa", onOff(Prefs.clean(ctx))) {
            Prefs.setClean(ctx, !Prefs.clean(ctx)); select(TAB_SET)
        })
        col.addRow(row("🔊", "Som do aparelho", onOff(Prefs.internal(ctx))) {
            Prefs.setInternal(ctx, !Prefs.internal(ctx)); select(TAB_SET)
        })
        col.addRow(row("🎤", "Voz pelo microfone", onOff(Prefs.mic(ctx))) {
            Prefs.setMic(ctx, !Prefs.mic(ctx)); select(TAB_SET)
        })
        val extrasInfo = if (Prefs.countdown(ctx) > 0) "${Prefs.countdown(ctx)}s" else null
        col.addRow(row("⏱️", "Extras da gravação", extrasInfo) { page = 7; select(TAB_SET) })
        col.addGap()

        col.addRow(row("⏪", "Voltar no tempo  🆕", "${Prefs.replaySec(ctx)}s") {
            page = 4; select(TAB_SET)
        })
        val fmtNames = listOf("M4A", "OGG", "3GP", "WAV")
        col.addRow(row("🎙️", "Formato do gravador de voz", fmtNames[Prefs.voiceFmt(ctx).coerceIn(0, 3)]) {
            page = 5; select(TAB_SET)
        })
        col.addGap()

        val dot = View(ctx).apply {
            background = Ui.orbDrawable(Prefs.color(ctx), Prefs.orbShape(ctx), dp(28))
            alpha = Prefs.opacity(ctx) / 100f
        }
        col.addRow(row("🔴", "Botão 47", trailing = dot) { page = 2; select(TAB_SET) })
        col.addRow(row("📹", "Câmera (webcam)", onOff(Prefs.facecam(ctx))) { page = 8; select(TAB_SET) })
        col.addRow(row("💧", "Minha assinatura", onOff(Prefs.watermark(ctx))) {
            page = 3; select(TAB_SET)
        })
        col.addRow(row("🎨", "Aparência do app") { page = 6; select(TAB_SET) })
        col.addGap()

        col.addRow(row("🚀", "Abrir ao ligar o celular", onOff(Prefs.startOnBoot(ctx))) {
            Prefs.setStartOnBoot(ctx, !Prefs.startOnBoot(ctx)); select(TAB_SET)
        })
        col.addRow(row("🛡️", "Administrador do dispositivo", onOff(isAdminActive())) { toggleAdmin() })
        col.addRow(row("🔋", "Impedir que o Android feche o app", onOff(isIgnoringBattery())) { toggleBattery() })
        col.addGap()

        col.addRow(row("ℹ️", "Sobre o 47 Recorder", "v2.0.0"))
        col.addView(note("Tela limpa: esconde o botão 47 durante a gravação. " +
            "Para parar, use o botão \"Parar\" da notificação.\n\n" +
            "Abrir ao ligar: depois que o celular liga, aparece uma notificação (e o app tenta abrir sozinho); " +
            "você só confirma a captura de tela.\n\n" +
            "Administrador: impede desinstalar o app sem desativar antes. Quem mais evita o Android " +
            "fechar o app é a opção de bateria acima."))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun qualityView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Qualidade da gravação"))
        col.addGap()

        col.addView(sectionTitle("Perfis prontos"))
        col.addView(chips(listOf("🎮 Jogo", "📚 Tutorial", "🪶 Leve"), -1) { i ->
            when (i) {
                0 -> {
                    Prefs.setResolution(ctx, 1080)
                    Prefs.setBitrate(ctx, 8)
                    Prefs.setFps(ctx, 60)
                    Prefs.setInternal(ctx, true)
                    Prefs.setMic(ctx, false)
                }
                1 -> {
                    Prefs.setResolution(ctx, 720)
                    Prefs.setBitrate(ctx, 5)
                    Prefs.setFps(ctx, 30)
                    Prefs.setInternal(ctx, true)
                    Prefs.setMic(ctx, true)
                }
                else -> {
                    Prefs.setResolution(ctx, 480)
                    Prefs.setBitrate(ctx, 2)
                    Prefs.setFps(ctx, 30)
                    Prefs.setInternal(ctx, true)
                    Prefs.setMic(ctx, false)
                }
            }
            Toast.makeText(ctx, "Perfil aplicado", Toast.LENGTH_SHORT).show()
            select(TAB_SET)
        })

        val resList = listOf(480, 720, 1080)
        col.addView(sectionTitle("Resolução"))
        col.addView(chips(resList.map { "${it}p" }, resList.indexOf(Prefs.resolution(ctx))) { i ->
            Prefs.setResolution(ctx, resList[i]); select(TAB_SET)
        })

        val brList = listOf(2, 5, 8, 12)
        col.addView(sectionTitle("Taxa de bits (qualidade)"))
        col.addView(chips(brList.map { "$it Mbps" }, brList.indexOf(Prefs.bitrate(ctx))) { i ->
            Prefs.setBitrate(ctx, brList[i]); select(TAB_SET)
        })

        val fpsList = listOf(30, 60)
        col.addView(sectionTitle("Quadros por segundo"))
        col.addView(chips(fpsList.map { "$it fps" }, fpsList.indexOf(Prefs.fps(ctx))) { i ->
            Prefs.setFps(ctx, fpsList[i]); select(TAB_SET)
        })

        col.addView(note("Resolução e qualidade maiores geram arquivos maiores. " +
            "As capturas feitas durante a gravação saem na resolução escolhida aqui."))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun replayView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Voltar no tempo"))
        col.addGap()

        col.addView(label(
            "Grave o passado.\n\n" +
                "Neste modo o app fica gravando só na memória, sem criar arquivo. " +
                "Quando acontecer algo incrível, abra o botão 47 e toque em 💾 Salvar replay " +
                "(ou use \"Salvar replay\" na notificação) para guardar os últimos segundos.",
            14f, Ui.txt).apply { setPadding(dp(20), dp(20), dp(20), dp(12)) })

        val list = listOf(15, 30, 60)
        col.addView(sectionTitle("Duração salva"))
        col.addView(chips(list.map { "$it s" }, list.indexOf(Prefs.replaySec(ctx))) { i ->
            Prefs.setReplaySec(ctx, list[i]); select(TAB_SET)
        })

        val startBtn = Button(ctx).apply {
            text = "Iniciar agora"
            setOnClickListener { startMode(RecorderService.MODE_REPLAY) }
        }
        col.addView(startBtn, lp(MATCH, WRAP, dp(8)).apply { leftMargin = dp(20); rightMargin = dp(20) })
        col.addView(note("Quanto maior a duração e a qualidade, mais memória o modo usa."))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun extrasView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Extras da gravação"))
        col.addGap()

        val cd = listOf(0, 3, 5, 10)
        col.addView(sectionTitle("Contagem regressiva antes de gravar"))
        col.addView(chips(listOf("Off", "3 s", "5 s", "10 s"), cd.indexOf(Prefs.countdown(ctx))) { i ->
            Prefs.setCountdown(ctx, cd[i]); select(TAB_SET)
        })

        val am = listOf(0, 1, 5, 10, 30)
        col.addView(sectionTitle("Parar automaticamente depois de"))
        col.addView(chips(listOf("Off", "1 min", "5 min", "10 min", "30 min"), am.indexOf(Prefs.autoStopMin(ctx))) { i ->
            Prefs.setAutoStopMin(ctx, am[i]); select(TAB_SET)
        })

        col.addGap()
        col.addRow(row("📳", "Agitar para parar", onOff(Prefs.shake(ctx))) {
            Prefs.setShake(ctx, !Prefs.shake(ctx)); select(TAB_SET)
        })
        col.addView(note(
            "A contagem aparece na tela e dá tempo de abrir o jogo ou o app. " +
                "Enquanto grava, o botão 47 mostra o cronômetro. " +
                "Agitar para parar: sacuda o celular 3 vezes (pode não funcionar em todos os aparelhos). " +
                "Ao terminar, uma notificação permite abrir ou compartilhar o vídeo."
        ))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun cameraView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Câmera (webcam)"))
        col.addGap()

        col.addRow(row("📹", "Mostrar câmera na gravação", onOff(Prefs.facecam(ctx))) {
            val on = !Prefs.facecam(ctx)
            Prefs.setFacecam(ctx, on)
            if (on && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                cameraLauncher.launch(Manifest.permission.CAMERA)
            }
            select(TAB_SET)
        })

        // pré-visualização do formato, tamanho e borda
        val shape = Prefs.camShape(ctx)
        val pw = dp(Prefs.camSize(ctx))
        val ph = if (shape == 2) pw * 3 / 4 else pw
        val box = FrameLayout(ctx).apply { background = round(0xFF2B2F3A.toInt()) }
        val prev = View(ctx)
        val pd = GradientDrawable()
        if (shape == 0) {
            pd.shape = GradientDrawable.OVAL
        } else {
            pd.shape = GradientDrawable.RECTANGLE
            pd.cornerRadius = if (shape == 1) pw * 0.2f else dp(10).toFloat()
        }
        pd.setColor(0xFF777777.toInt())
        if (Prefs.camBorder(ctx)) pd.setStroke(dp(3), Prefs.color(ctx))
        prev.background = pd
        prev.alpha = Prefs.camOpacity(ctx) / 100f
        box.addView(prev, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))
        col.addView(box, lp(MATCH, dp(280), dp(8), dp(8)).apply {
            leftMargin = dp(16)
            rightMargin = dp(16)
        })

        col.addView(sectionTitle("Câmera"))
        col.addView(chips(listOf("Frontal", "Traseira"), Prefs.camFacing(ctx)) { i ->
            Prefs.setCamFacing(ctx, i); select(TAB_SET)
        })

        col.addView(sectionTitle("Formato da janela"))
        col.addView(chips(listOf("Círculo", "Quadrado", "Retângulo"), Prefs.camShape(ctx)) { i ->
            Prefs.setCamShape(ctx, i); select(TAB_SET)
        })

        col.addView(sectionTitle("Posição inicial"))
        col.addView(chips(listOf("↖ Topo", "↗ Topo", "↙ Base", "↘ Base"), Prefs.camCorner(ctx)) { i ->
            Prefs.setCamCorner(ctx, i); select(TAB_SET)
        })

        val sliders = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(8))
        }
        sliders.addView(label("Tamanho: ${Prefs.camSize(ctx)}", 14f, Ui.txt))
        sliders.addView(slider(160, Prefs.camSize(ctx) - 80, true) { p ->
            Prefs.setCamSize(ctx, p + 80); select(TAB_SET)
        }, lp(MATCH, WRAP, dp(4), dp(12)))
        sliders.addView(label("Opacidade: ${Prefs.camOpacity(ctx)}%", 14f, Ui.txt))
        sliders.addView(slider(70, Prefs.camOpacity(ctx) - 30, true) { p ->
            Prefs.setCamOpacity(ctx, p + 30); select(TAB_SET)
        }, lp(MATCH, WRAP, dp(4), dp(4)))
        col.addView(sliders)

        col.addGap()
        col.addRow(row("🪞", "Espelhar imagem (frontal)", onOff(Prefs.camMirror(ctx))) {
            Prefs.setCamMirror(ctx, !Prefs.camMirror(ctx)); select(TAB_SET)
        })
        col.addRow(row("⭕", "Borda colorida", onOff(Prefs.camBorder(ctx))) {
            Prefs.setCamBorder(ctx, !Prefs.camBorder(ctx)); select(TAB_SET)
        })
        col.addView(note(
            "A borda usa a cor do botão 47. Durante a gravação, arraste a janelinha da câmera " +
                "para onde quiser. Se mudar a câmera com o círculo flutuante aberto, feche o círculo " +
                "(arrastando até o ✕) e abra de novo."
        ))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun voiceFormatView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Formato do gravador de voz"))
        col.addGap()

        col.addView(sectionTitle("Formato do arquivo"))
        col.addView(chips(listOf("M4A", "OGG", "3GP", "WAV"), Prefs.voiceFmt(ctx).coerceIn(0, 3)) { i ->
            Prefs.setVoiceFmt(ctx, i); select(TAB_SET)
        })
        col.addView(label(
            "M4A: AAC, o mais compatível.\nOGG: Opus, ótima qualidade com arquivo pequeno.\n" +
                "3GP: AMR-WB, voz leve.\nWAV: sem compressão, arquivo grande.",
            12f, Ui.sub).apply { setPadding(dp(20), 0, dp(20), dp(8)) })

        val kb = listOf(64, 128, 192)
        col.addView(sectionTitle("Qualidade (M4A e OGG)"))
        col.addView(chips(kb.map { "$it kbps" }, kb.indexOf(Prefs.voiceKbps(ctx))) { i ->
            Prefs.setVoiceKbps(ctx, kb[i]); select(TAB_SET)
        })
        col.addView(note("Se o aparelho não suportar o formato escolhido, o app usa M4A automaticamente."))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun watermarkView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Minha assinatura"))
        col.addGap()

        col.addRow(row("💧", "Mostrar assinatura", onOff(Prefs.watermark(ctx))) {
            Prefs.setWatermark(ctx, !Prefs.watermark(ctx)); select(TAB_SET)
        })

        col.addView(sectionTitle("Texto"))
        val et = EditText(ctx).apply {
            setText(Prefs.wmText(ctx))
            hint = "Seu texto"
            setSingleLine()
            setTextColor(Ui.txt)
            setHintTextColor(Ui.sub)
            filters = arrayOf(InputFilter.LengthFilter(30))
            doAfterTextChanged { Prefs.setWmText(ctx, it?.toString() ?: "") }
        }
        col.addView(et, lp(MATCH, WRAP).apply { leftMargin = dp(20); rightMargin = dp(20) })

        col.addView(sectionTitle("Posição"))
        col.addView(chips(listOf("↖ Topo", "↗ Topo", "↙ Base", "↘ Base"), Prefs.wmPos(ctx)) { i ->
            Prefs.setWmPos(ctx, i); select(TAB_SET)
        })

        col.addView(note("A assinatura aparece na tela durante a gravação, " +
            "então fica gravada no vídeo e nas capturas."))
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun appearanceView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Aparência do app"))
        col.addGap()

        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        body.addView(label("Cor de destaque", 14f, Ui.txt, true))
        body.addView(colorPicker(Ui.accent, true) { c ->
            Prefs.setUiAccent(ctx, c); restyle()
        })

        body.addView(label("Fundo", 14f, Ui.txt, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        val bgs = listOf(0xFF0E0E0E.toInt(), 0xFF1C1F26.toInt(), 0xFF1A0A0E.toInt(), 0xFF0B1020.toInt())
        body.addView(chips(listOf("Preto", "Grafite", "Vinho", "Azul"), bgs.indexOf(Prefs.uiBg(ctx))) { i ->
            Prefs.setUiBg(ctx, bgs[i]); restyle()
        })

        body.addView(label("Tamanho do texto", 14f, Ui.txt, true))
        body.addView(chips(listOf("Pequeno", "Normal", "Grande"), Prefs.uiScale(ctx)) { i ->
            Prefs.setUiScale(ctx, i); restyle()
        })

        body.addView(label("Arredondamento dos cantos", 14f, Ui.txt, true).apply { setPadding(0, dp(4), 0, dp(4)) })
        body.addView(slider(28, Prefs.uiRadius(ctx), true) { p ->
            Prefs.setUiRadius(ctx, p); restyle()
        }, lp(MATCH, WRAP, 0, dp(16)))

        val reset = Button(ctx).apply {
            text = "Restaurar vermelho e preto"
            setOnClickListener { Prefs.resetUi(ctx); restyle() }
        }
        body.addView(reset, lp(MATCH, WRAP))
        col.addView(body)
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun orbView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Botão 47"))
        col.addGap()

        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        val box = FrameLayout(ctx).apply { background = round(0xFF2B2F3A.toInt()) }
        val preview = TextView(ctx).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        box.addView(preview)
        body.addView(box, lp(MATCH, dp(170), 0, dp(16)))

        fun refresh() {
            val s = dp(Prefs.size(ctx))
            val c = Prefs.color(ctx)
            val t = Prefs.orbText(ctx)
            preview.layoutParams = FrameLayout.LayoutParams(s, s, Gravity.CENTER)
            preview.background = Ui.orbDrawable(c, Prefs.orbShape(ctx), s)
            preview.alpha = Prefs.opacity(ctx) / 100f
            preview.text = t
            preview.setTextColor(Prefs.contrast(c))
            preview.textSize = Prefs.size(ctx) / (if (t.length >= 3) 4.2f else 3.2f)
        }
        refresh()

        val sizeLbl = label("Tamanho: ${Prefs.size(ctx)}", 14f, Ui.txt)
        body.addView(sizeLbl)
        body.addView(slider(80, Prefs.size(ctx) - 40) { p ->
            Prefs.setSize(ctx, p + 40)
            sizeLbl.text = "Tamanho: ${p + 40}"
            refresh()
        }, lp(MATCH, WRAP, dp(4), dp(16)))

        val opLbl = label("Opacidade: ${Prefs.opacity(ctx)}%", 14f, Ui.txt)
        body.addView(opLbl)
        body.addView(slider(80, Prefs.opacity(ctx) - 20) { p ->
            Prefs.setOpacity(ctx, p + 20)
            opLbl.text = "Opacidade: ${p + 20}%"
            refresh()
        }, lp(MATCH, WRAP, dp(4), dp(16)))

        body.addView(label("Cor do botão", 14f, Ui.txt, true))
        body.addView(colorPicker(Prefs.color(ctx), false) { c ->
            Prefs.setColor(ctx, c); refresh()
        })

        body.addView(label("Formato", 14f, Ui.txt, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        body.addView(chips(listOf("Círculo", "Quadrado arredondado"), Prefs.orbShape(ctx)) { i ->
            Prefs.setOrbShape(ctx, i); select(TAB_SET)
        })

        body.addView(label("Texto do botão (até 3 letras)", 14f, Ui.txt, true))
        val et = EditText(ctx).apply {
            setText(Prefs.orbText(ctx))
            setSingleLine()
            setTextColor(Ui.txt)
            setHintTextColor(Ui.sub)
            filters = arrayOf(InputFilter.LengthFilter(3))
            doAfterTextChanged {
                Prefs.setOrbText(ctx, it?.toString() ?: "")
                refresh()
            }
        }
        body.addView(et, lp(MATCH, WRAP, 0, dp(12)))

        body.addView(label("Cor do painel de opções", 14f, Ui.txt, true))
        val panels = listOf(0xF2141414.toInt(), 0xF21F2430.toInt(), 0xF22A0F14.toInt(), 0xF2F5F5F5.toInt())
        body.addView(chips(listOf("Preto", "Grafite", "Vinho", "Claro"), panels.indexOf(Prefs.menuBg(ctx))) { i ->
            Prefs.setMenuBg(ctx, panels[i]); select(TAB_SET)
        })

        val rowShot = row("📷", "Mostrar \"Capturar\"", onOff(Prefs.showShot(ctx))) {
            Prefs.setShowShot(ctx, !Prefs.showShot(ctx)); select(TAB_SET)
        }
        val rowDraw = row("✏️", "Mostrar \"Desenhar\"", onOff(Prefs.showDraw(ctx))) {
            Prefs.setShowDraw(ctx, !Prefs.showDraw(ctx)); select(TAB_SET)
        }
        body.addView(rowShot, lp(MATCH, WRAP, dp(8)))
        body.addView(rowDraw, lp(MATCH, WRAP))

        body.addView(label(
            "Toque no botão para abrir as opções (gravar, pausar, parar, áudio, desenhar e print). " +
                "Arraste até o ✕ que aparece embaixo para fechar tudo. " +
                "Vale a partir da próxima gravação.",
            12f, Ui.sub), lp(WRAP, WRAP, dp(12), dp(12)))
        val reset = Button(ctx).apply {
            text = "Restaurar padrão"
            setOnClickListener { Prefs.resetOrb(ctx); select(TAB_SET) }
        }
        body.addView(reset, lp(MATCH, WRAP))

        col.addView(body)
        return ScrollView(ctx).apply { addView(col) }
    }

    // ----------------------------------------------------------- gravação
    // ---------------------------------------------- estabilidade do app
    private fun adminComponent() = ComponentName(this, AdminReceiver::class.java)

    private fun isAdminActive(): Boolean {
        return try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.isAdminActive(adminComponent())
        } catch (_: Exception) {
            false
        }
    }

    private fun toggleAdmin() {
        try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isAdminActive(adminComponent())) {
                AlertDialog.Builder(this)
                    .setTitle("Desativar administrador?")
                    .setMessage("O app deixará de ser administrador e poderá ser desinstalado normalmente.")
                    .setPositiveButton("Desativar") { _, _ ->
                        try { dpm.removeActiveAdmin(adminComponent()) } catch (_: Exception) { }
                        select(TAB_SET)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            } else {
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                i.putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Ativar como administrador impede que o 47 Recorder seja desinstalado sem querer. " +
                        "Ele não recebe nenhum controle extra sobre o celular."
                )
                startActivity(i)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o ajuste de administrador", Toast.LENGTH_LONG).show()
        }
    }

    private fun isIgnoringBattery(): Boolean {
        return try {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        } catch (_: Exception) {
            false
        }
    }

    private fun toggleBattery() {
        try {
            if (isIgnoringBattery()) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } else {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Abra Ajustes > Bateria e libere o 47 Recorder", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startDraw() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Ative a sobreposição e volte", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, DrawService::class.java))
        moveTaskToBack(true)
    }

    private fun startMode(mode: Int) {
        if (RecorderService.active) {
            Toast.makeText(
                this,
                "O círculo flutuante já está aberto. Use as opções dele ou arraste até o ✕ para fechar.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        pendingMode = mode
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Ative a sobreposição e volte", Toast.LENGTH_LONG).show()
            return
        }
        val perms = mutableListOf(Manifest.permission.POST_NOTIFICATIONS)
        perms.add(Manifest.permission.RECORD_AUDIO)
        if (Prefs.facecam(this)) perms.add(Manifest.permission.CAMERA)
        permissionsLauncher.launch(perms.toTypedArray())
    }

    private fun showRecChoice() {
        val items = arrayOf("⭕  Abrir círculo flutuante", "●  Gravar agora")
        AlertDialog.Builder(this)
            .setTitle("47 Recorder")
            .setItems(items) { _, which ->
                if (which == 0) openCircle() else recordNow()
            }
            .show()
    }

    private fun openCircle() {
        startMode(RecorderService.MODE_MENU)
    }

    private fun recordNow() {
        if (RecorderService.active) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_REC))
            moveTaskToBack(true)
        } else {
            startMode(RecorderService.MODE_RECORD)
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
