package com.recorder47

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputFilter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged

private val ACCENT = 0xFFEE4B2B.toInt()
private val BAR_DARK = 0xFFC93A1E.toInt()
private val BG = 0xFFFFFFFF.toInt()
private val TXT = 0xFF222222.toInt()
private val SUB = 0xFF8A8A8A.toInt()
private val DIV = 0xFFE6E6E6.toInt()
private val SECTION = 0xFFEFEFEF.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : ComponentActivity() {

    private lateinit var content: FrameLayout
    private lateinit var tabIcons: List<TextView>
    private lateinit var tabInds: List<View>
    private var current = 0        // 0 = Vídeos, 1 = Imagens, 2 = Ajustes
    private var page = 0           // 0 lista, 1 vídeo, 2 círculo, 3 marca d'água, 4 replay
    private var pendingMode = RecorderService.MODE_RECORD

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { page = 0; select(2) }
    }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, RecorderService::class.java).apply {
                    action = RecorderService.ACTION_START
                    putExtra(RecorderService.EXTRA_CODE, result.resultCode)
                    putExtra(RecorderService.EXTRA_DATA, result.data)
                    putExtra(RecorderService.EXTRA_MIC, Prefs.mic(this@MainActivity))
                    putExtra(RecorderService.EXTRA_MODE, pendingMode)
                }
                startForegroundService(intent)
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Permissão de captura negada", Toast.LENGTH_SHORT).show()
            }
        }

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (pendingMode == RecorderService.MODE_SHOT || it[Manifest.permission.RECORD_AUDIO] == true) {
                askProjection()
            } else {
                Toast.makeText(this, "Permita o áudio para gravar", Toast.LENGTH_SHORT).show()
            }
        }

    // ------------------------------------------------------------ helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, r: Int = 16) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top; bottomMargin = bottom }

    private fun LinearLayout.addRow(v: View) {
        addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(View(context).apply { setBackgroundColor(DIV) }, LinearLayout.LayoutParams(MATCH, 1))
    }

    private fun LinearLayout.addGap() {
        addView(View(context).apply { setBackgroundColor(SECTION) },
            LinearLayout.LayoutParams(MATCH, dp(12)))
    }

    private fun row(
        icon: String, title: String, value: String? = null,
        trailing: View? = null, onClick: (() -> Unit)? = null
    ): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setBackgroundColor(BG)
        }
        r.addView(label(icon, 18f, TXT), LinearLayout.LayoutParams(dp(36), WRAP))
        r.addView(label(title, 15f, TXT), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (value != null) r.addView(label(value, 15f, ACCENT))
        if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(dp(28), dp(28)))
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    private fun header(title: String): View =
        label("‹  $title", 17f, TXT, true).apply {
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setOnClickListener { page = 0; select(2) }
        }

    private fun sectionTitle(t: String) =
        label(t, 14f, SUB).apply { setPadding(dp(20), dp(16), dp(20), dp(8)) }

    private fun slider(max: Int, value: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            progress = value
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

    private fun chips(options: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(16), dp(16))
        }
        options.forEachIndexed { i, o ->
            val sel = i == selected
            val t = label(o, 14f, if (sel) 0xFFFFFFFF.toInt() else TXT, sel).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                background = round(if (sel) ACCENT else SECTION, 20)
                setOnClickListener { onPick(i) }
            }
            r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
        return r
    }

    private fun pill(text: String, onClick: () -> Unit) =
        label(text, 13f, 0xFFFFFFFF.toInt(), true).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = round(0xFF333333.toInt(), 22)
            elevation = dp(4).toFloat()
            setOnClickListener { onClick() }
        }

    private fun onOff(b: Boolean) = if (b) "Ativado" else "Desativado"

    // ------------------------------------------------------------- ciclo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BAR_DARK
        onBackPressedDispatcher.addCallback(this, backCb)

        content = FrameLayout(this)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(ACCENT)
        }
        val icons = mutableListOf<TextView>()
        val inds = mutableListOf<View>()
        listOf("🎬", "🖼️", "⚙️").forEachIndexed { i, s ->
            val t = TextView(this).apply {
                text = s
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(0, dp(14), 0, dp(10))
            }
            val u = View(this)
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setOnClickListener { page = 0; select(i) }
            }
            cell.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            cell.addView(u, LinearLayout.LayoutParams(dp(28), dp(3)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            })
            bar.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            icons.add(t); inds.add(u)
        }
        tabIcons = icons
        tabInds = inds

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        })
        select(0)
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) select(current)
    }

    private fun select(i: Int) {
        current = i
        backCb.isEnabled = (i == 2 && page != 0)
        tabInds.forEachIndexed { k, v ->
            v.setBackgroundColor(if (k == i) 0xFFFFFFFF.toInt() else 0x00000000)
            tabIcons[k].alpha = if (k == i) 1f else 0.6f
        }
        content.removeAllViews()
        content.addView(
            when (i) {
                0 -> mediaView(true)
                1 -> mediaView(false)
                else -> when (page) {
                    1 -> videoSettingsView()
                    2 -> circleView()
                    3 -> watermarkView()
                    4 -> replayView()
                    else -> settingsView()
                }
            }
        )
    }

    // ------------------------------------------------- Vídeos e Imagens
    private fun mediaView(video: Boolean): View {
        val root = FrameLayout(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(200))
        }

        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cols = if (video) arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE
        ) else arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE
        )
        val pathCol = if (video) MediaStore.Video.Media.RELATIVE_PATH else MediaStore.Images.Media.RELATIVE_PATH
        val dateCol = if (video) MediaStore.Video.Media.DATE_ADDED else MediaStore.Images.Media.DATE_ADDED
        val prefix = if (video) "Movies/47 Recorder%" else "Pictures/47 Recorder%"

        var count = 0
        try {
            contentResolver.query(
                collection, cols, "$pathCol LIKE ?", arrayOf(prefix), "$dateCol DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: "arquivo"
                    val dur = if (video) c.getLong(2) else 0L
                    val size = c.getLong(if (video) 3 else 2)
                    col.addRow(mediaRow(video, id, name, dur, size))
                    count++
                }
            }
        } catch (_: Exception) { }

        if (count == 0) {
            val msg = if (video) "Nenhum vídeo ainda.\nToque em REC para gravar."
            else "Nenhuma imagem ainda.\nUse 📷 Prints para capturar a tela."
            col.addView(label(msg, 14f, SUB).apply {
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(80), dp(24), 0)
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        root.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(MATCH, MATCH))

        if (video) {
            val cluster = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            cluster.addView(pill("⏪ Replay") { startMode(RecorderService.MODE_REPLAY) }, lp(WRAP, WRAP, 0, dp(10)))
            cluster.addView(pill("📷 Prints") { startMode(RecorderService.MODE_SHOT) }, lp(WRAP, WRAP, 0, dp(14)))
            val fab = label("REC", 13f, 0xFFFFFFFF.toInt(), true).apply {
                gravity = Gravity.CENTER
                background = oval(ACCENT)
                elevation = dp(8).toFloat()
                setOnClickListener { startMode(RecorderService.MODE_RECORD) }
            }
            cluster.addView(fab, LinearLayout.LayoutParams(dp(68), dp(68)))
            root.addView(cluster, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
                rightMargin = dp(20); bottomMargin = dp(24)
            })
        }
        return root
    }

    private fun mediaRow(video: Boolean, id: Long, name: String, durMs: Long, size: Long): View {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, id)
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(BG)
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(SECTION)
        }
        r.addView(thumb, LinearLayout.LayoutParams(dp(120), dp(72)))
        Thread {
            try {
                val bmp = contentResolver.loadThumbnail(uri, Size(dp(240), dp(144)), null)
                runOnUiThread { thumb.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }.start()

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(name, 14f, TXT, true))
        val mb = size / 1048576.0
        val line = if (video) {
            val secs = durMs / 1000
            String.format("%d:%02d  •  %.1f MB", secs / 60, secs % 60, mb)
        } else String.format("%.1f MB", mb)
        info.addView(label(line, 12f, SUB), lp(WRAP, WRAP, dp(4)))
        r.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        r.setOnClickListener {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, if (video) "video/*" else "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Nenhum app encontrado para abrir", Toast.LENGTH_SHORT).show()
            }
        }
        r.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Excluir?")
                .setMessage(name)
                .setPositiveButton("Excluir") { _, _ ->
                    try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
                    select(current)
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
        return r
    }

    // -------------------------------------------------------------- Ajustes
    private fun settingsView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        col.addRow(row("🎬", "Configurações de vídeo",
            "${Prefs.resolution(ctx)}P/${Prefs.bitrate(ctx)}M/${Prefs.fps(ctx)}") {
            page = 1; select(2)
        })
        col.addRow(row("✨", "Modo limpo", onOff(Prefs.clean(ctx))) {
            Prefs.setClean(ctx, !Prefs.clean(ctx)); select(2)
        })
        col.addRow(row("🔊", "Áudio interno", onOff(Prefs.internal(ctx))) {
            Prefs.setInternal(ctx, !Prefs.internal(ctx)); select(2)
        })
        col.addRow(row("🎤", "Microfone", onOff(Prefs.mic(ctx))) {
            Prefs.setMic(ctx, !Prefs.mic(ctx)); select(2)
        })
        col.addGap()

        col.addRow(row("⏪", "Replay instantâneo  🆕", "${Prefs.replaySec(ctx)}s") {
            page = 4; select(2)
        })
        col.addGap()

        val dot = View(ctx).apply {
            background = oval(Prefs.color(ctx))
            alpha = Prefs.opacity(ctx) / 100f
        }
        col.addRow(row("⭕", "Círculo flutuante", trailing = dot) { page = 2; select(2) })
        col.addRow(row("📹", "Face cam", onOff(Prefs.facecam(ctx))) {
            Prefs.setFacecam(ctx, !Prefs.facecam(ctx)); select(2)
        })
        col.addRow(row("💧", "Marca d'água", onOff(Prefs.watermark(ctx))) {
            page = 3; select(2)
        })
        col.addGap()

        col.addRow(row("ℹ️", "Sobre o 47 Recorder", "v1.4.0"))

        col.addView(
            label("Modo limpo: esconde o círculo flutuante durante a gravação. " +
                "Para parar, use o botão \"Parar\" da notificação.", 12f, SUB)
                .apply { setPadding(dp(20), dp(16), dp(20), dp(24)) }
        )
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun videoSettingsView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Configurações de vídeo"))
        col.addGap()

        val resList = listOf(480, 720, 1080)
        col.addView(sectionTitle("Resolução"))
        col.addView(chips(resList.map { "${it}p" }, resList.indexOf(Prefs.resolution(ctx))) { i ->
            Prefs.setResolution(ctx, resList[i]); select(2)
        })

        val brList = listOf(2, 5, 8, 12)
        col.addView(sectionTitle("Qualidade (taxa de bits)"))
        col.addView(chips(brList.map { "$it Mbps" }, brList.indexOf(Prefs.bitrate(ctx))) { i ->
            Prefs.setBitrate(ctx, brList[i]); select(2)
        })

        val fpsList = listOf(30, 60)
        col.addView(sectionTitle("Taxa de quadros"))
        col.addView(chips(fpsList.map { "$it fps" }, fpsList.indexOf(Prefs.fps(ctx))) { i ->
            Prefs.setFps(ctx, fpsList[i]); select(2)
        })

        col.addView(label("Resolução e qualidade maiores geram arquivos maiores. " +
            "Os prints durante a gravação saem na resolução escolhida aqui.", 12f, SUB)
            .apply { setPadding(dp(20), dp(8), dp(20), dp(24)) })
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun replayView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Replay instantâneo"))
        col.addGap()

        col.addView(label(
            "Grave o passado.\n\n" +
                "No modo Replay o app fica gravando só na memória, sem criar arquivo. " +
                "Quando acontecer algo incrível, toque em 💾 no botão flutuante (ou em " +
                "\"Salvar replay\" na notificação) e ele salva os últimos segundos que você escolher.",
            14f, TXT).apply { setPadding(dp(20), dp(20), dp(20), dp(12)) })

        val list = listOf(15, 30, 60)
        col.addView(sectionTitle("Duração salva"))
        col.addView(chips(list.map { "$it s" }, list.indexOf(Prefs.replaySec(ctx))) { i ->
            Prefs.setReplaySec(ctx, list[i]); select(2)
        })

        col.addView(Button(ctx).apply {
            text = "Iniciar replay agora"
            setOnClickListener { startMode(RecorderService.MODE_REPLAY) }
        }, lp(MATCH, WRAP, dp(8)).apply { leftMargin = dp(20); rightMargin = dp(20) })

        col.addView(label("Quanto maior a duração e a qualidade de vídeo, mais memória o replay usa.",
            12f, SUB).apply { setPadding(dp(20), dp(16), dp(20), dp(24)) })
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun watermarkView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Marca d'água"))
        col.addGap()

        col.addRow(row("💧", "Mostrar marca d'água", onOff(Prefs.watermark(ctx))) {
            Prefs.setWatermark(ctx, !Prefs.watermark(ctx)); select(2)
        })

        col.addView(sectionTitle("Texto"))
        val et = EditText(ctx).apply {
            setText(Prefs.wmText(ctx))
            hint = "Seu texto"
            setSingleLine()
            setTextColor(TXT)
            filters = arrayOf(InputFilter.LengthFilter(30))
            doAfterTextChanged { Prefs.setWmText(ctx, it?.toString() ?: "") }
        }
        col.addView(et, lp(MATCH, WRAP).apply { leftMargin = dp(20); rightMargin = dp(20) })

        col.addView(sectionTitle("Posição"))
        col.addView(chips(listOf("↖ Topo", "↗ Topo", "↙ Base", "↘ Base"), Prefs.wmPos(ctx)) { i ->
            Prefs.setWmPos(ctx, i); select(2)
        })

        col.addView(label("A marca d'água aparece na tela durante a gravação, " +
            "então fica gravada no vídeo e nos prints.", 12f, SUB)
            .apply { setPadding(dp(20), dp(8), dp(20), dp(24)) })
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun circleView(): View {
        val ctx = this
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(header("Círculo flutuante"))
        col.addGap()

        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        val box = FrameLayout(ctx).apply { background = round(0xFF2B2F3A.toInt()) }
        val preview = TextView(ctx).apply { text = "47"; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        box.addView(preview)
        body.addView(box, lp(MATCH, dp(170), 0, dp(16)))

        fun refresh() {
            val s = dp(Prefs.size(ctx))
            val c = Prefs.color(ctx)
            preview.layoutParams = FrameLayout.LayoutParams(s, s, Gravity.CENTER)
            preview.background = oval(c)
            preview.alpha = Prefs.opacity(ctx) / 100f
            preview.setTextColor(Prefs.contrast(c))
            preview.textSize = Prefs.size(ctx) / 3.2f
        }
        refresh()

        val sizeLbl = label("Tamanho: ${Prefs.size(ctx)}", 14f, TXT)
        body.addView(sizeLbl)
        body.addView(slider(80, Prefs.size(ctx) - 40) { p ->
            Prefs.setSize(ctx, p + 40)
            sizeLbl.text = "Tamanho: ${p + 40}"
            refresh()
        }, lp(MATCH, WRAP, dp(4), dp(16)))

        val opLbl = label("Opacidade: ${Prefs.opacity(ctx)}%", 14f, TXT)
        body.addView(opLbl)
        body.addView(slider(80, Prefs.opacity(ctx) - 20) { p ->
            Prefs.setOpacity(ctx, p + 20)
            opLbl.text = "Opacidade: ${p + 20}%"
            refresh()
        }, lp(MATCH, WRAP, dp(4), dp(16)))

        body.addView(label("Cor", 14f, TXT))
        val presets = intArrayOf(
            0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFFFDD835.toInt(), 0xFF43A047.toInt(),
            0xFF00ACC1.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFFEC407A.toInt(),
            0xFFFFFFFF.toInt(), 0xFF000000.toInt()
        )
        val prow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (pc in presets) {
            val d = View(ctx).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(pc)
                    setStroke(dp(2), 0xFFBBBBBB.toInt())
                }
                setOnClickListener { Prefs.setColor(ctx, pc); refresh() }
            }
            prow.addView(d, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        }
        body.addView(HorizontalScrollView(ctx).apply { addView(prow) }, lp(MATCH, WRAP, dp(8), dp(12)))

        val strip = View(ctx).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                    0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
                )
            ).apply { cornerRadius = dp(4).toFloat() }
        }
        body.addView(strip, lp(MATCH, dp(8)))
        val hsv = FloatArray(3)
        Color.colorToHSV(Prefs.color(ctx), hsv)
        body.addView(slider(360, hsv[0].toInt()) { p ->
            Prefs.setColor(ctx, Color.HSVToColor(floatArrayOf(p.toFloat(), 0.85f, 0.95f)))
            refresh()
        }, lp(MATCH, WRAP, 0, dp(16)))

        body.addView(label("Toque no círculo durante a gravação para abrir o menu " +
            "(💾 salvar replay, 📷 print, ■ parar). Vale a partir da próxima gravação.", 12f, SUB),
            lp(WRAP, WRAP, 0, dp(12)))
        body.addView(Button(ctx).apply {
            text = "Restaurar padrão"
            setOnClickListener { Prefs.resetCircle(ctx); select(2) }
        }, lp(MATCH, WRAP))

        col.addView(body)
        return ScrollView(ctx).apply { addView(col) }
    }

    // ----------------------------------------------------------- gravação
    private fun startMode(mode: Int) {
        pendingMode = mode
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Ative a sobreposição e volte", Toast.LENGTH_LONG).show()
            return
        }
        val perms = mutableListOf(Manifest.permission.POST_NOTIFICATIONS)
        if (mode != RecorderService.MODE_SHOT) perms.add(Manifest.permission.RECORD_AUDIO)
        if (Prefs.facecam(this)) perms.add(Manifest.permission.CAMERA)
        permissionsLauncher.launch(perms.toTypedArray())
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
