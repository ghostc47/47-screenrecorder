# 47 Recorder

Gravador de tela open source para Android, escrito do zero (Kotlin).

## Recursos (v1.1)
- Gravação de tela H.264 (até 1080p, 30 fps, 8 Mbps)
- **Áudio interno** do aparelho (AudioPlaybackCapture, Android 10+)
- Microfone opcional, mixado com o áudio interno
- Botão flutuante arrastável para parar
- Salva em Movies/47 Recorder

## Limitações
- Alguns apps bloqueiam a captura de áudio (ex.: apps de streaming com DRM, chamadas).
- Se o áudio interno falhar, grava só o vídeo.

## Gerar o APK
**GitHub Actions:** suba o projeto, abra a aba Actions e baixe o artefato `47recorder-apk`.
**Android Studio:** Build > Build APK(s).

## Próximos passos
Câmera frontal (PiP), contagem regressiva, configurações de qualidade, editor básico, ícone próprio, licença.
