# 47 Recorder

Gravador de tela open source para Android, escrito do zero (Kotlin).

## Recursos (v1.1)
- Gravação de tela H.264 (até 1080p, 30 fps, 8 Mbps)
- **Áudio interno** do aparelho (AudioPlaybackCapture, Android 10+)
- Microfone opcional, mixado com o áudio interno
- Botão flutuante arrastável para parar
- Salva em Movies/47 Recorder

## Novidades (etapa 1)
- Resolução até 4K, bitrate até 80 Mbps, 90/120 fps (ajusta sozinho ao limite do aparelho)
- Codec HEVC/H.265 opcional, com queda automática para H.264
- Mostrar toques na tela e continuar gravando com a tela apagada
- Gravação agendada por horário e parada automática até 1 h

## Novidades (etapa 2)
- Player próprio: vídeo, áudio e imagens, com toque duplo ±10 s, velocidade 0,5x–2x, repetir, girar, anterior/próximo, compartilhar, detalhes e excluir
- Galeria: ordenar por recentes/maiores/nome, total de itens e MB, menu de pressionar e segurar (abrir em outro app, compartilhar, renomear, excluir)
- A notificação "Vídeo salvo" abre no player do app

## Limitações
- Alguns apps bloqueiam a captura de áudio (ex.: apps de streaming com DRM, chamadas).
- Se o áudio interno falhar, grava só o vídeo.

## Gerar o APK
**GitHub Actions:** suba o projeto, abra a aba Actions e baixe o artefato `47recorder-apk`.
**Android Studio:** Build > Build APK(s).

## Próximos passos
Câmera frontal (PiP), contagem regressiva, configurações de qualidade, editor básico, ícone próprio, licença.
